# Waves 1–8 — Exact SQL + JS Commits (git patches)

These patches apply **Wave 1 → Wave 8** on top of the base commit (`chore: initial SSI skeleton`).

## Apply (recommended)

```sh
# 1) Clone or cd into your repo (or create a new repo)
# 2) Ensure your repo is at the baseline commit equivalent
# 3) From the repo root:

git am ./patches/*.patch
```

If a patch fails:

```sh
git am --abort
# then inspect the failing patch and your working tree
```

## Contents
- `patches/0001...0008*.patch` — the exact commit diffs
- `README_APPLY.md` — instructions

## Validate quickly (Termux)

```sh
npm install
npm run maicp:server &
npm run maicp:local &
node core/ssi_maicp_driver.js "test"
node scripts/inspect_db.js
```
