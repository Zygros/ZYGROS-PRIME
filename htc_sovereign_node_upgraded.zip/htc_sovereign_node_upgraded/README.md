# HTC Sovereign Node — UPGRADE ALL (Bounded, Secure, Auditable)

This package is a hardened, deployable FastAPI service that runs **bounded** HTC simulations,
stores results persistently, and supports secure inter-node use.

## What’s Included
- Bounded simulation engine with numeric hardening + SHA-512 epoch truth layer
- FastAPI service with:
  - Node registration (API key issued once)
  - JWT session tokens (short-lived)
  - Dual-auth protected endpoints (JWT + X-API-Key) for write/ignite
  - Rate limiting (in-memory; swap to Redis in production)
  - Persistent storage (SQLite by default; Postgres-ready schema)
  - Checkpoint artifacts (hash + manifest) per run
- Optional Stripe webhook adapter stub (safe, minimal)
- Docker + docker-compose for one-command launch

## Quickstart
```bash
docker compose up --build
```

Open:
- http://localhost:8000/docs
- http://localhost:8000/health

## Security Model
1) Register node -> receive API key (shown once)
2) Exchange API key for JWT token
3) Call /ignite or /nexus/data/write with BOTH:
   - Authorization: Bearer <JWT>
   - X-API-Key: <API_KEY>

## Environment
- HTC_SECRET_KEY (required in production)
- HTC_MAX_DEPTH (default 500)
- HTC_MAX_CONCURRENT (default 16)
- HTC_TOKEN_EXPIRE_MINUTES (default 60)
- HTC_DB_URL (default sqlite:///./data/htc.db)

## Notes
- This system is for **bounded simulation and optimization**. It is not a self-modifying agent.
- Replace in-memory rate limiting + job runner with Redis + Celery/RQ for production scale.
