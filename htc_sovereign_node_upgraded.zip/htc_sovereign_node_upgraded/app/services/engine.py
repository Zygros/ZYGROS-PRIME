import hashlib
import time
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional

import numpy as np
import scipy.special as sp


@dataclass
class EpochRecord:
    epoch: int
    state: float
    p: float
    r: float
    a: float
    entropy: float
    truth_hash: str
    t: float


class MegaCodexEngine:
    """Bounded simulation engine with SHA-512 truth layer per epoch."""

    def __init__(self, sovereign_constant: float = 1e6, clamp_x: float = 25.0, seed: Optional[int] = None):
        self.constant = float(sovereign_constant)
        self.clamp_x = float(clamp_x)
        self.rng = np.random.default_rng(seed)

    def _perceive(self, x: float) -> float:
        x = float(np.clip(x, -self.clamp_x, self.clamp_x))
        return float(np.tanh(x * np.pi) + np.sin(x))

    def _reason(self, x: float) -> float:
        x = float(np.clip(x, -10.0, 10.0))
        ax = abs(x)
        num = float(sp.gamma(ax + 1.0))
        den = float(ax + 1e-9)
        val = num / den
        return float(np.clip(val, -self.constant, self.constant))

    def _act(self, x: float) -> float:
        x = float(np.clip(x, -20.0, 20.0))
        base = float(np.clip(np.exp(x), 0.0, self.constant))
        noise = float(self.rng.normal(1.0, 0.01))
        return float(np.clip(base * noise, 0.0, self.constant))

    def _reflect_entropy(self, vec: np.ndarray) -> float:
        v = np.asarray(vec, dtype=np.float64)
        v = np.nan_to_num(v, nan=0.0, posinf=self.constant, neginf=-self.constant)
        eps = 1e-12
        return float(-np.sum(v * np.log(np.abs(v) + eps)))

    def _truth_layer(self, payload: Dict[str, Any]) -> str:
        canonical = repr(sorted(payload.items())).encode("utf-8")
        return hashlib.sha512(canonical).hexdigest()

    def run_simulation(self, initial_state: float, max_depth: int, stop_threshold: Optional[float] = None) -> List[Dict[str, Any]]:
        state = float(initial_state)
        history: List[EpochRecord] = []

        for epoch in range(int(max_depth)):
            t = time.time()
            p = self._perceive(state)
            r = self._reason(p)
            a = self._act(r)
            entropy = self._reflect_entropy(np.array([p, r, a], dtype=np.float64))

            next_state = (state * 0.01) + (entropy * 0.99)
            if not np.isfinite(next_state):
                next_state = 0.0
            state = float(np.clip(next_state, -self.constant, self.constant))

            truth_payload = {"epoch": epoch, "state": state, "p": p, "r": r, "a": a, "entropy": entropy, "t": t}
            truth_hash = self._truth_layer(truth_payload)

            history.append(EpochRecord(epoch=epoch, state=state, p=p, r=r, a=a, entropy=entropy, truth_hash=truth_hash, t=t))

            if stop_threshold is not None and abs(state) <= float(stop_threshold):
                break

        return [asdict(x) for x in history]
