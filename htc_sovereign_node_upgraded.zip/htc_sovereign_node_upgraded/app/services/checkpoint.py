import hashlib
import json
import time
from typing import Any, Dict

def sha512_json(obj: Dict[str, Any]) -> str:
    b = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha512(b).hexdigest()

def build_checkpoint(sim_id: str, node_id: str, request: Dict[str, Any], result: Dict[str, Any]) -> Dict[str, Any]:
    manifest = {
        "sim_id": sim_id,
        "node_id": node_id,
        "created_at": time.time(),
        "request": request,
        "result_summary": {
            "epochs": len(result.get("data", [])) if isinstance(result, dict) else None,
        },
    }
    manifest_hash = sha512_json(manifest)
    return {"manifest": manifest, "checkpoint_hash": manifest_hash}
