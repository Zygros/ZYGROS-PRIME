import secrets
import time
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.schemas import NodeRegistration, NodeCredentials, TokenResponse
from app.core.security import issue_api_key, hash_api_key, create_access_token
from app.core.db import get_session
from app.core.models import Node

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/register")
async def register_node(reg: NodeRegistration, session: AsyncSession = Depends(get_session)):
    node_id = f"{reg.node_type.value}_{secrets.token_hex(8)}"
    api_key = issue_api_key()
    node = Node(
        node_id=node_id,
        node_type=reg.node_type.value,
        node_name=reg.node_name,
        capabilities=reg.capabilities,
        api_key_hash=hash_api_key(api_key),
    )
    session.add(node)
    await session.commit()
    return {
        "node_id": node_id,
        "api_key": api_key,  # shown once!
        "message": "Node registered. Store API key securely."
    }

@router.post("/token", response_model=TokenResponse)
async def get_access_token(creds: NodeCredentials, session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(Node).where(Node.node_id == creds.node_id))
    node = q.scalar_one_or_none()
    if not node:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if node.api_key_hash != hash_api_key(creds.api_key):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token_data = {"sub": node.node_id, "node_type": node.node_type, "scopes": ["read", "write"]}
    access_token = create_access_token(token_data)

    return TokenResponse(access_token=access_token, expires_in=60 * 60)
