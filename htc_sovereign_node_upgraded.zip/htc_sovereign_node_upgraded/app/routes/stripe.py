import time
from fastapi import APIRouter, Request, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import verify_token, verify_api_key, rate_limiter, hash_api_key
from app.core.db import get_session
from app.core.models import Node, MetricEvent
from sqlalchemy import select

router = APIRouter(prefix="/stripe", tags=["Stripe (Optional)"])

@router.post("/webhook")
async def stripe_webhook(
    request: Request,
    token_data: dict = Depends(verify_token),
    x_api_key: str = Depends(verify_api_key),
    session: AsyncSession = Depends(get_session),
):
    """
    Minimal Stripe webhook adapter stub.
    - DOES NOT verify Stripe signatures (add in production).
    - Normalizes event into MetricEvent for HTC metrics pipelines.
    """
    node_id = token_data["sub"]
    rate_limiter(node_id, max_requests=60)

    q = await session.execute(select(Node).where(Node.node_id == node_id))
    node = q.scalar_one_or_none()
    if not node or node.api_key_hash != hash_api_key(x_api_key):
        raise HTTPException(status_code=403, detail="Token/API key mismatch")

    payload = await request.json()
    event_type = str(payload.get("type", "stripe.unknown"))

    ev = MetricEvent(node_id=node_id, event_type=event_type, payload=payload, ts=time.time())
    session.add(ev)
    await session.commit()

    return {"received": True, "event_type": event_type}
