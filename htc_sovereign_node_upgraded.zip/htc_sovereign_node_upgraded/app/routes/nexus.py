import time
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.schemas import DataPayload
from app.core.security import verify_token, verify_api_key, rate_limiter, hash_api_key
from app.core.db import get_session
from app.core.models import Node, MetricEvent
from sqlalchemy import select

router = APIRouter(prefix="/nexus", tags=["Nexus"])

@router.post("/data/write")
async def write_metric_event(
    payload: DataPayload,
    token_data: dict = Depends(verify_token),
    x_api_key: str = Depends(verify_api_key),
    session: AsyncSession = Depends(get_session),
):
    node_id = token_data["sub"]
    rate_limiter(node_id)

    # verify api key matches node
    q = await session.execute(select(Node).where(Node.node_id == node_id))
    node = q.scalar_one_or_none()
    if not node or node.api_key_hash != hash_api_key(x_api_key):
        raise HTTPException(status_code=403, detail="Token/API key mismatch")

    event_type = str(payload.metadata.get("event_type", "generic"))
    ev = MetricEvent(node_id=node_id, event_type=event_type, payload=payload.content, ts=time.time())
    session.add(ev)
    await session.commit()

    return {"status": "success", "node_id": node_id, "event_type": event_type}

@router.get("/data/recent")
async def recent_events(
    token_data: dict = Depends(verify_token),
    session: AsyncSession = Depends(get_session),
    limit: int = 50
):
    node_id = token_data["sub"]
    rate_limiter(node_id, max_requests=120)

    # very simple query; for production add filters + pagination
    q = await session.execute(
        select(MetricEvent).where(MetricEvent.node_id == node_id).order_by(MetricEvent.ts.desc()).limit(min(limit, 500))
    )
    rows = q.scalars().all()
    return {
        "node_id": node_id,
        "count": len(rows),
        "events": [{"event_type": r.event_type, "payload": r.payload, "ts": r.ts} for r in rows]
    }
