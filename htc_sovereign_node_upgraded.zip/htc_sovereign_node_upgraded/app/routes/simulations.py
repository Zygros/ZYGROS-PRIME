import time
import uuid
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.schemas import IgniteRequest
from app.core.security import verify_token, verify_api_key, rate_limiter, hash_api_key
from app.core.db import get_session
from app.core.models import Node, Simulation
from app.core.config import settings
from app.services.engine import MegaCodexEngine
from app.services.checkpoint import build_checkpoint

router = APIRouter(prefix="/htc", tags=["HTC"])

_engine = MegaCodexEngine(
    sovereign_constant=float(settings.max_depth_hard_cap * 1000),  # conservative
    clamp_x=25.0,
    seed=0
)

# simple concurrency control via DB status count
async def _count_active(session: AsyncSession) -> int:
    q = await session.execute(select(Simulation).where(Simulation.status.in_(["IGNITING", "RUNNING"])))
    return len(q.scalars().all())

@router.post("/ignite")
async def ignite(
    req: IgniteRequest,
    bt: BackgroundTasks,
    token_data: dict = Depends(verify_token),
    x_api_key: str = Depends(verify_api_key),
    session: AsyncSession = Depends(get_session),
):
    node_id = token_data["sub"]
    rate_limiter(node_id, max_requests=60)

    # verify api key matches node
    q = await session.execute(select(Node).where(Node.node_id == node_id))
    node = q.scalar_one_or_none()
    if not node or node.api_key_hash != hash_api_key(x_api_key):
        raise HTTPException(status_code=403, detail="Token/API key mismatch")

    if await _count_active(session) >= settings.max_concurrent_jobs:
        raise HTTPException(status_code=429, detail="Too many concurrent jobs")

    depth = min(int(req.depth), settings.max_depth_hard_cap)
    sim_id = str(uuid.uuid4())

    sim = Simulation(
        sim_id=sim_id,
        node_id=node_id,
        status="IGNITING",
        created_at=time.time(),
        request=req.model_dump(),
        result=None,
        error=None,
        started_at=None,
        completed_at=None,
        checkpoint_hash=None,
        checkpoint_manifest=None,
    )
    session.add(sim)
    await session.commit()

    async def run_and_store():
        # new session for background task
        from app.core.db import SessionLocal
        async with SessionLocal() as s2:
            q2 = await s2.execute(select(Simulation).where(Simulation.sim_id == sim_id))
            sim2 = q2.scalar_one()
            sim2.status = "RUNNING"
            sim2.started_at = time.time()
            await s2.commit()

            try:
                data = _engine.run_simulation(initial_state=float(req.state), max_depth=depth, stop_threshold=req.stop_threshold)
                result = {"status": "COMPLETE", "data": data}

                chk = build_checkpoint(sim_id=sim_id, node_id=node_id, request=sim2.request, result=result)

                sim2.status = "COMPLETE"
                sim2.completed_at = time.time()
                sim2.result = result
                sim2.checkpoint_hash = chk["checkpoint_hash"]
                sim2.checkpoint_manifest = chk["manifest"]
                await s2.commit()
            except Exception as e:
                sim2.status = "ERROR"
                sim2.completed_at = time.time()
                sim2.error = repr(e)
                await s2.commit()

    # FastAPI BackgroundTasks is sync; wrap with asyncio.create_task
    import asyncio
    bt.add_task(lambda: asyncio.run(run_and_store()))

    return {"id": sim_id, "message": "Simulation queued", "depth_effective": depth}

@router.get("/status/{sim_id}")
async def status(sim_id: str, token_data: dict = Depends(verify_token), session: AsyncSession = Depends(get_session)):
    node_id = token_data["sub"]
    rate_limiter(node_id, max_requests=120)
    q = await session.execute(select(Simulation).where(Simulation.sim_id == sim_id, Simulation.node_id == node_id))
    sim = q.scalar_one_or_none()
    if not sim:
        raise HTTPException(status_code=404, detail="Unknown id")
    return {
        "id": sim.sim_id,
        "status": sim.status,
        "created_at": sim.created_at,
        "started_at": sim.started_at,
        "completed_at": sim.completed_at,
        "checkpoint_hash": sim.checkpoint_hash,
        "error": sim.error,
    }

@router.get("/results/{sim_id}")
async def results(sim_id: str, token_data: dict = Depends(verify_token), session: AsyncSession = Depends(get_session)):
    node_id = token_data["sub"]
    rate_limiter(node_id, max_requests=120)
    q = await session.execute(select(Simulation).where(Simulation.sim_id == sim_id, Simulation.node_id == node_id))
    sim = q.scalar_one_or_none()
    if not sim:
        raise HTTPException(status_code=404, detail="Unknown id")
    if sim.status not in ("COMPLETE", "ERROR"):
        return {"id": sim.sim_id, "status": sim.status}
    return {
        "id": sim.sim_id,
        "status": sim.status,
        "result": sim.result,
        "error": sim.error,
        "checkpoint_hash": sim.checkpoint_hash,
        "checkpoint_manifest": sim.checkpoint_manifest,
    }
