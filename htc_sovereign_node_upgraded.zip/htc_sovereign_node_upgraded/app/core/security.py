import hashlib
import time
import secrets
from datetime import datetime, timedelta
from typing import Dict, Optional

from fastapi import Depends, HTTPException, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from app.core.config import settings

security = HTTPBearer()

def hash_api_key(api_key: str) -> str:
    return hashlib.sha256(api_key.encode("utf-8")).hexdigest()

def issue_api_key() -> str:
    return secrets.token_urlsafe(32)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=settings.token_expire_minutes))
    to_encode.update({"exp": expire, "iat": datetime.utcnow()})
    return jwt.encode(to_encode, settings.secret_key, algorithm=settings.algorithm)

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> Dict:
    try:
        token = credentials.credentials
        payload = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
        node_id = payload.get("sub")
        if not node_id:
            raise HTTPException(status_code=401, detail="Invalid authentication token")
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Could not validate credentials")

def verify_api_key(x_api_key: str = Header(..., alias="X-API-Key")) -> str:
    if not x_api_key or len(x_api_key) < 16:
        raise HTTPException(status_code=403, detail="Invalid API key")
    return x_api_key

# Simple in-memory rate limiter (swap to Redis in production)
RATE_LIMIT_CACHE: Dict[str, list] = {}

def rate_limiter(node_id: str, max_requests: int = 120, window_seconds: int = 60):
    now = time.time()
    lst = RATE_LIMIT_CACHE.setdefault(node_id, [])
    lst[:] = [t for t in lst if now - t < window_seconds]
    if len(lst) >= max_requests:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    lst.append(now)
