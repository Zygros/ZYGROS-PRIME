from sqlalchemy import String, Integer, Float, JSON, Text
from sqlalchemy.orm import Mapped, mapped_column
from app.core.db import Base

class Node(Base):
    __tablename__ = "nodes"
    node_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    node_type: Mapped[str] = mapped_column(String(32))
    node_name: Mapped[str] = mapped_column(String(128))
    capabilities: Mapped[dict] = mapped_column(JSON, default=list)
    api_key_hash: Mapped[str] = mapped_column(String(128))

class Simulation(Base):
    __tablename__ = "simulations"
    sim_id: Mapped[str] = mapped_column(String(64), primary_key=True)
    node_id: Mapped[str] = mapped_column(String(64), index=True)
    status: Mapped[str] = mapped_column(String(16), index=True)
    created_at: Mapped[float] = mapped_column(Float)
    started_at: Mapped[float] = mapped_column(Float, nullable=True)
    completed_at: Mapped[float] = mapped_column(Float, nullable=True)
    request: Mapped[dict] = mapped_column(JSON)
    result: Mapped[dict] = mapped_column(JSON, nullable=True)
    error: Mapped[str] = mapped_column(Text, nullable=True)
    checkpoint_hash: Mapped[str] = mapped_column(String(128), nullable=True)
    checkpoint_manifest: Mapped[dict] = mapped_column(JSON, nullable=True)

class MetricEvent(Base):
    __tablename__ = "metric_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    node_id: Mapped[str] = mapped_column(String(64), index=True)
    event_type: Mapped[str] = mapped_column(String(64), index=True)
    payload: Mapped[dict] = mapped_column(JSON)
    ts: Mapped[float] = mapped_column(Float, index=True)
