import os
from dataclasses import dataclass

@dataclass(frozen=True)
class Settings:
    secret_key: str = os.getenv("HTC_SECRET_KEY", "dev-only-secret")
    algorithm: str = "HS256"
    token_expire_minutes: int = int(os.getenv("HTC_TOKEN_EXPIRE_MINUTES", "60"))

    max_depth_hard_cap: int = int(os.getenv("HTC_MAX_DEPTH", "500"))
    max_concurrent_jobs: int = int(os.getenv("HTC_MAX_CONCURRENT", "16"))

    db_url: str = os.getenv("HTC_DB_URL", "sqlite+aiosqlite:///./data/htc.db")

settings = Settings()
