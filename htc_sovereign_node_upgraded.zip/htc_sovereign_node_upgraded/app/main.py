import time
from fastapi import FastAPI

from app.routes.auth import router as auth_router
from app.routes.nexus import router as nexus_router
from app.routes.simulations import router as htc_router
from app.routes.stripe import router as stripe_router
from app.core.init_db import main as init_db_main

app = FastAPI(title="HTC Sovereign Node (Upgraded)", version="2.0.0")

@app.on_event("startup")
async def startup():
    # initialize tables
    await init_db_main()

@app.get("/health")
async def health():
    return {"status": "operational", "ts": time.time()}

app.include_router(auth_router)
app.include_router(nexus_router)
app.include_router(htc_router)
app.include_router(stripe_router)
