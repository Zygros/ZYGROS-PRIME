import hashlib
import json
import time
from typing import Any, Dict

def sha512_json(obj: Dict[str, Any]) -> str:
    b = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha512(b).hexdigest()


    request_hash = sha512_json(request)
    result_hash = sha512_json(result)


def build_checkpoint(sim_id: str, node_id: str, request: Dict[str, Any], result: Dict[str, Any]) -> Dict[str, Any]:
    manifest = {
        "schema_version": "htc-checkpoint-1",
        "sim_id": sim_id,
        "node_id": node_id,
        "created_at": time.time(),
        "request": request,
        "request_hash": request_hash,
        "result_summary": {
            "result_hash": result_hash,
            "epochs": len(result.get("data", [])) if isinstance(result, dict) else None,
        },
    }
    manifest_hash = sha512_json(manifest)
    return {"manifest": manifest, "checkpoint_hash": manifest_hash}
