import hashlib
import json
import time
from dataclasses import dataclass
from typing import Dict, List, Tuple

# Hard allowlists (edit as needed)
ALLOWED_SCOPES = {
    "pricing",
    "onboarding",
    "copy",
    "feature-gating",
    "analytics",
    "deployment",
    "integration",
}

# Sliding-window recursion governor (in-memory; swap to Redis/Postgres for production)
# key: (node_id, domain) -> list[timestamps]
_RECURSION: Dict[Tuple[str, str], List[float]] = {}

def metric_def_hash(metric_definition: dict) -> str:
    b = json.dumps(metric_definition, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(b).hexdigest()

def enforce_scope(scope: str) -> None:
    if scope not in ALLOWED_SCOPES:
        raise ValueError(f"Scope '{scope}' not allowed")

def enforce_recursion(node_id: str, domain: str, max_depth_per_window: int, window_seconds: int) -> None:
    now = time.time()
    key = (node_id, domain)
    lst = _RECURSION.setdefault(key, [])
    lst[:] = [t for t in lst if now - t < window_seconds]
    if len(lst) >= max_depth_per_window:
        raise ValueError("Recursion limit reached for window")
    lst.append(now)
