from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from enum import Enum

class NodeType(str, Enum):
    GEMINI = "gemini"
    CLAUDE = "claude"
    PERPLEXITY = "perplexity"
    OPENAI = "openai"
    GROK = "grok"
    OTHER = "other"

class NodeRegistration(BaseModel):
    node_type: NodeType
    node_name: str
    capabilities: List[str] = []

class NodeCredentials(BaseModel):
    node_id: str
    node_type: NodeType
    api_key: str = Field(..., min_length=16)

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class IgniteRequest(BaseModel):
    state: float = 0.1
    depth: int = Field(50, ge=1)
    stop_threshold: Optional[float] = None

    # Governance: required experiment metadata (machine-enforced)
    domain: str = Field(..., description="Allowed domain (pricing/onboarding/copy/feature-gating/etc).")
    scope: str = Field(..., description="Declared scope. Must be allowed by governor.")
    primary_metric: str = Field(..., description="Primary metric name.")
    guardrails: List[str] = Field(..., min_length=1, description="Guardrail metric names (veto metrics).")
    metric_definition: Dict[str, Any] = Field(..., description="Immutable metric definition blob (hashed & locked).")

    metadata: Dict[str, Any] = {}


class DataPayload(BaseModel):
    content: Dict[str, Any]
    metadata: Dict[str, Any] = {}
