
# HTC Curl Examples

## 1) Register node
```bash
curl -X POST http://localhost:8000/auth/register   -H "Content-Type: application/json"   -d '{"node_type":"other","node_name":"local-node","capabilities":["htc","metrics"]}'
```

## 2) Get token
```bash
curl -X POST http://localhost:8000/auth/token   -H "Content-Type: application/json"   -d '{"node_id":"YOUR_NODE_ID","node_type":"other","api_key":"YOUR_API_KEY"}'
```

## 3) Ignite HTC (governed)
```bash
curl -X POST http://localhost:8000/htc/ignite   -H "Content-Type: application/json"   -H "Authorization: Bearer YOUR_JWT"   -H "X-API-Key: YOUR_API_KEY"   -d '{
    "state": 0.1,
    "depth": 50,
    "domain": "pricing",
    "scope": "pricing",
    "primary_metric": "net_mrr_delta",
    "guardrails": ["refund_rate", "chargeback_rate", "logo_churn"],
    "metric_definition": {
      "primary": {"name":"net_mrr_delta","window_days":7},
      "guardrails": [
        {"name":"refund_rate","max_delta":0.01},
        {"name":"chargeback_rate","max_delta":0.001},
        {"name":"logo_churn","max_delta":0.01}
      ]
    },
    "metadata": {"note":"test run"}
  }'
```
