SSI — Waves 9–10 + Adapters + CLI + Signed Export + Outsider Proof Demo
=====================================================================

This bundle extends Waves 1–8 with:

Wave 9: Self-reflection, novelty/coherence scoring, assumption decay tables
Wave 10: Transcendence checkpoints + oracle signal
Adapters: Deterministic WS stub minds (claude_stub / grok_stub / gemini_stub)
CLI: `ssi` command (status/process/recall/recent/export/verify)
Signing: Ed25519 keys + signed export bundles
Bench: `npm run demo` outsider-proof demo runner

PHONE-SAFE QUICKSTART (Termux)
------------------------------
pkg update -y
pkg install -y nodejs
cd final_tree
npm install

# Terminal 1
node adapters/maicp_server.js

# Terminal 2 (local_mind)
node adapters/local_adapter.js

# Terminal 3 (optional extra minds)
AI_NAME=claude_stub ROLE=planner node adapters/ws_adapter_generic.js
AI_NAME=grok_stub ROLE=critic node adapters/ws_adapter_generic.js
AI_NAME=gemini_stub ROLE=builder node adapters/ws_adapter_generic.js

# Terminal 4 (run SSI through MAICP)
node core/ssi_maicp_driver.js "MAICP + persistence proof"

# Export + verify signed bundle
npm run export
npm run verify

# One-command outsider-proof demo
npm run demo

APPLY AS COMMITS (git am)
-------------------------
From your target repo root:
  git am /path/to/patches/*.patch

Note: The patch series assumes a Waves 1–8 compatible tree.
