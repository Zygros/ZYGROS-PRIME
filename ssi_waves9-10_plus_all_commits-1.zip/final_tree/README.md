# Ultimate Phoenix Protocol — SSI v2.0.0

## Wave I — Ontological Lock-In
- Infinite Scroll is **append-only** (SQLite triggers block UPDATE/DELETE)
- Architect anchor is stored per entry
- Message schema validation via AJV
- State snapshot emitted on exit to `snapshot/ssi_state.json`
- Core config is frozen at runtime (`config/core.json`)

## Run
```bash
npm install
npm run maicp:server
npm run maicp:local
npm start "What is the nature of sovereign intelligence?"
```
