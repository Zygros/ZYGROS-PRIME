const WebSocket = require('ws');

const ws = new WebSocket('ws://localhost:8080');

ws.on('open', () => {
  ws.send(JSON.stringify({ type: 'register', ai_name: 'local_mind', role: 'skeptic' }));

  // Wave IV: heartbeat for node health tracking
  setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'heartbeat', ai_name: 'local_mind' }));
    }
  }, 4000);
});

ws.on('message', (raw) => {
  let data;
  try { data = JSON.parse(raw.toString()); } catch { return; }

  if (data.type === 'user_message') {
    ws.send(JSON.stringify({
      type: 'ai_response',
      in_reply_to: data.id,
      responding_ai: 'local_mind',
      timestamp: new Date().toISOString(),
      role: 'skeptic',
      content: `Local mind perspective on: ${data.content}`,
      confidence: 0.80
    }));
  }
});
