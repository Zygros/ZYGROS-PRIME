const WebSocket = require('ws');
const { validateMessage } = require('../lib/validate');
const fs = require('fs');
const path = require('path');

const wss = new WebSocket.Server({ port: 8080 });

// ai_name -> { ws, last_seen, status, role }
const clients = new Map();

// msg_id -> { createdAt, responses: [], min_quorum }
const inbox = new Map();

// Wave V: deliberation log (jsonl)
const LOG_DIR = path.join(process.cwd(), 'logs');
const LOG_FILE = path.join(LOG_DIR, 'maicp_deliberation.jsonl');
function logDeliberation(event) {
  try {
    if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
    fs.appendFileSync(LOG_FILE, JSON.stringify(event) + '\n', 'utf8');
  } catch (_) {
    // best-effort
  }
}

// Wave IV: node health + graceful loss
const HEARTBEAT_TTL_MS = 15000;
setInterval(() => {
  const now = Date.now();
  for (const [name, meta] of clients) {
    if (!meta || !meta.ws) { clients.delete(name); continue; }
    if (meta.ws.readyState !== WebSocket.OPEN) { clients.delete(name); continue; }
    if (meta.last_seen && (now - meta.last_seen) > HEARTBEAT_TTL_MS) {
      try { meta.ws.terminate(); } catch (_) {}
      clients.delete(name);
    }
  }
}, 3000);

console.log('📡 MAICP Sync Server running on ws://localhost:8080');

function broadcast(obj) {
  const payload = JSON.stringify(obj);
  for (const [, meta] of clients) {
    if (meta.ws && meta.ws.readyState === WebSocket.OPEN) meta.ws.send(payload);
  }
}

wss.on('connection', (ws) => {
  ws.on('message', (raw) => {
    let data;
    try { data = JSON.parse(raw.toString()); } catch { return; }

    const v = validateMessage(data);
    if (!v.ok) {
      ws.send(JSON.stringify({ type: 'error', error: v.error }));
      return;
    }

    if (data.type === 'register') {
      clients.set(data.ai_name, { ws, last_seen: Date.now(), status: 'connected', role: data.role || 'general' });
      console.log(`🤖 Registered AI: ${data.ai_name}`);
      logDeliberation({
        type: 'register',
        timestamp: new Date().toISOString(),
        ai_name: data.ai_name,
        role: data.role || 'general'
      });
      ws.send(JSON.stringify({ type: 'registered', ai_name: data.ai_name }));
      return;
    }

    if (data.type === 'heartbeat') {
      const meta = clients.get(data.ai_name);
      if (meta) meta.last_seen = Date.now();
      return;
    }

    if (data.type === 'user_message') {
      // Wave IV: quorum + response timeouts
      const min_quorum = typeof data.min_quorum === 'number' ? data.min_quorum : 2;
      inbox.set(data.id, { createdAt: Date.now(), responses: [], min_quorum });
      console.log(`🧠 Broadcast msg ${data.id} from ${data.source_ai}`);
      logDeliberation({
        type: 'user_message',
        timestamp: new Date().toISOString(),
        id: data.id,
        source_ai: data.source_ai,
        min_quorum,
        content: data.content
      });
      broadcast(data);
      return;
    }

    if (data.type === 'ai_response') {
      const slot = inbox.get(data.in_reply_to);
      if (slot) {
        const meta = clients.get(data.responding_ai);
        const enriched = {
          ...data,
          role: data.role || (meta ? meta.role : 'general')
        };
        slot.responses.push(enriched);
        console.log(`✅ Response from ${data.responding_ai} for ${data.in_reply_to}`);
        logDeliberation({
          type: 'ai_response',
          timestamp: new Date().toISOString(),
          in_reply_to: data.in_reply_to,
          responding_ai: data.responding_ai,
          role: enriched.role,
          confidence: typeof enriched.confidence === 'number' ? enriched.confidence : null,
          content: enriched.content
        });
      }
      return;
    }

    if (data.type === 'get_responses') {
      const slot = inbox.get(data.in_reply_to);
      const timeout_ms = typeof data.timeout_ms === 'number' ? data.timeout_ms : 5000;
      const age_ms = slot ? (Date.now() - slot.createdAt) : 0;

      const ready = !!slot && (slot.responses.length >= slot.min_quorum || age_ms >= timeout_ms);
      ws.send(JSON.stringify({
        type: 'responses',
        in_reply_to: data.in_reply_to,
        ready,
        responses: slot ? slot.responses : []
      }));
      return;
    }
  });

  ws.on('close', () => {
    // Graceful node loss
    for (const [name, meta] of clients) {
      if (meta.ws === ws) clients.delete(name);
    }
  });
});
