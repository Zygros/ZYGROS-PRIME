process.env.AI_NAME='claude_stub'; process.env.ROLE='planner'; require('./ws_adapter_generic');
