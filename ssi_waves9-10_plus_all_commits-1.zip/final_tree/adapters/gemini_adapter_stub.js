process.env.AI_NAME='gemini_stub'; process.env.ROLE='builder'; require('./ws_adapter_generic');
