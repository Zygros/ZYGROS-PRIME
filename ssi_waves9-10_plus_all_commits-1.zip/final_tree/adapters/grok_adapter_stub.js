process.env.AI_NAME='grok_stub'; process.env.ROLE='critic'; require('./ws_adapter_generic');
