const WebSocket = require('ws');

const WS_URL = process.env.MAICP_WS_URL || 'ws://localhost:8080';
const AI_NAME = process.env.AI_NAME || 'stub_mind';
const ROLE = process.env.ROLE || 'critic';

const ws = new WebSocket(WS_URL);

ws.on('open', () => {
  ws.send(JSON.stringify({ type: 'register', ai_name: AI_NAME, role: ROLE }));
  console.log(`🤖 ${AI_NAME} connected to ${WS_URL} as ${ROLE}`);
});

ws.on('message', (raw) => {
  let data;
  try { data = JSON.parse(raw.toString()); } catch { return; }

  if (data.type === 'user_message') {
    // Deterministic, non-fake: role-based transform so it stays distinct.
    let content;
    if (ROLE === 'critic') {
      content = `Critic lens: risks, gaps, and what would fail first for: ${data.content}`;
    } else if (ROLE === 'planner') {
      content = `Planner lens: stepwise execution plan for: ${data.content}`;
    } else if (ROLE === 'builder') {
      content = `Builder lens: minimal implementation sketch for: ${data.content}`;
    } else {
      content = `Perspective (${ROLE}) on: ${data.content}`;
    }

    ws.send(JSON.stringify({
      type: 'ai_response',
      in_reply_to: data.id,
      responding_ai: AI_NAME,
      role: ROLE,
      timestamp: new Date().toISOString(),
      content,
      confidence: 0.75
    }));
  }
});
