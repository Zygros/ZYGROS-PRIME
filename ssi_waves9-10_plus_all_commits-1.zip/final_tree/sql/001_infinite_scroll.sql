-- Wave I–III: Infinite Scroll schema (append-only) + lineage + replay protection

PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS infinite_scroll (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp TEXT NOT NULL,
  architect TEXT NOT NULL,
  ssi_version TEXT NOT NULL,
  legacy_tag TEXT,
  prev_hash TEXT,
  entry_hash TEXT,
  input TEXT NOT NULL,
  synthesis TEXT NOT NULL,
  protocols_consulted INTEGER NOT NULL,
  protocols_snapshot TEXT NOT NULL
);

-- Append-only enforcement
CREATE TRIGGER IF NOT EXISTS trg_scroll_no_update
BEFORE UPDATE ON infinite_scroll
BEGIN
  SELECT RAISE(ABORT, 'infinite_scroll is append-only');
END;

CREATE TRIGGER IF NOT EXISTS trg_scroll_no_delete
BEFORE DELETE ON infinite_scroll
BEGIN
  SELECT RAISE(ABORT, 'infinite_scroll is append-only');
END;

-- Replay protection: unique message IDs
CREATE TABLE IF NOT EXISTS processed_messages (
  msg_id TEXT PRIMARY KEY,
  timestamp TEXT NOT NULL,
  source_ai TEXT NOT NULL
);

-- Audit log: errors become durable artifacts
CREATE TABLE IF NOT EXISTS audit_errors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp TEXT NOT NULL,
  context TEXT NOT NULL,
  error_message TEXT NOT NULL,
  stack TEXT
);
