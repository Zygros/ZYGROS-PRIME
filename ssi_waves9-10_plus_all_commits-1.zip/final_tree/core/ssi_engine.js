// 🔥 SUPER SOVEREIGN INTELLIGENCE (SSI) - CORE ENGINE 🔥
// The Ultimate Phoenix Protocol - Final Form
// Architect: Justin Conzet
// "AGI is an Architecture Problem, not a Compute Problem"

const SuperSovereignIntelligence = require('../lib/ssi');
const { validateMessage } = require('../lib/validate');
const { insertScrollEntry } = require('../lib/scroll');
const { markProcessed } = require('../lib/replay');
const { logError } = require('../lib/audit');

function processInput(runtime, input, opts = {}) {
  const msg_id = opts.msg_id || `local_${Date.now()}`;
  try {
    validateMessage({
    type: 'user_message',
      id: msg_id,
    timestamp: new Date().toISOString(),
    source_ai: 'ssi',
    user_id: 'justin_conzet',
    content: input
    });

    // Replay protection (Wave III)
    markProcessed(runtime.db, msg_id, 'ssi');
  } catch (err) {
    logError(runtime.db, { stage: 'validate_or_dedupe', msg_id }, err);
    throw err;
  }

  const perspectives = [];
  for (const [, p] of runtime.protocols) {
    if (typeof p.transform === 'function') {
      perspectives.push({ protocol: p.name, output: p.transform(input) });
    } else {
      perspectives.push({ protocol: p.name, analysis: `${p.name} perspective on: ${input}` });
    }
  }

  const synthesis = {
    summary: `Collective output from ${perspectives.length} sovereign protocols`,
    perspectives,
    consensus: 'Differentiated protocol outputs preserved'
  };

  // Append-only write (Wave I)
  try {
    insertScrollEntry(runtime.db, {
      timestamp: new Date().toISOString(),
      architect: runtime.base.architect,
      ssi_version: runtime.base.version,
      legacy_tag: opts.legacy_tag || null,
      input,
      synthesis: JSON.stringify(synthesis),
      protocols_consulted: perspectives.length,
      protocols_snapshot: JSON.stringify([...runtime.protocols.values()])
    });
  } catch (err) {
    logError(runtime.db, { stage: 'scroll_insert', msg_id }, err);
    throw err;
  }

  return synthesis;
}

if (require.main === module) {
  const runtime = SuperSovereignIntelligence.createRuntime({ architect: 'Justin Conzet' });

  console.log('🔥 SUPER SOVEREIGN INTELLIGENCE - INITIALIZING 🔥');
  console.log(`👑 Architect: ${runtime.base.architect}`);
  console.log(`⚜️ Version: ${runtime.base.version}`);
  console.log(`✅ SSI INITIALIZATION COMPLETE`);
  console.log(`📊 Active Protocols: ${runtime.protocols.size}`);

  const args = process.argv.slice(2);
  const legacyArg = args.find(a => a.startsWith('--legacy='));
  const legacy_tag = legacyArg ? legacyArg.split('=')[1] : null;
  const input = args.filter(a => !a.startsWith('--legacy=')).join(' ') || 'What is the nature of sovereign intelligence?';
  const synthesis = processInput(runtime, input, { legacy_tag });

  console.log('\n🧠 SYNTHESIS:');
  console.log(JSON.stringify(synthesis, null, 2));
}

module.exports = { processInput };
