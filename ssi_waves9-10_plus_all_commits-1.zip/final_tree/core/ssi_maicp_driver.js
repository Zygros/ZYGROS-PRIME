const SuperSovereignIntelligence = require('../lib/ssi');
const { processWithMAICP } = require('../lib/maicp_process');

async function main() {
  const input = process.argv.slice(2).join(' ').trim();
  if (!input) {
    console.log('Usage: node core/ssi_maicp_driver.js "your prompt"');
    process.exit(1);
  }

  const runtime = SuperSovereignIntelligence.createRuntime();
  const out = await processWithMAICP(runtime, input);
  console.log(JSON.stringify(out, null, 2));
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
