#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

# Terminal 1: server
node adapters/maicp_server.js &
SERVER_PID=$!

# Terminal 2: local adapter
node adapters/local_adapter.js &
ADAPTER_PID=$!

echo "MAICP server PID: $SERVER_PID"
echo "Local adapter PID: $ADAPTER_PID"
echo "Run a test in another shell:"
echo "  npm run maicp:test -- \"What is the nature of sovereign intelligence?\""

echo "Press Ctrl+C to stop."
wait
