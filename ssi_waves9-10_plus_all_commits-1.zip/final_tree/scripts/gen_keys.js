const { generateKeys } = require('../lib/signing');
const keys = generateKeys();
console.log(JSON.stringify(keys, null, 2));
