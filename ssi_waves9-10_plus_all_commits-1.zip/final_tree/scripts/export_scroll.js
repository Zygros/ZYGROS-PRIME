const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const dbPath = process.argv[2] || path.join(process.cwd(), 'data', 'infinite_scroll.db');
const outFile = process.argv[3] || path.join(process.cwd(), 'snapshot', `infinite_scroll_export_${Date.now()}.json`);
const limit = Number(process.argv[4] || 500);

const db = new Database(dbPath, { readonly: true });

const rows = db.prepare(`
  SELECT * FROM infinite_scroll
  ORDER BY id DESC
  LIMIT ?
`).all(limit);

fs.mkdirSync(path.dirname(outFile), { recursive: true });
fs.writeFileSync(outFile, JSON.stringify({ exported_at: new Date().toISOString(), db: dbPath, rows }, null, 2), 'utf8');
console.log(`✅ Exported ${rows.length} scroll entries to ${outFile}`);
