#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

pkg update -y
pkg install -y nodejs git

# Ensure native build toolchain for better-sqlite3
pkg install -y python make clang

npm install

echo "✅ Termux setup complete."
