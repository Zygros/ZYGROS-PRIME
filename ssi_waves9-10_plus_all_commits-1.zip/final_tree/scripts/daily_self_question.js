const SuperSovereignIntelligence = require('../lib/ssi');
const { shouldAsk, generateQuestion, listStaleAssumptions } = require('../lib/self_reflection');
const { insertScrollEntry } = require('../lib/scroll');

function main() {
  const runtime = SuperSovereignIntelligence.createRuntime();
  const now = new Date().toISOString();

  if (!shouldAsk(runtime.db, now)) {
    console.log('🜃🧠 No self-question due yet.');
    return;
  }

  const question = generateQuestion(runtime.db, now);
  const stale = listStaleAssumptions(runtime.db, now);

  const synthesis = {
    type: 'self_question',
    question,
    stale_assumptions: stale,
    next_action: 'Answer this question in your next SSI process() call.'
  };

  insertScrollEntry(runtime.db, {
    timestamp: now,
    architect: runtime.base.architect,
    ssi_version: runtime.base.version,
    legacy_tag: 'self_question',
    input: question,
    synthesis: JSON.stringify(synthesis),
    novelty_score: null,
    coherence_score: null,
    value_alignment_delta: null,
    checkpoint_tag: null,
    protocols_consulted: 1,
    protocols_snapshot: JSON.stringify([...runtime.protocols.values()])
  });

  console.log('🜂❓ Self-question written to Infinite Scroll:');
  console.log(question);
}

main();
