#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "🜂 Starting MAICP server + adapters (local proof demo)"

node adapters/maicp_server.js > /tmp/maicp_server.log 2>&1 &
SERVER_PID=$!
sleep 0.4

# Start three deterministic stub minds
AI_NAME=claude_stub ROLE=planner node adapters/ws_adapter_generic.js > /tmp/claude_stub.log 2>&1 &
C1=$!
AI_NAME=grok_stub ROLE=critic node adapters/ws_adapter_generic.js > /tmp/grok_stub.log 2>&1 &
C2=$!
AI_NAME=gemini_stub ROLE=builder node adapters/ws_adapter_generic.js > /tmp/gemini_stub.log 2>&1 &
C3=$!

sleep 0.6

echo "🧠 Running SSI MAICP driver"
node core/ssi_maicp_driver.js "Outsider-proof demo: multi-mind + persistent memory" | tee /tmp/ssi_run.json

echo "♾️ Inspecting DB"
node scripts/inspect_db.js | tee /tmp/inspect.json

echo "🔐 Exporting signed bundle"
node scripts/sign_export.js ssi_export_bundle | tee /tmp/export.json

echo "✅ Verifying signed bundle"
node scripts/verify_export.js ssi_export_bundle | tee /tmp/verify.json

echo "🧹 Shutting down"
kill $C1 $C2 $C3 $SERVER_PID || true

echo "DONE: ssi_export_bundle contains manifest + signature + db + json"
