const path = require('path');
const Database = require('better-sqlite3');

const dbPath = process.argv[2] || path.join(process.cwd(), 'data', 'infinite_scroll.db');
const limit = Number(process.argv[3] || 10);

const db = new Database(dbPath, { readonly: true });

const rows = db.prepare(`
  SELECT id, timestamp, architect, ssi_version, legacy_tag, entry_hash, prev_hash
  FROM infinite_scroll
  ORDER BY id DESC
  LIMIT ?
`).all(limit);

console.log(JSON.stringify({ db: dbPath, count: rows.length, rows }, null, 2));
