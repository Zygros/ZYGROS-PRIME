#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

# One-command launcher for MAICP v0 loop.
# Opens 3 processes in the same Termux session using background jobs.

node adapters/maicp_server.js &
SERVER_PID=$!

node adapters/local_adapter.js &
LOCAL_PID=$!

sleep 0.5

PROMPT=${1:-"What is the nature of sovereign intelligence?"}
node core/ssi_maicp_driver.js "$PROMPT"

kill $SERVER_PID $LOCAL_PID 2>/dev/null || true
