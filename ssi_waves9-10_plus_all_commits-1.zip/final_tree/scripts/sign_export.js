const SuperSovereignIntelligence = require('../lib/ssi');
const { exportScrollBundle } = require('../lib/export_bundle');

const runtime = SuperSovereignIntelligence.createRuntime({
  core: { db_file: process.env.SSI_DB_FILE || undefined }
});

const outDir = process.argv[2] || 'ssi_export_bundle';
const result = exportScrollBundle(runtime, outDir);
console.log(JSON.stringify(result, null, 2));
