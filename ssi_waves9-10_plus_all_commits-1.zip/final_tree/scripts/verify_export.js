const { verifyScrollBundle } = require('../lib/export_bundle');
const dir = process.argv[2] || 'ssi_export_bundle';
console.log(JSON.stringify(verifyScrollBundle(dir), null, 2));
