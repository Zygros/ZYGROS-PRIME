#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

DB=${1:-"data/infinite_scroll.db"}
OUTDIR=${2:-"backup"}

mkdir -p "$OUTDIR"
TS=$(date +%Y%m%d_%H%M%S)
cp -f "$DB" "$OUTDIR/infinite_scroll_$TS.db"
echo "✅ Backup written: $OUTDIR/infinite_scroll_$TS.db"
