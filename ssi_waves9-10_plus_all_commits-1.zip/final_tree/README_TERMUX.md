# SSI / MAICP v0 — Termux Quickstart (Waves 1–8)

This folder contains the **Wave 1–8 hardening commits** that make the Phoenix/SSI core *outsider-proof*:

- **Append-only Infinite Scroll** (SQLite + triggers)
- **Lineage hashing** (prev_hash + entry_hash)
- **Replay protection** (processed_messages)
- **Audit log** (durable error artifacts)
- **MAICP stabilization** (quorum, timeout, node health)
- **Deliberation upgrades** (role tags, disagreement surface, logs)
- **Protocol differentiation** (non-overlapping transforms)
- **End-to-end MAICP⇄SSI driver**

## 0) Termux setup

```sh
chmod +x scripts/termux_setup.sh scripts/run_wave_stack.sh
./scripts/termux_setup.sh
```

## 1) Run MAICP v0 loop (one command)

```sh
./scripts/run_wave_stack.sh "What is the nature of sovereign intelligence?"
```

You should see:
- MAICP server registering nodes
- a synthesis JSON printed by SSI
- a new row appended to `data/infinite_scroll.db`

## 2) Inspect / export the Infinite Scroll

```sh
node scripts/inspect_db.js
node scripts/export_scroll.js
```

## 3) Rebuild the DB schema from SQL (optional)

The canonical SQL is in:
- `sql/001_infinite_scroll.sql`

You can apply it manually with SQLite if needed.
