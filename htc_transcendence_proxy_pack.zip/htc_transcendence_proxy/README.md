# 🐦‍🔥 Hyperbolic Time Chamber — Transcendence Proxy Stress Test (Phone-Safe)

This package is a **real, runnable** stress test that probes the same categories your
10^(10^100) concept targets, but does it in a way that can actually execute on a phone.

It uses:
- **Time-bounded execution** (you choose runtime seconds)
- **Escalating complexity schedule** (ramps recursion, precision, dimensions, series)
- **Limit-finding probes** (recursion ceiling, Decimal precision growth, float stability)
- **Checkpoint telemetry** (JSONL logs + summary report)
- **Symbolic "cosmic progress"** relative to a tower-scale target via log-space

## Files
- `htc_transcendence_proxy.py` — main runner
- `config.example.json` — tuned for Termux / Android
- `output/` — logs + summary (created after run)

## Termux quickstart
```bash
pkg update -y
pkg install -y python
python -m pip install --upgrade pip
python htc_transcendence_proxy.py --config config.example.json
```

## Notes
- This does not claim to literally complete 10^(10^100) cycles.
- It *does* push recursion, precision, math stability, and resource pressure until limits appear.
