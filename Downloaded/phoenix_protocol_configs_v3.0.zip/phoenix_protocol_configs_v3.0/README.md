# Phoenix Protocol Configs v3.0 (Scaffold)

Copy `configs/` into your runtime config directory:
```bash
sudo mkdir -p /etc/phoenix_protocol
sudo cp -r configs/* /etc/phoenix_protocol/
```
