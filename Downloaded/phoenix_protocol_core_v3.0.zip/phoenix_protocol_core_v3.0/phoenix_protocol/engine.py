import json
import os
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List

from .modules.registry import ModuleRegistry


@dataclass
class PhoenixEngine:
    """Main entry point for the Phoenix Protocol scaffold."""
    config_path: str = "/etc/phoenix_protocol"
    registry: ModuleRegistry = field(default_factory=ModuleRegistry)
    configs: Dict[str, Any] = field(default_factory=dict)

    def load_configs(self) -> Dict[str, Any]:
        """Load all JSON configs under config_path into a nested dict."""
        root = self.config_path
        if not os.path.isdir(root):
            raise FileNotFoundError(f"Config path not found: {root}")

        loaded: Dict[str, Any] = {}
        for dirpath, _, filenames in os.walk(root):
            for name in filenames:
                if not name.lower().endswith(".json"):
                    continue
                full = os.path.join(dirpath, name)
                rel = os.path.relpath(full, root)
                key = rel.replace(os.sep, "/")
                with open(full, "r", encoding="utf-8") as fp:
                    loaded[key] = json.load(fp)
        self.configs = loaded
        return loaded

    def activate_protocols(self) -> List[str]:
        """Initialize all registered modules."""
        if not self.configs:
            # Best effort: load configs if present
            try:
                self.load_configs()
            except FileNotFoundError:
                self.configs = {}
        activated = []
        for module in self.registry.modules:
            module.configure(self.configs)
            module.start()
            activated.append(module.name)
        return activated

    def execute_domination_strategy(self) -> Dict[str, Any]:
        """Placeholder orchestration hook."""
        return {
            "status": "ok",
            "message": "Scaffold running. Implement business logic in modules/",
            "activated_modules": [m.name for m in self.registry.modules],
        }
