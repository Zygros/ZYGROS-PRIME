from typing import Dict, Any

class PhoenixModule:
    name: str = "base"

    def configure(self, configs: Dict[str, Any]) -> None:
        self.configs = configs

    def start(self) -> None:
        # Override in subclasses
        return

    def stop(self) -> None:
        # Override in subclasses
        return
