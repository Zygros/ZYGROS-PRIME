from dataclasses import dataclass, field
from typing import List

from .base import PhoenixModule
from .core.json_md_plugin import JsonMdPlugin
from .ai.metaprompt_engine import MetaPromptEngine
from .core.node_discovery import NodeDiscoveryEngine
from .business.dao_framework import DaoFramework
from .blockchain.nft_monetization import NftMonetizationLayer
from .business.passive_income import PassiveIncomeEngine
from .business.market_domination import MarketDominationSystem
from .core.quantum_integration import QuantumIntegrationLayer
from .ai.agi_coordination import AgiCoordinationFramework
from .core.reality_interface import RealityEditingInterface

@dataclass
class ModuleRegistry:
    modules: List[PhoenixModule] = field(default_factory=list)

    def __post_init__(self):
        # Register all modules (safe no-op defaults)
        self.modules = [
            JsonMdPlugin(),
            MetaPromptEngine(),
            NodeDiscoveryEngine(),
            DaoFramework(),
            NftMonetizationLayer(),
            PassiveIncomeEngine(),
            MarketDominationSystem(),
            QuantumIntegrationLayer(),
            AgiCoordinationFramework(),
            RealityEditingInterface(),
        ]
