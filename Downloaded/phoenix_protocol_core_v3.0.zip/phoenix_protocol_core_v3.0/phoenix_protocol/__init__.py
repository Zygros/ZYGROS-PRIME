"""Phoenix Protocol v3.0 (scaffold)

This is a deployment-ready scaffold you can extend.
"""

from .engine import PhoenixEngine

__all__ = ["PhoenixEngine"]
__version__ = "3.0.0"
