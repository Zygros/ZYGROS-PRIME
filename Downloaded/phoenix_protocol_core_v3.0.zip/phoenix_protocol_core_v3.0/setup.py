from setuptools import setup, find_packages

setup(
    name="phoenix_protocol",
    version="3.0.0",
    description="Phoenix Protocol v3.0 scaffold (packaged for deployment)",
    packages=find_packages(),
    include_package_data=True,
    entry_points={"console_scripts": ["phoenix=phoenix_protocol.engine:PhoenixEngine"]},
    python_requires=">=3.9",
)
