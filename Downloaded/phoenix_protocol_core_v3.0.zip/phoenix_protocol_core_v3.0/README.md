# Phoenix Protocol v3.0 (Scaffold)

This bundle contains a safe, extendable scaffold matching the requested module layout.

## Install (editable)
```bash
cd phoenix_protocol_core_v3.0
python -m pip install -e .
```

## Run
```bash
phoenix --config-path /etc/phoenix_protocol status
phoenix --config-path /etc/phoenix_protocol activate
```

## Notes
- Modules are stubs (no network calls, no blockchain interaction).
- Add real implementations inside `phoenix_protocol/modules/*`.
