# Mythic Interface Layer (Optional)
This layer is purely **presentation**—it can render checkpoints as “cosmic” narrative without altering truth conditions.

Rules:
- Never claim literal completion of impossible cycle counts.
- Use “tower-scale target” language and log-space scores.
- Use metaphor only for labels; keep metrics numeric and auditable.

Example label mapping:
- `reality_integrity` → “Reality Integrity”
- `mathematical_stability` → “Mathematical Stability”
- `cosmic_progress_score` → “Transcendence Score (log-log)”
