# Termux CLI Guide

## Install
```bash
pkg update -y
pkg install -y python
python -m pip install --upgrade pip
```

## Run
From the suite folder:
```bash
python src/hes_runner.py --config examples/config.termux.json
```

## Outputs
- `output/telemetry.jsonl` — checkpoint stream
- `output/summary.json` — final report (conforms to `schemas/hes_summary.schema.json`)
