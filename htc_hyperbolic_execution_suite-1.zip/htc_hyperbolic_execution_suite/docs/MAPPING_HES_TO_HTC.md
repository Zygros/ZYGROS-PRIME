# Mapping HES → Phoenix / HTC Pattern (Implementation Notes)

## 1) HTC “Cycle” Reframed
- Replace `cycle < 10^(10^100)` with:
  - `time < deadline`
  - escalating schedules: precision, dimensions, memory pressure, recursion probes

## 2) Layer Mapping (suggested)
- L1: Input + seed + guardrails (governance)
- L2: Escalation scheduler (complexity ramps)
- L3: Boundary probes (recursion/memory/precision/float)
- L4: Telemetry + checkpointing (JSONL)
- L5: Stability metrics (proxy integrities)
- L6: Report synthesis (summary + artifacts)
- L7: Optional “mythic interface” (labels only; no false claims)

## 3) Enforcement
- Hard preflight checks:
  - disallow digit materialization of tower-scale numbers
  - disallow unbounded loops
  - cap memory pressure
  - cap recursion probes
- Restore runtime settings post-test (recursion limit, context precision).

## 4) Plug-in Surface
Expose probes as plugins:
- `probe_recursion()`
- `probe_decimal_precision()`
- `probe_float_anomalies()`
- `probe_memory_pressure()`
Each returns:
- measurements
- breaking points
- stability deltas

## 5) Auditable Outputs
- `telemetry.jsonl` (append-only)
- `summary.json` (final)
- optional `artifacts/` folder for graphs or exported views
