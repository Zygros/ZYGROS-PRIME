# Hyperbolic Execution Specification (HES) v1.0
Date: 2025-12-27

## 1. Purpose
HES defines a **finite, evidence-producing** execution model for testing “infinite-scale” concepts (e.g., 10^(10^100)) without pretending literal completion is feasible.

It replaces impossible iteration counts with:
- **Time-bounded execution**
- **Escalating complexity schedules**
- **Boundary probes** (stack/recursion, heap/memory, numeric precision, float anomalies)
- **Telemetry checkpoints** (JSONL) and **final summary** (JSON)

## 2. Core Principles
1. **Representation ≠ Materialization**
   - Symbolic representation of huge values is allowed.
   - Digit-wise materialization is treated as a separate operation with explicit guards.

2. **Finite Runtime, Infinite Target**
   - The “target” is encoded in log-space and used only for **progress scoring**.

3. **Escalation Schedules**
   - Complexity ramps by step/time (e.g., precision, dimensions, recursion depth probes).

4. **Limit Finding**
   - The goal is to discover **breaking points** and stability regimes, not “finish”.

5. **Determinism**
   - Provide seed control for reproducibility.

## 3. Metrics
Required metrics:
- `steps_executed`
- `runtime_seconds`
- `max_safe_recursion`
- `decimal_prec_final`
- `float_anomaly_rate` (or penalty accumulator)
- `memory_pressure_mb`
- `mathematical_stability` (proxy)
- `reality_integrity` (proxy)
- `breaking_points[]` (timestamped)

## 4. Progress Scoring
For tower-scale targets like 10^(10^100):
- `log10(target) = 10^100` (unrepresentable)
- `log10(log10(target)) = 100` (representable)

Define:
- `score = log10(log10(steps + 10)) / 100`

Score is **symbolic** and only used for dashboarding and checkpoint narration.

## 5. Safety Guardrails (Hard Requirements)
- Never attempt `str(Decimal(10) ** Decimal(10**100))`
- Never attempt loops like `range(10**100)`
- Memory pressure must be chunked and capped.
- Recursion probing must be bounded and restore the original recursion limit.

## 6. Conformance
An implementation conforms to HES v1.0 if it:
- Enforces the guardrails
- Produces telemetry + summary in the specified fields
- Implements at least 3 boundary probes
- Is reproducible via seed

## 7. Reference Implementation
See `src/hes_runner.py` and `examples/config.termux.json`.
