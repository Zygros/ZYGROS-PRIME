#!/usr/bin/env bash
# Offline helper that mirrors what you'd do locally.
# 1) Compute hashes
# 2) Emit a manifest
# 3) (Optional) Later: ots stamp dist/manifest.json on a connected machine
set -euo pipefail

python3 tools/hash_and_pack.py
echo "Manifest & package built in ./dist"
echo "To anchor later (on your machine with internet):"
echo "  ots stamp dist/manifest.json"
echo "  ots verify dist/manifest.json"
