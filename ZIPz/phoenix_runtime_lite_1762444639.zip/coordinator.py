#!/usr/bin/env python3
Simple local coordinator scaffold.
Purpose: Provide a single place to (a) load the metaprompt text; (b) persist ephemeral notes; (c) produce hashes for verification.
Note: This *does not* call external LLMs or the internet. It’s a local skeleton you can wire to your preferred APIs.

import json, hashlib, pathlib, datetime
from pathlib import Path

ROOT = Path(__file__).parent
METAPROMPT_FILE = ROOT / "PHOENIX_UNIVERSAL_METAPROMPT.md"
MEM_PATH = ROOT / "runtime" / "memory" / "eternal_memory.json"
MANIFEST = ROOT / "manifest.json"

def sha256_bytes(data: bytes) -> str:
    import hashlib
    h = hashlib.sha256(); h.update(data); return h.hexdigest()

def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8") if p.exists() else ""

def load_memory():
    MEM_PATH.parent.mkdir(parents=True, exist_ok=True)
    if MEM_PATH.exists():
        return json.loads(MEM_PATH.read_text(encoding="utf-8"))
    return {"notes": [], "last_updated": None}

def save_memory(obj):
    obj["last_updated"] = datetime.datetime.utcnow().isoformat() + "Z"
    MEM_PATH.write_text(json.dumps(obj, indent=2), encoding="utf-8")

def build_state():
    mp_text = read_text(METAPROMPT_FILE)
    mem = load_memory()
    state = {
        "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
        "metaprompt_hash": sha256_bytes(mp_text.encode("utf-8")) if mp_text else None,
        "memory_hash": sha256_bytes(json.dumps(mem, sort_keys=True).encode("utf-8")),
    }
    # Persist current state to manifest for easy auditing
    manifest = {}
    if MANIFEST.exists():
        try:
            manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
        except Exception:
            manifest = {}
    manifest["last_state"] = state
    MANIFEST.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return state

def add_note(note: str):
    mem = load_memory()
    mem["notes"].append({"t": datetime.datetime.utcnow().isoformat() + "Z", "note": note})
    save_memory(mem)

def cli():
    import argparse
    ap = argparse.ArgumentParser(description="Phoenix Runtime Lite — local coordinator")
    ap.add_argument("--hash", action="store_true", help="Compute hashes for metaprompt and memory")
    ap.add_argument("--note", type=str, help="Append a note to memory")
    args = ap.parse_args()

    if args.note:
        add_note(args.note)
        print("Note added.")

    if args.hash:
        state = build_state()
        print(json.dumps(state, indent=2))

if __name__ == "__main__":
    cli()
