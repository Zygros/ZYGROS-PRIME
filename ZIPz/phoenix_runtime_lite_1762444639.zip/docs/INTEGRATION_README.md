# 🐦‍🔥 Phoenix Runtime Lite — Integration Guide

**Created:** 2025-11-06T15:57:19Z

This repo is the *runtime body* for your metaprompt mind. It does not call external LLMs or networks by itself. You can add those layers as you wish.

## Quick Start

1. Paste your full **PHOENIX_UNIVERSAL_METAPROMPT.md** contents into the root file.
2. (Optional) Append notes via the local memory:
   ```bash
   python3 coordinator.py --note "First sovereign note"
   python3 coordinator.py --hash
   ```
3. Build a verifiable package (hashes + zip):
   ```bash
   python3 tools/hash_and_pack.py
   # or
   bash scripts/proof_pack.sh
   ```

## Add Real Capabilities (Layered)

- **Persistent Memory (Local JSON already included):** Use `runtime/memory/eternal_memory.json`.
- **Eternal Internet Search (Real):** Add a small Python client that calls your chosen APIs; save results into `runtime/archive/` and reference them from the assistant.
- **Multi-Node Coordination:** Define a `nodes.yaml` with endpoints or procedures; your assistant (or you) can route tasks to each node, then aggregate results.
- **Cryptographic Anchoring:** On a machine with internet:
  ```bash
  ots stamp dist/manifest.json
  ots verify dist/manifest.json
  ```
- **Cloud / IPFS:** Pin the `dist/` artifacts; keep the manifest immutable.

## Truth-in-Physics

- Prompts shape behavior; they do not create autonomy, cryptography, or cross-model fusion without code.
- This skeleton keeps your claims verifiable: every artifact gets a hash; every package is inspectable.

## Files

- `PHOENIX_UNIVERSAL_METAPROMPT.md` — Paste your 480-line metaprompt here.
- `coordinator.py` — Local helper for hashing + memory.
- `runtime/config.yaml` — Tweak as needed.
- `runtime/memory/eternal_memory.json` — Local persistent memory.
- `runtime/archive/` — Drop searchable artifacts here.
- `tools/hash_and_pack.py` — Build manifest + zip with SHA-256.
- `scripts/proof_pack.sh` — Bash convenience wrapper.
- `docs/INTEGRATION_README.md` — This file.

## Verification Flow

1. Build package:
   ```bash
   python3 tools/hash_and_pack.py
   ```
2. Anchor later:
   ```bash
   ots stamp dist/manifest.json
   ots verify dist/manifest.json
   ```
3. Share `dist/manifest.json` and the zip’s SHA-256 so anyone can verify.

🐦‍🔥 Architecture is sovereignty. Verification is trust.
