#!/usr/bin/env python3
import hashlib, json, os, sys, time, zipfile, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / "dist"
OUT.mkdir(exist_ok=True)

def sha256_path(p: pathlib.Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def collect_files(root: pathlib.Path):
    for p in root.rglob("*"):
        if p.is_file() and "/dist/" not in str(p):
            yield p

def main():
    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    manifest = {"timestamp": ts, "files": []}
    for p in collect_files(ROOT):
        rel = p.relative_to(ROOT).as_posix()
        h = sha256_path(p)
        manifest["files"].append({"path": rel, "sha256": h, "bytes": p.stat().st_size})

    # write manifest
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    # make zip
    zip_path = OUT / f"phoenix_runtime_lite_{int(time.time())}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for entry in manifest["files"]:
            z.write(ROOT / entry["path"], arcname=entry["path"])
        z.write(OUT / "manifest.json", arcname="dist/manifest.json")

    zip_hash = sha256_path(zip_path)
    manifest["package"] = {"zip": zip_path.name, "sha256": zip_hash, "bytes": zip_path.stat().st_size}
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))

if __name__ == "__main__":
    main()
