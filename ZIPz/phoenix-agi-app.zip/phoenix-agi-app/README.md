# 🐦‍🔥 Phoenix AGI Web Application

Production-ready scaffold: FastAPI backend + React (Vite) frontend + PostgreSQL + Redis (optional) via Docker Compose.

## Quickstart (Docker)
1. Copy `.env.example` to `.env` and fill values.
2. `docker compose up --build`

Backend: http://localhost:8000  
Frontend: http://localhost:5173

## Quickstart (Local Dev)
### Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

## Notes
- Provider abstraction is under `backend/app/services/ai_providers/` with `OpenAIProvider` implemented. Add others by subclassing `BaseProvider`.
- Orchestrator supports multi-provider routing and simple tool-style function calls.
- Memory interface is implemented with Postgres (simple table). Swap for pgvector/Chroma later if needed.
- Keep your API keys in `.env` (never commit them).
```