from fastapi import APIRouter, HTTPException
from ..models.schemas import ChatRequest, ChatResponse, Message
from ..services.orchestrator import orchestrator
from ..services.memory import save_messages, load_history
from ..db import init_db
from ..core.config import settings

router = APIRouter()

@router.on_event("startup")
def on_startup():
    init_db()

@router.get("/providers")
def list_providers():
    return {"providers": ["openai"]}

@router.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    provider = orchestrator.get_provider(req.provider)
    model = orchestrator.select_model(provider.name, req.model)

    history = load_history(req.session_id or "default", limit=50)
    messages = history + [m.model_dump() for m in req.messages]

    try:
        content = await provider.chat(model=model, messages=[Message(**m) for m in messages],
                                      max_tokens=req.max_tokens or settings.MAX_TOKENS,
                                      temperature=req.temperature or settings.TEMPERATURE)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    save_messages(req.session_id or "default", req.messages + [{"role": "assistant", "content": content}])
    return ChatResponse(content=content, provider=provider.name, model=model)
