from pydantic import BaseModel, Field
from typing import List, Optional, Literal

Role = Literal["system", "user", "assistant"]

class Message(BaseModel):
    role: Role
    content: str

class ChatRequest(BaseModel):
    provider: Optional[str] = None
    model: Optional[str] = None
    messages: List[Message]
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    session_id: Optional[str] = "default"

class ChatResponse(BaseModel):
    content: str
    provider: str
    model: str
