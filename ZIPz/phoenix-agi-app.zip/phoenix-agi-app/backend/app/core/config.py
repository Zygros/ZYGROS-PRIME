from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    APP_ENV: str = "development"
    SECRET_KEY: str = "change_me"
    CORS_ORIGINS: str = "http://localhost:5173"
    LOG_LEVEL: str = "INFO"

    POSTGRES_USER: str = "phoenix"
    POSTGRES_PASSWORD: str = "phoenix_password"
    POSTGRES_DB: str = "phoenixdb"
    POSTGRES_HOST: str = "db"
    POSTGRES_PORT: int = 5432

    REDIS_HOST: str = "redis"
    REDIS_PORT: int = 6379

    OPENAI_API_KEY: str | None = None

    DEFAULT_PROVIDER: str = "openai"
    MODEL_FALLBACKS: str = "gpt-4o-mini,gpt-4o,gpt-4.1"
    MAX_TOKENS: int = 2048
    TEMPERATURE: float = 0.2

    class Config:
        env_file = ".env"

settings = Settings()
