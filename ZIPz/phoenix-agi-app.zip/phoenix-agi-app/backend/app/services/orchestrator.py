from typing import Dict, List
from ..models.schemas import Message
from .ai_providers.base import BaseProvider
from .ai_providers.openai_provider import OpenAIProvider
from ..core.config import settings

class Orchestrator:
    def __init__(self):
        self.providers: Dict[str, BaseProvider] = {
            "openai": OpenAIProvider(api_key=settings.OPENAI_API_KEY),
        }

    def get_provider(self, name: str | None) -> BaseProvider:
        name = name or settings.DEFAULT_PROVIDER
        if name not in self.providers:
            raise ValueError(f"Unknown provider: {name}")
        return self.providers[name]

    def select_model(self, provider: str, preferred: str | None) -> str:
        if preferred:
            return preferred
        # Default sensible model; fallbacks in env var if needed.
        if provider == "openai":
            return "gpt-4o-mini"
        return "gpt-4o-mini"

orchestrator = Orchestrator()
