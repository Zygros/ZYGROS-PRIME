from sqlalchemy.orm import Session
from sqlalchemy import text
from ..db import SessionLocal

def save_messages(session_id: str, messages: list[dict]):
    db: Session = SessionLocal()
    try:
        for m in messages:
            db.execute(
                text("INSERT INTO memory (session_id, role, content) VALUES (:sid, :r, :c)"),
                {"sid": session_id, "r": m["role"], "c": m["content"]},
            )
        db.commit()
    finally:
        db.close()

def load_history(session_id: str, limit: int = 50) -> list[dict]:
    db: Session = SessionLocal()
    try:
        rows = db.execute(
            text("SELECT role, content FROM memory WHERE session_id=:sid ORDER BY id DESC LIMIT :lim"),
            {"sid": session_id, "lim": limit},
        ).all()
        return [{"role": r[0], "content": r[1]} for r in rows[::-1]]
    finally:
        db.close()
