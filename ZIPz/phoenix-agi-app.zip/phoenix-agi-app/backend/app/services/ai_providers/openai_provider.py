import os
from typing import List
import httpx
from ...models.schemas import Message
from .base import BaseProvider

OPENAI_API_BASE = "https://api.openai.com/v1"

class OpenAIProvider(BaseProvider):
    name = "openai"

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")

    async def chat(self, model: str, messages: List[Message], max_tokens: int | None = None, temperature: float | None = None) -> str:
        if not self.api_key:
            raise RuntimeError("OPENAI_API_KEY not set")
        payload = {
            "model": model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
        }
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if temperature is not None:
            payload["temperature"] = temperature

        headers = {"Authorization": f"Bearer {self.api_key}"}
        async with httpx.AsyncClient(timeout=120) as client:
            r = await client.post(f"{OPENAI_API_BASE}/chat/completions", headers=headers, json=payload)
            r.raise_for_status()
            data = r.json()
            return data["choices"][0]["message"]["content"]
