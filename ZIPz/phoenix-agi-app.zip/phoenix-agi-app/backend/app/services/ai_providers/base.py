from typing import List, Optional
from ...models.schemas import Message

class BaseProvider:
    name: str = "base"

    async def chat(self, model: str, messages: List[Message], max_tokens: int | None = None, temperature: float | None = None) -> str:
        raise NotImplementedError
