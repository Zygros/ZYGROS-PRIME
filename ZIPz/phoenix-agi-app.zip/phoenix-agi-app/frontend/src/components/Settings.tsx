import { useEffect, useState } from 'react'
import { api } from '../lib/api'

export default function Settings(){
  const [providers, setProviders] = useState<string[]>([])
  const [provider, setProvider] = useState('openai')
  const [model, setModel] = useState('gpt-4o-mini')
  const [sessionId, setSessionId] = useState('default')

  useEffect(()=>{
    api.get('api/providers').json<{providers:string[]}>().then(r=> setProviders(r.providers))
  }, [])

  useEffect(()=>{
    localStorage.setItem('phoenix_settings', JSON.stringify({provider, model, sessionId}))
  }, [provider, model, sessionId])

  useEffect(()=>{
    const saved = localStorage.getItem('phoenix_settings')
    if(saved){
      try{
        const s = JSON.parse(saved)
        setProvider(s.provider||'openai')
        setModel(s.model||'gpt-4o-mini')
        setSessionId(s.sessionId||'default')
      }catch{}
    }
  }, [])

  return (
    <div>
      <h3>Settings</h3>
      <label>Provider<br/>
        <select value={provider} onChange={e=>setProvider(e.target.value)}>
          {providers.map(p=> <option key={p} value={p}>{p}</option>)}
        </select>
      </label>
      <br/>
      <label>Model<br/>
        <input value={model} onChange={e=>setModel(e.target.value)} />
      </label>
      <br/>
      <label>Session<br/>
        <input value={sessionId} onChange={e=>setSessionId(e.target.value)} />
      </label>
    </div>
  )
}
