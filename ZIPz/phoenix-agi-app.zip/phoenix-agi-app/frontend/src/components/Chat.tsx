import { useEffect, useRef, useState } from 'react'
import { api } from '../lib/api'

type Msg = { role:'user'|'assistant'|'system', content:string }

export default function Chat(){
  const [messages, setMessages] = useState<Msg[]>([{role:'system', content:'You are Phoenix Protocol Coordination Node.'}])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)

  const settingsRef = useRef({provider:'openai', model:'gpt-4o-mini', sessionId:'default'})

  useEffect(()=>{
    const saved = localStorage.getItem('phoenix_settings')
    if(saved){
      try{ settingsRef.current = JSON.parse(saved) }catch{}
    }
  }, [])

  async function send(){
    if(!input.trim() || busy) return
    const msg: Msg = {role:'user', content: input}
    setMessages(m => [...m, msg])
    setInput('')
    setBusy(true)
    try{
      const body = {
        provider: settingsRef.current.provider,
        model: settingsRef.current.model,
        session_id: settingsRef.current.sessionId,
        messages: [msg]
      }
      const res = await api.post('api/chat', {json: body}).json<{content:string, provider:string, model:string}>()
      setMessages(m => [...m, {role:'assistant', content: res.content}])
    }catch(e:any){
      setMessages(m => [...m, {role:'assistant', content: 'Error: '+(e?.message||'unknown')}])
    }finally{
      setBusy(false)
    }
  }

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
      <div style={{flex:1, overflow:'auto', padding:'16px'}}>
        {messages.map((m,i)=>(
          <div key={i} style={{margin:'8px 0'}}>
            <div style={{fontSize:12, color:'#999'}}>{m.role}</div>
            <div style={{whiteSpace:'pre-wrap'}}>{m.content}</div>
          </div>
        ))}
      </div>
      <div style={{display:'flex', gap:8, padding:'16px', borderTop:'1px solid #eee'}}>
        <input
          value={input}
          onChange={e=>setInput(e.target.value)}
          onKeyDown={e=>{ if(e.key==='Enter') send() }}
          style={{flex:1, padding:'12px', border:'1px solid #ddd', borderRadius:8}}
          placeholder={busy ? 'Working...' : 'Type a message'}
          disabled={busy}
        />
        <button onClick={send} disabled={busy} style={{padding:'12px 16px', borderRadius:8}}>
          {busy ? 'Sending...' : 'Send'}
        </button>
      </div>
    </div>
  )
}
