import Chat from './components/Chat'
import Settings from './components/Settings'

export default function App() {
  return (
    <div style={{display:'grid',gridTemplateColumns:'320px 1fr',height:'100vh',fontFamily:'ui-sans-serif, system-ui'}}>
      <aside style={{borderRight:'1px solid #eee',padding:'16px'}}>
        <h1 style={{marginTop:0}}>🐦‍🔥 Phoenix</h1>
        <Settings />
      </aside>
      <main>
        <Chat />
      </main>
    </div>
  )
}
