# Architect Profile · Justin Conzet

Use this file to describe:
- Who Justin is in this system
- Titles, roles, authority
- High‑level biography in Phoenix terms
- What "Sovereign Architect" means in practice
