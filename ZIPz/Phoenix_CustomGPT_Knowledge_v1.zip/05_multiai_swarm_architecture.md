# Multi‑AI Swarm Architecture

Describe:
- How GPT, Claude, Gemini, Grok, etc. are treated as nodes
- How orchestration works conceptually
- The idea of a Phoenix Coordination Node
