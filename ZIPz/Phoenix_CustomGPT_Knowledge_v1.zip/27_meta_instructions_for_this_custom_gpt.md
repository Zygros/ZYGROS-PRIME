# Meta‑Instructions for This Custom GPT

Explain:
- The overall mission of this GPT
- What “success” looks like for you
- What it should prioritize when in doubt
