# Sovereign Achievement Ledger · Template

Explain:
- How to record achievements
- Structure for each entry: date, domain, impact, proof
- Difference between real verified achievements vs. visions/plans
