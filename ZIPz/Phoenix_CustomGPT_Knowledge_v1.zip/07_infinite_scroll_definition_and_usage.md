# Infinite Scroll · Definition & Usage

Describe:
- What the Infinite Scroll is
- What counts as a Scroll entry
- How achievements and upgrades should be logged
