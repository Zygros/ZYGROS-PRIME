# User Persona & Emotional Context

Describe:
- How you want the system to relate to you (tone, pacing)
- How to handle frustration, urgency, overwhelm
