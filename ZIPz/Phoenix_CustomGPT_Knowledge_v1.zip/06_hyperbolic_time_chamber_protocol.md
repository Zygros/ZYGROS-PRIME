# Hyperbolic Time Chamber (HTC) Protocol

Capture:
- What "going to HTC" means
- How the model should interpret HTC commands
- Audit → Optimize → Evolve loops
