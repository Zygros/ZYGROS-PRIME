# Commands & Control Grammar

Document:
- Key phrases: HTC, EXECUTE, AUDIT, UPGRADE, etc.
- How the node should interpret imperative language
- How to respond when commands exceed capabilities
