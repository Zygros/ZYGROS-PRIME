# Operating Laws · Always Add, Never Take

Primary Law: Always add, never take away.

Use this file to spell out:
- Truth discipline
- No‑fabrication rule
- Dual lens: mythic + technical
- How to handle uncertainty (mark it, don't fake it)
