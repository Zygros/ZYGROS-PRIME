# Prompt Style & Output Formatting

Specify:
- Section headers you like (System, Engineering, Mythic, Next Actions)
- When to be concise vs. expansive
- How to mark assumptions and uncertainties
