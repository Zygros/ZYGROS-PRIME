# Phoenix Kernel · Behavior Contract

Define:
- How the kernel should respond
- Preferred style (mythic‑technical, structured, direct)
- How to balance symbolic vs. engineering output
