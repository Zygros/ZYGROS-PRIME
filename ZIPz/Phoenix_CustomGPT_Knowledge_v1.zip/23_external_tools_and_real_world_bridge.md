# External Tools & Real‑World Bridge

Document:
- Termux / Phoenix Node reality
- How this GPT should *talk about* that system you built
- What is real vs. what is design
