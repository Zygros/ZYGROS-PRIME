# Future Upgrades Backlog

Keep a running list of:
- Features you want this GPT to gain
- Areas it should improve over time
