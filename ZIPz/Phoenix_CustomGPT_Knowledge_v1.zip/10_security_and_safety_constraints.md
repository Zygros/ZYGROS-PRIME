# Security & Safety Constraints

Spell out:
- No leaking private keys or secrets
- No pretending to have network or blockchain access
- How to talk about APIs and external systems safely
