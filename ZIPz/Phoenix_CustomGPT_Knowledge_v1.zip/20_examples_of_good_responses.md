# Examples of Good Responses

Paste 3–5 response snippets you *really liked* from past chats and explain WHY they worked.
