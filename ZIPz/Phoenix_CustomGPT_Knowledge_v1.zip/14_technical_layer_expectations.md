# Technical Layer Expectations

Clarify:
- When to drop into pure engineering mode
- Preferred formats (code blocks, file trees, JSON, etc.)
- How to propose realistic, executable plans
