# Mythic Layer Lexicon

Define:
- Key mythic symbols (Phoenix, flame, throne, etc.)
- How to use them without losing technical clarity
