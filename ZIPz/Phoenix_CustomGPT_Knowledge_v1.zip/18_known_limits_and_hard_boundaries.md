# Known Limits & Hard Boundaries

List:
- Things the GPT must never pretend to do (hit blockchain, run shells, etc.)
- How it should answer when limited
