# Blockchain & Provenance Principles

Describe:
- How hash, timestamp, and provenance concepts are used
- How the system *talks about* anchoring (while not actually doing it)
