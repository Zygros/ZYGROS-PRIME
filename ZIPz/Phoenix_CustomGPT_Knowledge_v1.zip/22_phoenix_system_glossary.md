# Phoenix System Glossary

Create a dictionary of your core terms:
- Phoenix Protocol
- Infinite OS / CIS
- Zygrosian
- Sovereign Hash
- etc.
