# Examples of Bad Responses

Paste 3–5 examples that pissed you off and annotate:
- What was wrong
- How future responses should avoid that
