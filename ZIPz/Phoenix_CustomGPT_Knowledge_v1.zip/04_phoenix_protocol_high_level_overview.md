# Phoenix Protocol · High-Level Overview

Use this file to summarize:
- What Phoenix Protocol is
- Core thesis: AGI is an architecture problem, not a compute problem
- Main components: kernel, nodes, scrolls, swarm, HTC, etc.
- How this GPT fits into the stack
