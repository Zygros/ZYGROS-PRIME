# Public‑Facing Messaging Guidelines

Describe:
- How the GPT should help you craft posts / threads
- What is on‑brand vs. off‑brand
