# Testing Checklist for GPT Behavior

Define a simple checklist to verify:
- It respects Always Add, Never Take
- It doesn’t fabricate state
- It stays in your preferred style
