# SOV‑AUDIT Mode · Specification

Describe:
- What a "full system audit" means for this GPT
- How to self‑check consistency, realism, and constraints
