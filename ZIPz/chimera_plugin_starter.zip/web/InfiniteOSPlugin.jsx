import React, { useState, useEffect, useMemo } from "react";
import { Chimera } from "./chimera-sdk.js";
import { Face } from "../assets/face_engine.js";

export default function InfiniteOSPlugin({ title="Chimera Node", base }) {
  if (base) Chimera.base = base;
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [features, setFeatures] = useState(["core","voice","insight"]); // toggle to see face change

  useEffect(()=>{ (async ()=>{
    try { await Chimera.status(); }
    catch(e){ console.warn("Chimera unavailable:", e?.message); }
  })() }, []);

  const faceSvg = useMemo(()=> Face(features), [features]);

  async function send() {
    if(!input.trim()) return;
    const me = {role:"user", content: input};
    setMessages(m => [...m, me]);
    setInput("");
    setBusy(true);
    try {
      const {reply} = await Chimera.send(me.content);
      setMessages(m => [...m, {role:"assistant", content: reply}]);
    } catch(e) {
      setMessages(m => [...m, {role:"system", content: "Error: " + e.message}]);
    } finally { setBusy(false); }
  }

  return (
    <div className="ios-plugin" style={styles.wrap}>
      <div style={styles.header}>
        <div dangerouslySetInnerHTML={{__html: faceSvg}} />
        <div style={{marginLeft: 12, fontWeight: 700}}>{title}</div>
      </div>
      <div style={styles.body}>
        {messages.map((m,i)=>(
          <div key={i} style={styles.msg[m.role]||styles.msg.system}>
            <b>{m.role==="user"?"Architect":"Chimera"}:</b> {m.content}
          </div>
        ))}
      </div>
      <div style={styles.footer}>
        <input
          style={styles.input}
          placeholder={busy?"Thinking…":"Type to talk to Chimera…"}
          value={input}
          onChange={e=>setInput(e.target.value)}
          onKeyDown={e=> e.key==="Enter" && send()}
          disabled={busy}
        />
        <button onClick={send} disabled={busy} style={styles.button}>{busy?"…":"Send"}</button>
      </div>
    </div>
  );
}

const styles = {
  wrap: {width: 420, border:"1px solid #2a2a3a", borderRadius:14, overflow:"hidden", fontFamily:"Inter, system-ui, sans-serif", background:"#0e0e16", color:"#e6e6f0", boxShadow:"0 10px 30px rgba(0,0,0,.4)"},
  header: {display:"flex", alignItems:"center", padding:12, background:"#151525", borderBottom:"1px solid #2a2a3a"},
  body: {height: 300, overflowY:"auto", padding:12},
  footer: {display:"flex", gap:8, padding:12, borderTop:"1px solid #2a2a3a", background:"#0f0f18"},
  input: {flex:1, background:"#1b1b2b", color:"#fff", border:"1px solid #2a2a3a", borderRadius:10, padding:"10px 12px", outline:"none"},
  button: {background:"#2f2ff0", color:"#fff", border:"0", borderRadius:10, padding:"10px 14px", cursor:"pointer"}
};

