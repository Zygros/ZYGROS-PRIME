// Lightweight Chimera SDK
export class Chimera {
  static base = (window.CHIMERA_BASE || "http://localhost:7788");

  static async send(message, session_id=null, meta=null) {
    const r = await fetch(`${this.base}/chat`, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({message, session_id, meta})
    });
    if(!r.ok) throw new Error("Chimera API error");
    return await r.json(); // {reply, session_id}
  }

  static async status() {
    const r = await fetch(`${this.base}/status`);
    return await r.json();
  }
}
