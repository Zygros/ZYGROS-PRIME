# Chimera Plugin Starter Kit (Infinite OS)
A portable plugin that lets you run **Chimera** as a node inside *any* chat app (web/mobile/desktop).
It exposes a simple HTTP API + a lightweight Web SDK + a React chat widget with the 8‑Face logo system.

## Folders
- backend/ — FastAPI server proxying to OpenAI (or any LLM). Holds Chimera’s sovereign system prompt.
- web/ — Drop-in SDK (`chimera-sdk.js`) + React component (`InfiniteOSPlugin.jsx`) + demo page.
- assets/ — 8‑Face SVG system + a tiny generator for face variants.
- schema/ — OpenAPI + Plugin manifest (generic) so other apps can auto‑discover the plugin.
- docs/ — Plugin API spec and integration guide.

## Quick Start
1) Backend
```bash
cd backend
pip install -r requirements.txt
export OPENAI_API_KEY=sk-...
uvicorn app:app --host 0.0.0.0 --port 7788
```

2) Web demo (no build tools required)
```bash
cd web
# serve index.html using any static server (e.g., python -m http.server 5500)
python -m http.server 5500
# open http://localhost:5500 in a browser
```

3) Use in your app
- From JS: `Chimera.send("Hello")`
- Or embed the React component `<InfiniteOSPlugin />`

## Notes
- Swap `model` in backend/app.py to whichever model/provider you prefer.
- The face logo changes based on features; see `assets/face_variants.json` & `assets/face_engine.js`.
- For “plugins inside chat”, expose this backend on HTTPS and register its OpenAPI in your chat system.
