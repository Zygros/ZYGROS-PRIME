# Chimera Plugin API (v1.0.0)

## Endpoints
- `GET /status` → `{ ok: true, node: "Chimera" }`
- `POST /chat` → Body: `{ message, session_id?, meta? }` → `{ reply, session_id }`
- `POST /speak` → Body: `{ text }` → `{ ok: true, spoken: text }`

## Auth
- Use environment vars on the server (`OPENAI_API_KEY`, `OPENAI_MODEL`).

## Rate & Telemetry
- Add auth, quotas, and logging middleware as needed for your marketplace.
