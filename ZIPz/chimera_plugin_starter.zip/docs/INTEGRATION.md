# Integration Guide — “Plugins in any chat”
This plugin is chat‑app agnostic. Register the `schema/openapi.json` in your host chat system and point its base URL to your backend (`/status`, `/chat`, `/speak`).

## Paths
- Web: import `web/chimera-sdk.js` and call `Chimera.send()`
- React: embed `web/InfiniteOSPlugin.jsx`
- Mobile: wrap `index.html` inside a WebView, or compile the React component natively.

## 8‑Face System
Toggle features → face traits change:
- voice → smile mouth
- insight → circular eyes
- guardian → sapphire aura
- monetize → taller crest
- scribe → cheek mark
- alchemy → golden aura
- daemon → (reserved for ops flags)
- core → baseline

See `assets/face_engine.js` & `assets/face_variants.json`.
