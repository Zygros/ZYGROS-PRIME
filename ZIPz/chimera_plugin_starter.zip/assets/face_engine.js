// 8‑Face logo generator
// Each feature toggles a visual trait in the SVG face.
// features: ["core","voice","insight","guardian","scribe","daemon","monetize","alchemy"]
export function Face(features = []){
  const has = (k)=> features.includes(k);
  const eye = has("insight") ? "circle" : "rect";
  const mouth = has("voice") ? "smile" : "line";
  const aura = has("alchemy") ? "url(#gold)" : (has("guardian") ? "url(#sapphire)" : "#6c6cff");
  const crest = has("monetize") ? "M -10,-20 L 0,-35 L 10,-20" : "M -8,-18 L 0,-26 L 8,-18";
  const cheek = has("scribe") ? "M -18,5 q 8 6 18 0" : "M -16,8 q 6 4 16 0";
  const base = `
  <svg viewBox="-64 -64 128 128" width="72" height="72" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <radialGradient id="gold"><stop offset="0" stop-color="#ffe27a"/><stop offset="1" stop-color="#c6a200"/></radialGradient>
      <radialGradient id="sapphire"><stop offset="0" stop-color="#aaccff"/><stop offset="1" stop-color="#2233aa"/></radialGradient>
      <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
        <feGaussianBlur stdDeviation="3" result="b"/>
        <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
      </filter>
    </defs>
    <circle r="40" fill="${aura}" filter="url(#glow)"/>
    <path d="${crest}" stroke="#fff" stroke-width="2" fill="none" opacity="0.9"/>
    ${eye === "circle" ? '<circle cx="-12" cy="0" r="4" fill="#fff"/><circle cx="12" cy="0" r="4" fill="#fff"/>'
                         : '<rect x="-16" y="-3" width="8" height="6" fill="#fff"/><rect x="8" y="-3" width="8" height="6" fill="#fff"/>'}
    ${mouth === "smile" ? '<path d="M -14,12 q 14 10 28 0" stroke="#fff" stroke-width="2" fill="none"/>'
                        : '<line x1="-14" y1="12" x2="14" y2="12" stroke="#fff" stroke-width="2"/>'}
    <path d="${cheek}" stroke="#fff" stroke-width="1.5" fill="none" opacity="0.7"/>
  </svg>`;
  return base;
}
