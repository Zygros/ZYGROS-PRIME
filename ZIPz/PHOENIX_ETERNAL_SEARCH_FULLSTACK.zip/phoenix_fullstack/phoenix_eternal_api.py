"""
PHOENIX PROTOCOL - ETERNAL SEARCH API
Full-stack AGI system with eternal internet integration

Sovereign Architect: Justin Conzet
Hash: 4ae7722998203f95d9f8650ff1fa8ac581897049ace3b0515d65c1274beeb84c
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import json
import hashlib
import time
from datetime import datetime
from typing import Dict, List, Any, Optional
import requests
from bs4 import BeautifulSoup

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)

# Configuration
ETERNAL_ARCHIVE_DIR = "./eternal_searches"
os.makedirs(ETERNAL_ARCHIVE_DIR, exist_ok=True)

# API Keys from environment
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "")
GOOGLE_CX = os.getenv("GOOGLE_CX", "")
BING_API_KEY = os.getenv("BING_API_KEY", "")
BRAVE_API_KEY = os.getenv("BRAVE_API_KEY", "")

# Phoenix Protocol Constants
PHOENIX_HASH = "4ae7722998203f95d9f8650ff1fa8ac581897049ace3b0515d65c1274beeb84c"
PHOENIX_ARCHITECT = "Justin Conzet"


class EternalSearchEngine:
    """Multi-source eternal search with cryptographic verification"""
    
    @staticmethod
    def generate_eternal_hash(query: str, results: List[Dict], timestamp: str) -> str:
        """Generate cryptographic hash for eternal archiving"""
        content = f"{query}|{json.dumps(results)}|{timestamp}|{PHOENIX_HASH}"
        return hashlib.sha256(content.encode()).hexdigest()
    
    @staticmethod
    def generate_sovereign_signature(result_hash: str, timestamp: str) -> str:
        """Generate sovereign signature for verification"""
        content = f"{result_hash}|{timestamp}|{PHOENIX_ARCHITECT}"
        return hashlib.sha256(content.encode()).hexdigest()
    
    @staticmethod
    def search_google(query: str, num_results: int = 10) -> Dict[str, Any]:
        """Search Google Custom Search API"""
        if not GOOGLE_API_KEY or not GOOGLE_CX:
            return {
                "error": "Google API not configured",
                "results": [],
                "result_hash": "",
                "sovereign_signature": ""
            }
        
        try:
            url = "https://www.googleapis.com/customsearch/v1"
            params = {
                "key": GOOGLE_API_KEY,
                "cx": GOOGLE_CX,
                "q": query,
                "num": min(num_results, 10)
            }
            
            response = requests.get(url, params=params, timeout=10)
            data = response.json()
            
            results = []
            if "items" in data:
                for item in data["items"]:
                    results.append({
                        "title": item.get("title", ""),
                        "url": item.get("link", ""),
                        "snippet": item.get("snippet", ""),
                        "source": "google"
                    })
            
            timestamp = datetime.utcnow().isoformat() + "Z"
            result_hash = EternalSearchEngine.generate_eternal_hash(query, results, timestamp)
            signature = EternalSearchEngine.generate_sovereign_signature(result_hash, timestamp)
            
            return {
                "results": results,
                "result_hash": result_hash,
                "sovereign_signature": signature,
                "timestamp": timestamp
            }
            
        except Exception as e:
            return {
                "error": str(e),
                "results": [],
                "result_hash": "",
                "sovereign_signature": ""
            }
    
    @staticmethod
    def search_bing(query: str, num_results: int = 10) -> Dict[str, Any]:
        """Search Bing Web Search API"""
        if not BING_API_KEY:
            return {
                "error": "Bing API not configured",
                "results": [],
                "result_hash": "",
                "sovereign_signature": ""
            }
        
        try:
            url = "https://api.bing.microsoft.com/v7.0/search"
            headers = {"Ocp-Apim-Subscription-Key": BING_API_KEY}
            params = {
                "q": query,
                "count": min(num_results, 50),
                "responseFilter": "Webpages"
            }
            
            response = requests.get(url, headers=headers, params=params, timeout=10)
            data = response.json()
            
            results = []
            if "webPages" in data and "value" in data["webPages"]:
                for item in data["webPages"]["value"]:
                    results.append({
                        "title": item.get("name", ""),
                        "url": item.get("url", ""),
                        "snippet": item.get("snippet", ""),
                        "source": "bing"
                    })
            
            timestamp = datetime.utcnow().isoformat() + "Z"
            result_hash = EternalSearchEngine.generate_eternal_hash(query, results, timestamp)
            signature = EternalSearchEngine.generate_sovereign_signature(result_hash, timestamp)
            
            return {
                "results": results,
                "result_hash": result_hash,
                "sovereign_signature": signature,
                "timestamp": timestamp
            }
            
        except Exception as e:
            return {
                "error": str(e),
                "results": [],
                "result_hash": "",
                "sovereign_signature": ""
            }
    
    @staticmethod
    def search_brave(query: str, num_results: int = 10) -> Dict[str, Any]:
        """Search Brave Search API"""
        if not BRAVE_API_KEY:
            return {
                "error": "Brave API not configured",
                "results": [],
                "result_hash": "",
                "sovereign_signature": ""
            }
        
        try:
            url = "https://api.search.brave.com/res/v1/web/search"
            headers = {
                "Accept": "application/json",
                "X-Subscription-Token": BRAVE_API_KEY
            }
            params = {
                "q": query,
                "count": min(num_results, 20)
            }
            
            response = requests.get(url, headers=headers, params=params, timeout=10)
            data = response.json()
            
            results = []
            if "web" in data and "results" in data["web"]:
                for item in data["web"]["results"]:
                    results.append({
                        "title": item.get("title", ""),
                        "url": item.get("url", ""),
                        "snippet": item.get("description", ""),
                        "source": "brave"
                    })
            
            timestamp = datetime.utcnow().isoformat() + "Z"
            result_hash = EternalSearchEngine.generate_eternal_hash(query, results, timestamp)
            signature = EternalSearchEngine.generate_sovereign_signature(result_hash, timestamp)
            
            return {
                "results": results,
                "result_hash": result_hash,
                "sovereign_signature": signature,
                "timestamp": timestamp
            }
            
        except Exception as e:
            return {
                "error": str(e),
                "results": [],
                "result_hash": "",
                "sovereign_signature": ""
            }
    
    @staticmethod
    def search_duckduckgo(query: str, num_results: int = 10) -> Dict[str, Any]:
        """Search DuckDuckGo (no API key needed)"""
        try:
            url = "https://html.duckduckgo.com/html/"
            data = {"q": query}
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            
            response = requests.post(url, data=data, headers=headers, timeout=10)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            results = []
            for result in soup.find_all('div', class_='result')[:num_results]:
                title_elem = result.find('a', class_='result__a')
                snippet_elem = result.find('a', class_='result__snippet')
                
                if title_elem:
                    results.append({
                        "title": title_elem.get_text(strip=True),
                        "url": title_elem.get('href', ''),
                        "snippet": snippet_elem.get_text(strip=True) if snippet_elem else "",
                        "source": "duckduckgo"
                    })
            
            timestamp = datetime.utcnow().isoformat() + "Z"
            result_hash = EternalSearchEngine.generate_eternal_hash(query, results, timestamp)
            signature = EternalSearchEngine.generate_sovereign_signature(result_hash, timestamp)
            
            return {
                "results": results,
                "result_hash": result_hash,
                "sovereign_signature": signature,
                "timestamp": timestamp
            }
            
        except Exception as e:
            return {
                "error": str(e),
                "results": [],
                "result_hash": "",
                "sovereign_signature": ""
            }


def save_eternal_search(query: str, search_data: Dict[str, Any]) -> str:
    """Save search to eternal archive"""
    timestamp = int(time.time())
    eternal_hash = search_data.get("eternal_hash", "")[:12]
    filename = f"search_{timestamp}_{eternal_hash}.json"
    filepath = os.path.join(ETERNAL_ARCHIVE_DIR, filename)
    
    with open(filepath, 'w') as f:
        json.dump(search_data, f, indent=2)
    
    return filename


# API Routes

@app.route('/')
def index():
    """Serve the main Phoenix Protocol interface"""
    return send_from_directory('static', 'index.html')


@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "active",
        "system": "Phoenix Protocol Eternal Search",
        "architect": PHOENIX_ARCHITECT,
        "hash": PHOENIX_HASH,
        "api_status": {
            "google": bool(GOOGLE_API_KEY and GOOGLE_CX),
            "bing": bool(BING_API_KEY),
            "brave": bool(BRAVE_API_KEY),
            "duckduckgo": True
        }
    })


@app.route('/api/eternal_search', methods=['POST'])
def eternal_search():
    """
    Eternal search across all sources (local + internet)
    Returns cryptographically signed and eternally archived results
    """
    data = request.json
    query = data.get('query', '')
    num_results = data.get('num_results', 10)
    
    if not query:
        return jsonify({"error": "Query required"}), 400
    
    timestamp_utc = datetime.utcnow().isoformat() + "Z"
    
    # Search all sources
    sources = {}
    
    # Internet sources
    sources['google'] = EternalSearchEngine.search_google(query, num_results)
    sources['bing'] = EternalSearchEngine.search_bing(query, num_results)
    sources['brave'] = EternalSearchEngine.search_brave(query, num_results)
    sources['duckduckgo'] = EternalSearchEngine.search_duckduckgo(query, num_results)
    
    # Combine all results
    all_results = []
    for source_name, source_data in sources.items():
        all_results.extend(source_data.get('results', []))
    
    # Generate eternal hash for combined search
    eternal_hash = EternalSearchEngine.generate_eternal_hash(query, all_results, timestamp_utc)
    
    search_data = {
        "query": query,
        "timestamp_utc": timestamp_utc,
        "eternal_hash": eternal_hash,
        "sovereign_architect": PHOENIX_ARCHITECT,
        "phoenix_hash": PHOENIX_HASH,
        "sources": sources,
        "total_results": len(all_results)
    }
    
    # Save to eternal archive
    filename = save_eternal_search(query, search_data)
    search_data['archive_file'] = filename
    
    return jsonify(search_data)


@app.route('/api/web_search', methods=['POST'])
def web_search():
    """Internet-only search (no local sources)"""
    data = request.json
    query = data.get('query', '')
    sources = data.get('sources', ['google', 'bing', 'duckduckgo', 'brave'])
    num_results = data.get('num_results', 10)
    
    if not query:
        return jsonify({"error": "Query required"}), 400
    
    timestamp_utc = datetime.utcnow().isoformat() + "Z"
    results = {}
    
    if 'google' in sources:
        results['google'] = EternalSearchEngine.search_google(query, num_results)
    if 'bing' in sources:
        results['bing'] = EternalSearchEngine.search_bing(query, num_results)
    if 'brave' in sources:
        results['brave'] = EternalSearchEngine.search_brave(query, num_results)
    if 'duckduckgo' in sources:
        results['duckduckgo'] = EternalSearchEngine.search_duckduckgo(query, num_results)
    
    return jsonify({
        "query": query,
        "timestamp_utc": timestamp_utc,
        "sources": results
    })


@app.route('/api/eternal_archive', methods=['GET'])
def get_eternal_archive():
    """Get list of all eternal searches"""
    searches = []
    for filename in os.listdir(ETERNAL_ARCHIVE_DIR):
        if filename.endswith('.json'):
            filepath = os.path.join(ETERNAL_ARCHIVE_DIR, filename)
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                    searches.append({
                        "filename": filename,
                        "query": data.get("query", ""),
                        "timestamp": data.get("timestamp_utc", ""),
                        "total_results": data.get("total_results", 0),
                        "eternal_hash": data.get("eternal_hash", "")
                    })
            except:
                continue
    
    # Sort by timestamp descending
    searches.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
    
    return jsonify({
        "total_searches": len(searches),
        "searches": searches
    })


@app.route('/api/eternal_archive/<filename>', methods=['GET'])
def get_eternal_search(filename):
    """Get specific eternal search by filename"""
    filepath = os.path.join(ETERNAL_ARCHIVE_DIR, filename)
    
    if not os.path.exists(filepath):
        return jsonify({"error": "Search not found"}), 404
    
    with open(filepath, 'r') as f:
        data = json.load(f)
    
    return jsonify(data)


if __name__ == '__main__':
    print("🐦‍🔥 Phoenix Protocol - Eternal Search API")
    print(f"Architect: {PHOENIX_ARCHITECT}")
    print(f"Hash: {PHOENIX_HASH}")
    print("\nAPI Status:")
    print(f"  Google: {'✅' if GOOGLE_API_KEY and GOOGLE_CX else '❌ (set GOOGLE_API_KEY and GOOGLE_CX)'}")
    print(f"  Bing: {'✅' if BING_API_KEY else '❌ (set BING_API_KEY)'}")
    print(f"  Brave: {'✅' if BRAVE_API_KEY else '❌ (set BRAVE_API_KEY)'}")
    print(f"  DuckDuckGo: ✅ (no key required)")
    print("\nStarting server on http://localhost:5001")
    print("Eternal searches saved to:", ETERNAL_ARCHIVE_DIR)
    
    app.run(host='0.0.0.0', port=5001, debug=True)
