# Phoenix DAO — Proposal Bundle: DAO-476-HYPERBOLIC-UPGRADE

This bundle contains governance-ready artifacts for posting the proposal to Snapshot (off-chain) or an OpenZeppelin Governor (on-chain).

## Files

- `proposal_476.md` — Human-readable Markdown.
- `proposal_476.snapshot.json` — Snapshot-compatible JSON payload.
- `proposal_476.governor.json` — OZ Governor/Bravo action stub (fill targets/signatures/calldatas if executing on-chain).
- `proposal_476.metadata.json` — Compact IPFS/storage metadata.
- `hashes.txt` — SHA-256 hashes for all files (below).

## Snapshot Posting
1. Create a new proposal in your Snapshot space.
2. Paste the contents of `proposal_476.md` into the body.
3. Choices: YES, NO. Set voting window as desired (defaults encoded for ~3 days from now).
4. Optionally upload the Phoenix glyph image.
5. Publish; then pin `proposal_476.snapshot.json` to IPFS if your workflow supports programmatic posting.

## On-Chain (OZ Governor / Governor Bravo)
- Fill `targets`, `values`, `signatures`, and `calldatas` in `proposal_476.governor.json` with your registry contract call(s).
- Example (ABI): `setScrollStatus(uint256 id, bool ratified)` where id=476 and ratified=true.

## Provenance Anchoring
- Hash this folder and timestamp via OpenTimestamps:
  - `tar -czf dao-476-bundle.tgz dao-476-bundle/`
  - `sha256sum dao-476-bundle.tgz` → record
  - `ots stamp dao-476-bundle.tgz`
- Mirror the SHA-256 in an OP_RETURN note for redundancy.

