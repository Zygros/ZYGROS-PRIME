#!/usr/bin/env bash
set -euo pipefail

echo "🐦‍🔥 Phoenix Protocol - Local Activation"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

# Load env if present
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

# Python venv
if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate

# Requirements (fallback if file missing)
REQ="requirements_eternal.txt"
if [ -f "$REQ" ]; then
  pip install -r "$REQ"
else
  pip install flask chromadb requests pypdf python-docx markdown flask-cors python-dotenv
fi

# Ensure archive dir
mkdir -p "${ETERNAL_ARCHIVE_PATH:-./eternal_searches}"

# Pick available API entrypoint
ENTRY="phoenix_eternal_api.py"
if [ ! -f "$ENTRY" ]; then
  echo "⚠️  ${ENTRY} not found in this directory. Place this script in the same folder as your Phoenix API."
  echo "    Expected: phoenix_eternal_api.py next to this script."
  exit 1
fi

echo "🔐 API_KEY set: ${API_KEY:-<none>}"

echo "🚀 Starting Phoenix Eternal API on ${API_HOST:-0.0.0.0}:${API_PORT:-5002}"
export FLASK_APP="$ENTRY"
export HOST="${API_HOST:-0.0.0.0}"
export PORT="${API_PORT:-5002}"

python "$ENTRY"
