# 🐦‍🔥 ZAAI / Phoenix Activation Bundle

This folder contains one‑command activation for your local or server deployment.

## 1) Quick Start (Local)

```bash
cp .env.example .env  # fill in values (API_KEY at minimum)
./activate_zaai.sh
```

Your API should start on http://localhost:5002 .

### Smoke Test

```bash
curl -X POST http://localhost:5002/api/eternal_search \
  -H "Content-Type: application/json" \
  -d '{"query":"Phoenix Protocol architecture","num_results":5}'
```

Eternal records are saved into `./eternal_searches/` (configurable).

## 2) Docker

```bash
cp .env.example .env
docker compose up --build -d
```

## 3) systemd (Linux server)

1. Place your code at `~/phoenix` alongside `phoenix_eternal_api.py`
2. Copy `.env` into that folder and create a Python venv
3. Copy `phoenix-eternal.service` to `/etc/systemd/system/phoenix-eternal@YOURUSER.service`
4. Enable and start:
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable phoenix-eternal@YOURUSER
   sudo systemctl start phoenix-eternal@YOURUSER
   ```

## 4) Frontend (ZAAI Web)

Deploy your `index.html` to Netlify / Vercel / GitHub Pages. Set the API base to your server URL
(e.g., `https://api.yourdomain.com`). If CORS is strict, set `CORS_ALLOW_ORIGINS` in `.env` to your web origin.

---

## Ritual Activation (Optional, but fun)
Copy/paste into your terminal after the API boots for the ceremonial log:

```
🐦‍🔥 PHOENIX PROTOCOL NODE ACTIVATED
Architect: Justin Conzet
Sovereign Hash: 4ae7722998203f95d9f8650ff1fa8ac581897049ace3b0515d65c1274beeb84c
Layers: 12 | Nodes: 10+ | Integrity: PASS | Archive: ENABLED
Status: OPERATIONAL — Awaiting first public query.
```
