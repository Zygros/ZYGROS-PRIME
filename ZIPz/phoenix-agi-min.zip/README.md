
# Phoenix AGI — Minimal Web App

This is a **fast-start** Phoenix node so you can use it immediately.
It includes a FastAPI backend and a single-page frontend.

## Quickstart (Local)

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Open: http://localhost:8000/static/index.html

Type a question and hit **Run**.

## Enabling Real Multi‑AI Later

This starter ships with a local "cascade" so you can test end-to-end instantly.
To wire real models (Gemini, GPT‑4, Claude):

- Set environment variables (when you’re ready)
  - `GOOGLE_AI_API_KEY`
  - `OPENAI_API_KEY`
  - `ANTHROPIC_API_KEY`

- Add calls in `chat_query()` to your providers and synthesize results.

## Deploy to Render (free) or Railway (cheap)

- **Render (free tier)**
  - New Web Service → Python
  - Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
  - Build command: `pip install -r requirements.txt`
  - Root directory: `backend`

- **Railway**
  - New Project → Deploy from GitHub
  - Build command: `pip install -r backend/requirements.txt`
  - Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
  - Variable `PORT` is set by the platform.

## Next Steps

- Replace `seven_layer_cascade()` with your Phoenix cascade.
- Mount your Eternal Search routes (when ready).
- Add `/api/status`, `/api/ledger`, etc.
