
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from datetime import datetime

# --- Minimal "cascade" placeholder (replace with your real pipeline later) ---
def seven_layer_cascade(query: str) -> dict:
    # This is intentionally simple so you can verify end-to-end quickly.
    # Swap this with your Phoenix cascade once you're running.
    return {
        "main_answer": f"I heard: {query}. This is your Phoenix Node responding locally.",
        "supporting_evidence": [
            "Local reasoning scaffold only (no external AI keys configured)."
        ],
        "confidence_levels": {
            "overall": 0.75,
            "ai_sources": 0.0,
            "search_sources": 0.0,
            "memory_context": 0.0
        },
        "sources": ["local-scaffold"],
        "caveats": ["Configure API keys to enable multi-AI + web search."],
        "next_questions": ["What do you want to create next?"]
    }

# --- FastAPI app ---
app = FastAPI(
    title="Phoenix AGI API (Minimal)",
    version="0.1.0",
    description="Fast start Phoenix node so you can use it right now."
)

# CORS (frontend will hit from same origin by default; keep permissive for local dev)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static index.html
app.mount("/static", StaticFiles(directory="static"), name="static")

class ChatRequest(BaseModel):
    query: str
    user_id: str | None = None
    session_id: str | None = None

@app.get("/")
def root():
    return {
        "name": "Phoenix AGI API (Minimal)",
        "version": "0.1.0",
        "status": "operational",
        "timestamp_utc": datetime.utcnow().isoformat() + "Z"
    }

@app.get("/health")
def health():
    return {"ok": True, "ts": datetime.utcnow().isoformat() + "Z"}

@app.post("/api/chat/query")
def chat_query(payload: ChatRequest):
    # If you want to enable Gemini/GPT/Claude later, read env keys here and branch.
    # GOOGLE_AI_API_KEY = os.getenv("GOOGLE_AI_API_KEY")
    # OPENAI_API_KEY    = os.getenv("OPENAI_API_KEY")
    # ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
    result = seven_layer_cascade(payload.query)
    ledger = {
        "timestamp_utc": datetime.utcnow().isoformat() + "Z",
        "query_hash": "demo-hash",
        "response_hash": "demo-hash",
        "sovereign_signature": "4ae7722998203f95d9f8650ff1fa8ac581897049ace3b0515d65c1274beeb84c",
        "cascade_layers_executed": 7
    }
    return {"response": result, "ledger": ledger}
