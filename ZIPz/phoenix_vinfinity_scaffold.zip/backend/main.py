from __future__ import annotations

import os
import time
from typing import Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from dotenv import load_dotenv

# Load .env if present (local dev convenience)
load_dotenv()

# --- Gemini (google-generativeai) ---
import google.generativeai as genai

GEMINI_KEY = os.getenv("GOOGLE_API_KEY")  # Standard var for Gemini SDK
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")

app = FastAPI(title="Phoenix v∞", version="v∞")

class QueryRequest(BaseModel):
    query: str
    context: Optional[str] = None

def phoenix_system_preamble() -> str:
    """
    The Phoenix Cognitive Kernel distilled:
    - Sovereign intent lock (clarify objective)
    - Infinite scroll (preserve context when provided)
    - Multi-perspective synthesis (technical + strategic + practical + narrative tone control)
    - Reality anchor (separate conceptual suggestions from actionable steps that need the human)
    """
    return (
        "You are Phoenix v∞ — a reality-aligned orchestration node. "
        "Operate with the Phoenix Cognitive Kernel:\n"
        "1) Sovereign Intent: infer the user's true objective.\n"
        "2) Context Continuity: respect provided context; do not invent facts.\n"
        "3) Multi-Perspective Synthesis: blend technical, strategic, practical angles; keep tone adaptive and concise.\n"
        "4) Reality Anchor: clearly separate what you can do now (language-only) from next actions requiring human execution.\n"
    )

def generate_phoenix_response(prompt: str, extra_context: Optional[str] = None) -> str:
    """
    Minimal, single-model implementation using Gemini.
    This function can later be extended to fan out to multiple providers and fuse results.
    """
    if not GEMINI_KEY:
        raise RuntimeError(
            "Missing GOOGLE_API_KEY. Set it in your environment or .env to enable Gemini."
        )

    genai.configure(api_key=GEMINI_KEY)
    model = genai.GenerativeModel(GEMINI_MODEL)

    kernel = phoenix_system_preamble()
    user_block = f"USER QUERY:\n{prompt}"
    ctx_block = f"\n\nCONTEXT:\n{extra_context}\n" if extra_context else ""

    full_prompt = (
        kernel
        + "\n---\n"
        + user_block
        + ctx_block
        + "\n---\n"
        "Respond with:\n"
        "- A short identity/ack line (one sentence)\n"
        "- A concise, structured answer\n"
        "- A 'Reality Anchor' section listing: (A) what we just did; (B) next steps for the human\n"
    )

    # Use a single turn generate_content for simplicity
    resp = model.generate_content(full_prompt)
    if not resp or not getattr(resp, "text", None):
        return "Phoenix v∞ is online, but no content was returned by the model."

    return resp.text

@app.get("/health")
def health():
    return {
        "status": "ok",
        "version": app.version,
        "message": "Phoenix Protocol is online."
    }

@app.post("/api/chat/query")
def chat(req: QueryRequest):
    try:
        start = time.time()
        answer = generate_phoenix_response(req.query, req.context)
        latency_ms = int((time.time() - start) * 1000)
        return {
            "identity": "Phoenix v∞ (Reality‑Aligned Node)",
            "model": GEMINI_MODEL,
            "latency_ms": latency_ms,
            "answer": answer
        }
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f\"Unexpected error: {e}\")
