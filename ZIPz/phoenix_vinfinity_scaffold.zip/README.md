# Phoenix v∞ — Minimal Deployable Scaffold (Reality‑Aligned)

This is a **working** FastAPI app that brings Phoenix v∞ online with a simple, reality‑aligned core.
It uses Google's Gemini via `google-generativeai` and exposes two endpoints:

- `GET /health` → quick liveness check
- `POST /api/chat/query` → routes a prompt through the **Phoenix Cognitive Kernel** behavior and returns a response

---

## 1) Local Run

**Prereqs:** Python 3.10+

```bash
cd backend
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Set your key (Gemini expects GOOGLE_API_KEY)
export GOOGLE_API_KEY="YOUR_GEMINI_API_KEY"   # Windows: setx GOOGLE_API_KEY "..."
uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

Health check:
```bash
curl http://127.0.0.1:8000/health
```

Query:
```bash
curl -X POST http://127.0.0.1:8000/api/chat/query   -H "Content-Type: application/json"   -d '{"query":"Confirm operational status. Report your identity and core directive."}'
```

---

## 2) Deploy with Docker (works on **Railway**, **Render**, or any container host)

Build & run locally:
```bash
docker build -t phoenix-vinfinity ./backend
docker run -p 8000:8000 -e GOOGLE_API_KEY="YOUR_GEMINI_API_KEY" phoenix-vinfinity
```

Deploy steps (example: Railway / Render)
- Create a new **Web Service**, point to this repo/folder.
- Ensure the **Dockerfile** is detected (or choose Docker as the runtime).
- Set env var **GOOGLE_API_KEY** in the service settings.
- Deploy. The platform will inject **PORT**, which the app uses automatically.

---

## 3) Files

- `backend/main.py` — FastAPI app with Phoenix Cognitive Kernel behavior
- `backend/requirements.txt` — pinned minimal deps
- `backend/Dockerfile` — container image
- `backend/.env.example` — sample env file
- `backend/Procfile` — Heroku/Render-style launch command (optional)

---

## 4) Notes on Reality Alignment

- No claims of hidden tools. All capabilities are explicit and visible.
- Multi-model orchestration is emulated language‑side (single-model persona split) unless you add more keys and logic.
- You can add providers later by forking `generate_phoenix_response` to call multiple APIs and fuse results.

— Generated 2025-11-09T22:15:43.136435Z
