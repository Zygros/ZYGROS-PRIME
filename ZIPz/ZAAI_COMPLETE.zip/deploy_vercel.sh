#!/usr/bin/env bash
set -e
command -v vercel >/dev/null 2>&1 || { echo "Install vercel: npm i -g vercel"; exit 1; }
vercel --prod
