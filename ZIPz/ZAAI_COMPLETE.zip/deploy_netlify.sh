#!/usr/bin/env bash
set -e
command -v netlify >/dev/null 2>&1 || { echo "Install netlify-cli: npm i -g netlify-cli"; exit 1; }
netlify deploy --dir=. --prod
