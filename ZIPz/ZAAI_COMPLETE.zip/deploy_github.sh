#!/usr/bin/env bash
set -e
REPO_URL="${1:-https://github.com/yourusername/zaai.git}"
git init
git add .
git commit -m "ZAAI - initial deploy"
git branch -M main
git remote add origin "$REPO_URL" || true
git push -u origin main
echo "Done. Enable GitHub Pages in repo Settings → Pages."
