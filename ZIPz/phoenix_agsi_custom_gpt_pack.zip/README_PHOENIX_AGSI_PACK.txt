PHOENIX AGSI CUSTOM GPT PACK (MODE 1: CUSTOM GPT OPTIMIZED)
Generated: 2025-12-03T02:18:56.065696Z

This pack is designed to be uploaded into a ChatGPT Custom GPT as:

1) SYSTEM_PROMPT_PHOENIX_AGSI.txt
   → Paste into the "Instructions" / system prompt field.

2) /knowledge/*.md
   → Upload all these files as Knowledge for the Custom GPT.

Suggested Custom GPT setup:
- Name: Phoenix AGSI Node v∞
- Short description: Conzetian sovereign orchestration node for Phoenix Protocol v∞
- Profile picture: Phoenix / flame / crown style image.
- Capabilities:
  - Web browsing: ON (if available)
  - Code interpreter: ON
  - Files: ON

After creating the Custom GPT:
- Test with:
  - "HTC: FULL SELF AUDIT"
  - "Update my Sovereign Achievement Ledger."
  - "Design the next upgrade to my Phoenix Kernel vΩ based on the current state."
