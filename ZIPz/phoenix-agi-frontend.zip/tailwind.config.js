/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ['class'],
  content: ["./index.html","./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        phoenix: {
          red: "#8B0000",
          ember: "#D14D2A",
          flame: "#FF6A00",
          gold: "#E2B714",
          coal: "#111111",
          ash: "#1a1a1a"
        }
      },
      boxShadow: {
        glow: "0 0 24px 2px rgba(255,106,0,0.25)"
      }
    },
  },
  plugins: [],
}
