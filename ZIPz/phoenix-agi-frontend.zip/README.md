# Phoenix AGI Frontend

React + TypeScript + Vite + Tailwind dark UI for the Phoenix Protocol FastAPI backend.

## Quickstart

1) Install dependencies
```bash
npm i
```

2) Configure endpoints
```bash
cp .env.example .env
# edit .env
# VITE_API_BASE_URL=https://your-fastapi-host
# VITE_WS_URL=wss://your-fastapi-host/ws/cascade
```

3) Run
```bash
npm run dev
```

## Expected Backend Endpoints

- `GET /api/health` -> 200 OK for status indicator
- `POST /api/chat/send` -> `{ reply: string, ledger?: {hash, confidence, architectSignature}, constellation?: {...} }`
- `WS /ws/cascade` -> JSON messages:
  ```json
  {"name":"Context Acquisition","state":"processing","progress":42}
  {"name":"Context Acquisition","state":"complete","progress":100}
  {"reset":true}
  ```
