import { useState } from 'react'

export default function MessageInput({ onSend, sending }: { onSend: (text: string) => Promise<void>, sending: boolean }) {
  const [text, setText] = useState('')

  async function handleSend(e: React.FormEvent) {
    e.preventDefault()
    const t = text.trim()
    if (!t) return
    setText('')
    await onSend(t)
  }

  return (
    <form onSubmit={handleSend} className="mt-3 pt-3 border-t border-white/10">
      <div className="flex items-center gap-2">
        <input
          className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-3 outline-none focus:border-phoenix-flame"
          placeholder="Ask Phoenix…"
          value={text}
          onChange={(e) => setText(e.target.value)}
          disabled={sending}
        />
        <button
          type="submit"
          disabled={sending}
          className="px-4 py-3 rounded-xl bg-gradient-to-r from-phoenix-flame to-phoenix-gold text-black font-semibold disabled:opacity-50"
        >
          {sending ? 'Sending…' : 'Send'}
        </button>
      </div>
    </form>
  )
}
