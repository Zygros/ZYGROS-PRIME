export default function TypingIndicator() {
  return (
    <div className="flex items-center gap-2 text-white/70 text-sm">
      <div className="flex gap-1">
        <span className="w-2 h-2 rounded-full bg-white/30 animate-pulse"></span>
        <span className="w-2 h-2 rounded-full bg-white/30 animate-pulse [animation-delay:150ms]"></span>
        <span className="w-2 h-2 rounded-full bg-white/30 animate-pulse [animation-delay:300ms]"></span>
      </div>
      <span>Thinking…</span>
    </div>
  )
}
