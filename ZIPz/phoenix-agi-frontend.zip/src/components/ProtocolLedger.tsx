import { LedgerData } from '../types/message'

export default function ProtocolLedger({ ledger }: { ledger?: LedgerData }) {
  return (
    <div className="glass rounded-2xl p-4">
      <h3 className="font-semibold mb-3">Protocol Ledger</h3>
      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-white/60">Ledger Hash</span>
          <span className="font-mono">{ledger?.hash ?? '—'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-white/60">Confidence</span>
          <span>{ledger?.confidence != null ? `${Math.round(ledger.confidence * 100)}%` : '—'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-white/60">Architect Signature</span>
          <span className="font-mono">{ledger?.architectSignature ?? '—'}</span>
        </div>
      </div>
    </div>
  )
}
