import { ConstellationStatus } from '../types/message'

function Badge({ label, state }: { label: string, state?: 'idle' | 'working' | 'done' }) {
  const map: Record<string, string> = {
    idle: 'bg-white/10 text-white/70',
    working: 'bg-amber-500/20 text-amber-300',
    done: 'bg-green-500/20 text-green-300'
  }
  return <span className={`px-2 py-1 rounded-lg text-xs ${map[state ?? 'idle']}`}>{label}: {state ?? 'idle'}</span>
}

export default function MultiAIDisplay({ constellation }: { constellation?: ConstellationStatus }) {
  return (
    <div className="glass rounded-2xl p-4">
      <h3 className="font-semibold mb-3">Constellation Synthesis</h3>
      <div className="flex flex-wrap gap-2">
        <Badge label="GPT‑4" state={constellation?.gpt4} />
        <Badge label="Claude" state={constellation?.claude} />
        <Badge label="Gemini" state={constellation?.gemini} />
        <Badge label="Grok" state={constellation?.grok} />
      </div>
    </div>
  )
}
