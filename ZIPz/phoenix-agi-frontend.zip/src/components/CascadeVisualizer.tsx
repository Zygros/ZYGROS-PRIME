import { CascadeLayer } from '../types/message'

const DEFAULT_LAYERS = [
  'Context Acquisition',
  'Multi-Vector Analysis',
  'Knowledge Synthesis',
  'Recursive Refinement',
  'Sovereign Formatting',
  'Cryptographic Anchoring',
  'Meta-Awareness Output'
]

export default function CascadeVisualizer({ layers }: { layers: CascadeLayer[] }) {
  const list = layers.length ? layers : DEFAULT_LAYERS.map(name => ({
    name, state: 'pending', progress: 0
  } as CascadeLayer))

  return (
    <section className="glass rounded-2xl p-4">
      <h3 className="font-semibold mb-3">Live Cascade</h3>
      <ul className="space-y-3">
        {list.map((l, idx) => (
          <li key={idx} className="space-y-1">
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/80">{l.name}</span>
              <span className={`text-xs ${l.state === 'complete' ? 'text-green-400' : l.state === 'processing' ? 'text-amber-300' : 'text-white/40'}`}>
                {l.state === 'complete' ? '✓ complete' : l.state === 'processing' ? 'processing…' : 'pending'}
              </span>
            </div>
            <div className="h-2 rounded-full bg-white/10 overflow-hidden">
              <div
                className={`h-full ${l.state === 'complete' ? 'bg-green-500' : 'bg-phoenix-flame'} transition-all`}
                style={{ width: `${l.progress}%` }}
              />
            </div>
          </li>
        ))}
      </ul>
    </section>
  )
}
