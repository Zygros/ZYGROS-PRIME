export default function SystemStatus({ connected }: { connected: boolean }) {
  return (
    <div className="glass rounded-2xl p-4 flex items-center justify-between">
      <div>
        <h3 className="font-semibold">System Status</h3>
        <p className="text-sm text-white/60">FastAPI Connection</p>
      </div>
      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${connected ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>
        {connected ? 'connected' : 'disconnected'}
      </span>
    </div>
  )
}
