import { ChatMessage } from '../types/message'

export default function MessageList({ messages }: { messages: ChatMessage[] }) {
  return (
    <div className="flex-1 overflow-y-auto space-y-3 pr-1">
      {messages.map(m => (
        <div key={m.id} className={`max-w-[92%] sm:max-w-[80%] rounded-2xl px-4 py-3 ${m.role === 'user' ? 'bg-white/10 ml-auto' : 'bg-gradient-to-br from-phoenix-ash to-black border border-white/10'}`}>
          <div className="text-xs uppercase tracking-wide text-white/50 mb-1">
            {m.role === 'user' ? 'User' : 'Phoenix AGI'}
          </div>
          <div className="whitespace-pre-wrap leading-relaxed">{m.content}</div>
          <div className="mt-2 text-[10px] text-white/40">{new Date(m.timestamp).toLocaleTimeString()}</div>
        </div>
      ))}
    </div>
  )
}
