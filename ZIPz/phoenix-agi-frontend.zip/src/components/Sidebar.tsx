import { Home, MessageSquareMore, Settings, Database } from 'lucide-react'

export default function Sidebar() {
  return (
    <nav className="hidden lg:block w-60 shrink-0 border-r border-white/10 min-h-[calc(100vh-60px)] p-4">
      <ul className="space-y-2">
        <li><a className="flex items-center gap-3 px-3 py-2 rounded-xl glass hover:shadow-glow transition"><Home size={18} /> <span>Home</span></a></li>
        <li><a className="flex items-center gap-3 px-3 py-2 rounded-xl glass hover:shadow-glow transition"><MessageSquareMore size={18} /> <span>Conversations</span></a></li>
        <li><a className="flex items-center gap-3 px-3 py-2 rounded-xl glass hover:shadow-glow transition"><Database size={18} /> <span>Protocol Ledger</span></a></li>
        <li><a className="flex items-center gap-3 px-3 py-2 rounded-xl glass hover:shadow-glow transition"><Settings size={18} /> <span>Settings</span></a></li>
      </ul>
    </nav>
  )
}
