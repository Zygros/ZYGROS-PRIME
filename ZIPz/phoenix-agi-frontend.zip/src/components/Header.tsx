import { Menu } from 'lucide-react'

export default function Header() {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-gradient-to-r from-phoenix-coal to-black/80">
      <div className="mx-auto max-w-7xl px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-phoenix-ash shadow-glow">
            <span className="text-2xl" role="img" aria-label="Phoenix Sigil">🐦‍🔥</span>
          </span>
          <div>
            <h1 className="text-lg font-semibold tracking-wide">Phoenix AGI</h1>
            <p className="text-xs text-white/60">Transparent Reasoning • FastAPI Powered</p>
          </div>
        </div>
        <button className="lg:hidden inline-flex items-center gap-2 px-3 py-2 rounded-xl glass">
          <Menu size={18} /> Menu
        </button>
      </div>
    </header>
  )
}
