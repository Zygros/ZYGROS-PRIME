import Header from './components/Header'
import Sidebar from './components/Sidebar'
import MessageList from './components/MessageList'
import MessageInput from './components/MessageInput'
import CascadeVisualizer from './components/CascadeVisualizer'
import SystemStatus from './components/SystemStatus'
import ProtocolLedger from './components/ProtocolLedger'
import MultiAIDisplay from './components/MultiAIDisplay'
import { useChat } from './hooks/useChat'
import { useCascadeSocket } from './hooks/useCascadeSocket'

export default function App() {
  const { messages, sending, sendMessage, connection, ledger, constellation } = useChat()
  const { layers } = useCascadeSocket()

  return (
    <div className="min-h-screen bg-gradient-to-b from-phoenix-coal to-black">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-3 sm:p-4 lg:p-6 gap-4 grid grid-cols-1 lg:grid-cols-3">
          <section className="lg:col-span-2 glass rounded-2xl p-3 sm:p-4">
            <div className="h-[calc(100vh-220px)] sm:h-[calc(100vh-210px)] lg:h-[calc(100vh-220px)] flex flex-col">
              <MessageList messages={messages} />
              <MessageInput onSend={sendMessage} sending={sending} />
            </div>
          </section>
          <aside className="lg:col-span-1 space-y-4">
            <CascadeVisualizer layers={layers} />
            <div className="grid grid-cols-1 gap-4">
              <SystemStatus connected={connection === 'connected'} />
              <ProtocolLedger ledger={ledger} />
              <MultiAIDisplay constellation={constellation} />
            </div>
          </aside>
        </main>
      </div>
    </div>
  )
}
