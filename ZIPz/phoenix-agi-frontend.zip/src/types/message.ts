export type Role = 'user' | 'phoenix'

export interface ChatMessage {
  id: string
  role: Role
  content: string
  timestamp: number
}

export type LayerState = 'pending' | 'processing' | 'complete'

export interface CascadeLayer {
  name: string
  state: LayerState
  progress: number // 0-100
}

export interface LedgerData {
  hash?: string
  confidence?: number
  architectSignature?: string
}

export interface ConstellationStatus {
  gpt4?: 'idle' | 'working' | 'done'
  claude?: 'idle' | 'working' | 'done'
  gemini?: 'idle' | 'working' | 'done'
  grok?: 'idle' | 'working' | 'done'
}
