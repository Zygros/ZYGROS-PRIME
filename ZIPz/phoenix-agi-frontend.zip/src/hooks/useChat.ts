import { useEffect, useMemo, useRef, useState } from 'react'
import type { ChatMessage, ConstellationStatus, LedgerData } from '../types/message'

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'

type ConnectionState = 'connected' | 'disconnected'

export function useChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [sending, setSending] = useState(false)
  const [connection, setConnection] = useState<ConnectionState>('disconnected')
  const [ledger, setLedger] = useState<LedgerData | undefined>()
  const [constellation, setConstellation] = useState<ConstellationStatus | undefined>()
  const pingTimer = useRef<number | null>(null)

  useEffect(() => {
    let active = true
    const check = async () => {
      try {
        const res = await fetch(`${API_BASE}/api/health`)
        if (!active) return
        setConnection(res.ok ? 'connected' : 'disconnected')
      } catch {
        if (!active) return
        setConnection('disconnected')
      }
    }
    check()
    pingTimer.current = window.setInterval(check, 5000)
    return () => {
      active = false
      if (pingTimer.current) window.clearInterval(pingTimer.current)
    }
  }, [])

  const sendMessage = useMemo(() => {
    return async (text: string) => {
      setSending(true)
      const myMsg: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'user',
        content: text,
        timestamp: Date.now()
      }
      setMessages(prev => [...prev, myMsg])

      try {
        const res = await fetch(`${API_BASE}/api/chat/send`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: text })
        })
        if (!res.ok) throw new Error('send failed')
        const data = await res.json()
        const phoenix: ChatMessage = {
          id: crypto.randomUUID(),
          role: 'phoenix',
          content: data.reply ?? '(no content)',
          timestamp: Date.now()
        }
        setMessages(prev => [...prev, phoenix])
        setLedger(data.ledger)
        setConstellation(data.constellation)
      } catch (e) {
        const err: ChatMessage = {
          id: crypto.randomUUID(),
          role: 'phoenix',
          content: 'Error: could not reach backend. Check VITE_API_BASE_URL.',
          timestamp: Date.now()
        }
        setMessages(prev => [...prev, err])
      } finally {
        setSending(false)
      }
    }
  }, [])

  return { messages, sending, sendMessage, connection, ledger, constellation }
}
