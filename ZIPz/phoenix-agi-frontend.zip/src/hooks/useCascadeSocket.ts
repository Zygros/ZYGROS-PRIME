import { useEffect, useRef, useState } from 'react'
import type { CascadeLayer } from '../types/message'

const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8000/ws/cascade'

const INITIAL: CascadeLayer[] = [
  'Context Acquisition',
  'Multi-Vector Analysis',
  'Knowledge Synthesis',
  'Recursive Refinement',
  'Sovereign Formatting',
  'Cryptographic Anchoring',
  'Meta-Awareness Output'
].map(name => ({ name, state: 'pending', progress: 0 } as CascadeLayer))

export function useCascadeSocket() {
  const [layers, setLayers] = useState<CascadeLayer[]>(INITIAL)
  const socketRef = useRef<WebSocket | null>(null)
  const retry = useRef<number>(0)

  useEffect(() => {
    let closed = false

    function connect() {
      try {
        const ws = new WebSocket(WS_URL)
        socketRef.current = ws

        ws.onopen = () => {
          retry.current = 0
        }

        ws.onmessage = (ev) => {
          try {
            const msg = JSON.parse(ev.data)
            if (msg.reset) {
              setLayers(INITIAL)
              return
            }
            setLayers(prev => {
              const next = prev.map(layer => {
                if (layer.name === msg.name) {
                  return {
                    ...layer,
                    state: msg.state ?? layer.state,
                    progress: typeof msg.progress === 'number' ? msg.progress : layer.progress
                  }
                }
                return layer
              })
              return next
            })
          } catch {}
        }

        ws.onclose = () => {
          if (closed) return
          const timeout = Math.min(1000 * (2 ** retry.current), 15000)
          retry.current += 1
          setTimeout(connect, timeout)
        }
      } catch {
        const timeout = Math.min(1000 * (2 ** retry.current), 15000)
        retry.current += 1
        setTimeout(connect, timeout)
      }
    }

    connect()
    return () => {
      closed = true
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close()
      }
    }
  }, [])

  return { layers }
}
