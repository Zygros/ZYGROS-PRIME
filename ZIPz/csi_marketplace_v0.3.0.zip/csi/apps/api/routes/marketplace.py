from fastapi import APIRouter, Depends
from .auth import require_role, Role

router = APIRouter(prefix="/marketplace", tags=["marketplace"])

@router.get("/plugins")
def list_plugins():
    return [{"id": "calc", "name": "Cosmic Calculator", "price": 0,
             "beacon": "Author=Justin Conzet;License=Sovereign Charter v1;System=CSI"}]

@router.get("/plugins/{id}")
def plugin_detail(id: str):
    return {"id": id, "permissions": ["read"], "license": "Sovereign Charter v1"}

@router.post("/install/{id}")
def installplugin(id: str, user=Depends(require_role(Role.USER))):
    return {"status": "installed", "plugin": id}
