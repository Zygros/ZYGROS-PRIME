# CSI Marketplace Changelog

## v0.3.0
- Added plugin submission consent modal
- Implemented CLA signature flow
- Improved audit logging
