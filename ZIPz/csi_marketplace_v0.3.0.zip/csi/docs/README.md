# CSI Marketplace v0.3.0

**Author:** Justin Conzet  
**License:** Sovereign Charter v1  
**System:** CSI  

## Quick Start

1. Clone repo and navigate into `csi/`.
2. Run Docker services: `docker-compose up --build`
3. Seed database: `psql "$POSTGRES_URL" -f scripts/seed.sql`
4. Start API: `uvicorn apps.api.main:app --reload`
5. Start Web: `cd apps/web && npm install && npm run dev`

Your marketplace will be available at http://localhost:3000
