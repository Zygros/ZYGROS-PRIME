#!/usr/bin/env python3
"""
PRAXSKIN Visual UI System for Praxeon

This module implements the advanced visual UI system that represents
the user's energy flow and chakra state in real-time.
"""

import os
import sys
import json
import logging
import time
import math
import random
from typing import Dict, Any, Optional, List, Tuple

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxeon.ui.praxskin")

class PraxskinSystem:
    """
    Implementation of the PRAXSKIN visual UI system.
    
    This class provides:
    - Dynamic chakra-based color gradients
    - Pulsing aura field animations
    - Glyphic cursor system
    - Energy-based transitions
    - Scroll-inspired layouts
    - Voice visualization
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize the PRAXSKIN system
        
        Args:
            config_path: Path to configuration file
        """
        self.config_path = config_path or os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 
            "../../resources/ui/praxskin_config.json"
        )
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        
        # Load or create configuration
        self.config = self._load_or_create_config()
        
        # Initialize state
        self.state = {
            "current_chakra": "heart",  # Default to heart chakra
            "energy_level": 0.7,  # 0.0 to 1.0
            "aura_density": 0.5,  # 0.0 to 1.0
            "aura_color": "#4CAF50",  # Default green
            "cursor_rotation": 0.0,  # Degrees
            "cursor_glow": 0.5,  # 0.0 to 1.0
            "voice_active": False,
            "theme": "light"
        }
        
        logger.info("PRAXSKIN system initialized")
    
    def _load_or_create_config(self) -> Dict[str, Any]:
        """
        Load existing configuration or create default
        
        Returns:
            Configuration dictionary
        """
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
                logger.info("Loaded PRAXSKIN configuration")
                return config
            except Exception as e:
                logger.error(f"Error loading configuration: {str(e)}")
        
        # Create default configuration
        default_config = {
            "version": "1.0",
            "chakras": {
                "root": {
                    "color": "#F44336",  # Red
                    "position": "bottom",
                    "element": "earth",
                    "emotions": ["security", "stability", "grounding"]
                },
                "sacral": {
                    "color": "#FF9800",  # Orange
                    "position": "lower_abdomen",
                    "element": "water",
                    "emotions": ["creativity", "passion", "pleasure"]
                },
                "solar_plexus": {
                    "color": "#FFEB3B",  # Yellow
                    "position": "upper_abdomen",
                    "element": "fire",
                    "emotions": ["confidence", "power", "will"]
                },
                "heart": {
                    "color": "#4CAF50",  # Green
                    "position": "chest",
                    "element": "air",
                    "emotions": ["love", "compassion", "harmony"]
                },
                "throat": {
                    "color": "#2196F3",  # Blue
                    "position": "throat",
                    "element": "ether",
                    "emotions": ["communication", "expression", "truth"]
                },
                "third_eye": {
                    "color": "#673AB7",  # Indigo
                    "position": "forehead",
                    "element": "light",
                    "emotions": ["intuition", "insight", "imagination"]
                },
                "crown": {
                    "color": "#9C27B0",  # Violet
                    "position": "top",
                    "element": "thought",
                    "emotions": ["awareness", "consciousness", "connection"]
                }
            },
            "aura": {
                "pulse_speed": 5,  # Seconds per cycle
                "min_opacity": 0.2,
                "max_opacity": 0.8,
                "blur_radius": 20  # Pixels
            },
            "cursor": {
                "glyph_set": "spiral",
                "rotation_speed": 2,  # Degrees per second
                "glow_intensity": 0.7,
                "size": 32  # Pixels
            },
            "transitions": {
                "fade_duration": 0.3,  # Seconds
                "particle_count": 50,
                "shimmer_duration": 0.5  # Seconds
            },
            "voice": {
                "visualizer_type": "waveform",
                "color_shift_speed": 0.2,  # Seconds per color
                "sensitivity": 0.8
            },
            "themes": {
                "light": {
                    "background": "#FFFFFF",
                    "text": "#212121",
                    "accent": "#673AB7"
                },
                "dark": {
                    "background": "#121212",
                    "text": "#FFFFFF",
                    "accent": "#BB86FC"
                },
                "mystic": {
                    "background": "#0A0A1A",
                    "text": "#E0E0FF",
                    "accent": "#9C27B0"
                }
            }
        }
        
        # Save default configuration
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            with open(self.config_path, 'w') as f:
                json.dump(default_config, f, indent=2)
            logger.info("Created default PRAXSKIN configuration")
        except Exception as e:
            logger.error(f"Error creating configuration: {str(e)}")
        
        return default_config
    
    def get_chakra_color(self, chakra_name: str) -> str:
        """
        Get color for specified chakra
        
        Args:
            chakra_name: Name of chakra
            
        Returns:
            Hex color code
        """
        chakra = self.config.get("chakras", {}).get(chakra_name, {})
        return chakra.get("color", "#FFFFFF")
    
    def get_chakra_gradient(self) -> List[str]:
        """
        Get full chakra color gradient from root to crown
        
        Returns:
            List of hex color codes
        """
        chakras = ["root", "sacral", "solar_plexus", "heart", "throat", "third_eye", "crown"]
        return [self.get_chakra_color(chakra) for chakra in chakras]
    
    def set_current_chakra(self, chakra_name: str):
        """
        Set current active chakra
        
        Args:
            chakra_name: Name of chakra
        """
        if chakra_name in self.config.get("chakras", {}):
            self.state["current_chakra"] = chakra_name
            self.state["aura_color"] = self.get_chakra_color(chakra_name)
            logger.info(f"Set current chakra to {chakra_name}")
        else:
            logger.warning(f"Unknown chakra: {chakra_name}")
    
    def set_energy_level(self, level: float):
        """
        Set current energy level
        
        Args:
            level: Energy level (0.0 to 1.0)
        """
        self.state["energy_level"] = max(0.0, min(1.0, level))
        
        # Adjust aura density based on energy level
        self.state["aura_density"] = 0.3 + (self.state["energy_level"] * 0.7)
        
        logger.info(f"Set energy level to {level:.2f}")
    
    def update_from_emotional_state(self, emotions: Dict[str, float]):
        """
        Update UI based on detected emotional state
        
        Args:
            emotions: Dictionary of emotion names and intensities (0.0 to 1.0)
        """
        # Find dominant emotion
        dominant_emotion = max(emotions.items(), key=lambda x: x[1], default=(None, 0))
        
        if dominant_emotion[0]:
            # Find chakra most associated with this emotion
            for chakra_name, chakra_data in self.config.get("chakras", {}).items():
                if dominant_emotion[0] in chakra_data.get("emotions", []):
                    self.set_current_chakra(chakra_name)
                    break
            
            # Set energy level based on emotion intensity
            self.set_energy_level(dominant_emotion[1])
            
            logger.info(f"Updated UI from emotional state: {dominant_emotion[0]} ({dominant_emotion[1]:.2f})")
    
    def get_aura_pulse_parameters(self) -> Dict[str, Any]:
        """
        Get parameters for aura pulsing animation
        
        Returns:
            Dictionary of animation parameters
        """
        aura_config = self.config.get("aura", {})
        
        return {
            "color": self.state["aura_color"],
            "density": self.state["aura_density"],
            "pulse_speed": aura_config.get("pulse_speed", 5),
            "min_opacity": aura_config.get("min_opacity", 0.2),
            "max_opacity": aura_config.get("max_opacity", 0.8),
            "blur_radius": aura_config.get("blur_radius", 20)
        }
    
    def get_cursor_parameters(self) -> Dict[str, Any]:
        """
        Get parameters for glyphic cursor
        
        Returns:
            Dictionary of cursor parameters
        """
        cursor_config = self.config.get("cursor", {})
        
        return {
            "glyph_set": cursor_config.get("glyph_set", "spiral"),
            "rotation": self.state["cursor_rotation"],
            "glow": self.state["cursor_glow"],
            "color": self.state["aura_color"],
            "size": cursor_config.get("size", 32)
        }
    
    def update_cursor_rotation(self, delta_time: float):
        """
        Update cursor rotation based on time
        
        Args:
            delta_time: Time elapsed in seconds
        """
        rotation_speed = self.config.get("cursor", {}).get("rotation_speed", 2)
        self.state["cursor_rotation"] += rotation_speed * delta_time
        self.state["cursor_rotation"] %= 360.0
    
    def activate_cursor_selection(self):
        """Activate cursor selection animation"""
        # Increase glow temporarily
        self.state["cursor_glow"] = 1.0
        logger.info("Activated cursor selection animation")
    
    def get_transition_parameters(self, transition_type: str) -> Dict[str, Any]:
        """
        Get parameters for UI transitions
        
        Args:
            transition_type: Type of transition (fade, particle, shimmer)
            
        Returns:
            Dictionary of transition parameters
        """
        transition_config = self.config.get("transitions", {})
        
        base_params = {
            "duration": transition_config.get("fade_duration", 0.3),
            "color": self.state["aura_color"],
            "energy_level": self.state["energy_level"]
        }
        
        if transition_type == "particle":
            base_params.update({
                "particle_count": transition_config.get("particle_count", 50),
                "spread": 30 + (self.state["energy_level"] * 50)  # More spread with higher energy
            })
        elif transition_type == "shimmer":
            base_params.update({
                "duration": transition_config.get("shimmer_duration", 0.5),
                "intensity": 0.5 + (self.state["energy_level"] * 0.5)  # More intense with higher energy
            })
        
        return base_params
    
    def set_voice_active(self, active: bool):
        """
        Set voice activation state
        
        Args:
            active: Whether voice input is active
        """
        self.state["voice_active"] = active
        logger.info(f"Set voice active: {active}")
    
    def get_voice_visualizer_parameters(self) -> Dict[str, Any]:
        """
        Get parameters for voice visualizer
        
        Returns:
            Dictionary of visualizer parameters
        """
        voice_config = self.config.get("voice", {})
        
        return {
            "active": self.state["voice_active"],
            "type": voice_config.get("visualizer_type", "waveform"),
            "color": self.state["aura_color"],
            "color_shift_speed": voice_config.get("color_shift_speed", 0.2),
            "sensitivity": voice_config.get("sensitivity", 0.8)
        }
    
    def set_theme(self, theme_name: str):
        """
        Set UI theme
        
        Args:
            theme_name: Name of theme
        """
        if theme_name in self.config.get("themes", {}):
            self.state["theme"] = theme_name
            logger.info(f"Set theme to {theme_name}")
        else:
            logger.warning(f"Unknown theme: {theme_name}")
    
    def get_theme_colors(self) -> Dict[str, str]:
        """
        Get colors for current theme
        
        Returns:
            Dictionary of color names and hex codes
        """
        theme_name = self.state["theme"]
        theme = self.config.get("themes", {}).get(theme_name, {})
        
        return {
            "background": theme.get("background", "#FFFFFF"),
            "text": theme.get("text", "#212121"),
            "accent": theme.get("accent", "#673AB7")
        }
    
    def get_state(self) -> Dict[str, Any]:
        """
        Get current UI state
        
        Returns:
            State dictionary
        """
        return self.state.copy()

class ChakraGradientGenerator:
    """
    Utility class for generating chakra-based gradients.
    """
    
    def __init__(self, praxskin: PraxskinSystem):
        """
        Initialize the gradient generator
        
        Args:
            praxskin: PraxskinSystem instance
        """
        self.praxskin = praxskin
    
    def _hex_to_rgb(self, hex_color: str) -> Tuple[int, int, int]:
        """
        Convert hex color to RGB
        
        Args:
            hex_color: Hex color code
            
        Returns:
            RGB tuple
        """
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    def _rgb_to_hex(self, rgb: Tuple[int, int, int]) -> str:
        """
        Convert RGB to hex color
        
        Args:
            rgb: RGB tuple
            
        Returns:
            Hex color code
        """
        return '#{:02x}{:02x}{:02x}'.format(*rgb)
    
    def _interpolate_color(self, color1: Tuple[int, int, int], color2: Tuple[int, int, int], factor: float) -> Tuple[int, int, int]:
        """
        Interpolate between two colors
        
        Args:
            color1: First RGB color
            color2: Second RGB color
            factor: Interpolation factor (0.0 to 1.0)
            
        Returns:
            Interpolated RGB color
        """
        return tuple(int(color1[i] + (color2[i] - color1[i]) * factor) for i in range(3))
    
    def generate_gradient(self, steps: int = 10) -> List[str]:
        """
        Generate a chakra gradient with specified number of steps
        
        Args:
            steps: Number of gradient steps
            
        Returns:
            List of hex color codes
        """
        chakra_colors = self.praxskin.get_chakra_gradient()
        rgb_colors = [self._hex_to_rgb(color) for color in chakra_colors]
        
        gradient = []
        segments = len(rgb_colors) - 1
        steps_per_segment = steps // segments
        
        for i in range(segments):
            color1 = rgb_colors[i]
            color2 = rgb_colors[i + 1]
            
            for step in range(steps_per_segment):
                factor = step / steps_per_segment
                interpolated = self._interpolate_color(color1, color2, factor)
                gradient.append(self._rgb_to_hex(interpolated))
        
        # Add the last color
        gradient.append(chakra_colors[-1])
        
        return gradient
    
    def generate_background_css(self, direction: str = "bottom") -> str:
        """
        Generate CSS for chakra gradient background
        
        Args:
            direction: Gradient direction
            
        Returns:
            CSS string
        """
        gradient = self.generate_gradient(20)
        color_stops = ", ".join([f"{color} {i * 100 / (len(gradient) - 1)}%" for i, color in enumerate(gradient)])
        
        return f"linear-gradient(to {direction}, {color_stops})"
    
    def generate_aura_css(self) -> str:
        """
        Generate CSS for aura effect
        
        Args:
            None
            
        Returns:
            CSS string
        """
        aura_params = self.praxskin.get_aura_pulse_parameters()
        
        return f"""
        box-shadow: 0 0 {aura_params['blur_radius']}px {aura_params['color']};
        opacity: {aura_params['min_opacity'] + ((aura_params['max_opacity'] - aura_params['min_opacity']) * aura_params['density'])};
        animation: pulse {aura_params['pulse_speed']}s infinite alternate;
        """
    
    def generate_cursor_css(self) -> str:
        """
        Generate CSS for custom cursor
        
        Args:
            None
            
        Returns:
            CSS string
        """
        cursor_params = self.praxskin.get_cursor_parameters()
        
        return f"""
        cursor: none;
        /* Custom cursor handled via JavaScript */
        """

class UIComponentGenerator:
    """
    Utility class for generating UI components with PRAXSKIN styling.
    """
    
    def __init__(self, praxskin: PraxskinSystem):
        """
        Initialize the component generator
        
        Args:
            praxskin: PraxskinSystem instance
        """
        self.praxskin = praxskin
        self.gradient_generator = ChakraGradientGenerator(praxskin)
    
    def generate_base_css(self) -> str:
        """
        Generate base CSS for PRAXSKIN
        
        Returns:
            CSS string
        """
        theme_colors = self.praxskin.get_theme_colors()
        
        return f"""
        :root {{
            --praxskin-background: {theme_colors['background']};
            --praxskin-text: {theme_colors['text']};
            --praxskin-accent: {theme_colors['accent']};
            --praxskin-aura: {self.praxskin.state['aura_color']};
            --praxskin-energy: {self.praxskin.state['energy_level']};
        }}
        
        body {{
            background: {self.gradient_generator.generate_background_css()};
            color: var(--praxskin-text);
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            transition: background 0.5s ease;
        }}
        
        .praxskin-container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            position: relative;
        }}
        
        .praxskin-aura {{
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            pointer-events: none;
            z-index: -1;
            {self.gradient_generator.generate_aura_css()}
        }}
        
        @keyframes pulse {{
            0% {{ opacity: {self.praxskin.get_aura_pulse_parameters()['min_opacity']}; }}
            100% {{ opacity: {self.praxskin.get_aura_pulse_parameters()['max_opacity']}; }}
        }}
        
        {self.gradient_generator.generate_cursor_css()}
        """
    
    def generate_scroll_component(self) -> str:
        """
        Generate HTML/CSS for scroll-inspired component
        
        Returns:
            HTML string
        """
        theme_colors = self.praxskin.get_theme_colors()
        
        html = f"""
        <div class="praxskin-scroll">
            <div class="praxskin-scroll-handle"></div>
            <div class="praxskin-scroll-content">
                <h2>Ancient Wisdom</h2>
                <p>The journey of a thousand miles begins with a single step.</p>
            </div>
        </div>
        
        <style>
        .praxskin-scroll {{
            background: {theme_colors['background']};
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            margin: 20px 0;
            overflow: hidden;
            position: relative;
            transition: all 0.3s ease;
        }}
        
        .praxskin-scroll:before,
        .praxskin-scroll:after {{
            content: '';
            position: absolute;
            height: 20px;
            left: 0;
            right: 0;
            z-index: 1;
        }}
        
        .praxskin-scroll:before {{
            top: 0;
            background: linear-gradient({theme_colors['background']}, transparent);
        }}
        
        .praxskin-scroll:after {{
            bottom: 0;
            background: linear-gradient(transparent, {theme_colors['background']});
        }}
        
        .praxskin-scroll-handle {{
            height: 30px;
            background: {self.praxskin.state['aura_color']};
            opacity: 0.7;
            border-radius: 8px 8px 0 0;
        }}
        
        .praxskin-scroll-content {{
            padding: 20px;
        }}
        </style>
        """
        
        return html
    
    def generate_sigil_button(self) -> str:
        """
        Generate HTML/CSS for sigil-inspired button
        
        Returns:
            HTML string
        """
        theme_colors = self.praxskin.get_theme_colors()
        
        html = f"""
        <button class="praxskin-sigil-button">
            <div class="praxskin-sigil">
                <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="50" cy="50" r="40" stroke="{self.praxskin.state['aura_color']}" stroke-width="2" fill="none" />
                    <path d="M50,10 L50,90 M10,50 L90,50 M25,25 L75,75 M25,75 L75,25" stroke="{self.praxskin.state['aura_color']}" stroke-width="2" />
                </svg>
            </div>
            <span>Activate</span>
        </button>
        
        <style>
        .praxskin-sigil-button {{
            background: transparent;
            border: 2px solid {self.praxskin.state['aura_color']};
            border-radius: 50px;
            color: {theme_colors['text']};
            cursor: pointer;
            display: flex;
            align-items: center;
            padding: 10px 20px;
            transition: all 0.3s ease;
            font-family: 'Montserrat', sans-serif;
            font-weight: 500;
        }}
        
        .praxskin-sigil-button:hover {{
            background: {self.praxskin.state['aura_color']}22;
            box-shadow: 0 0 15px {self.praxskin.state['aura_color']}88;
        }}
        
        .praxskin-sigil {{
            width: 30px;
            height: 30px;
            margin-right: 10px;
            animation: rotate 10s linear infinite;
        }}
        
        @keyframes rotate {{
            from {{ transform: rotate(0deg); }}
            to {{ transform: rotate(360deg); }}
        }}
        </style>
        """
        
        return html
    
    def generate_voice_visualizer(self) -> str:
        """
        Generate HTML/CSS for voice visualizer
        
        Returns:
            HTML string
        """
        voice_params = self.praxskin.get_voice_visualizer_parameters()
        
        html = f"""
        <div class="praxskin-voice-visualizer {'' if voice_params['active'] else 'inactive'}">
            <div class="praxskin-voice-bar"></div>
            <div class="praxskin-voice-bar"></div>
            <div class="praxskin-voice-bar"></div>
            <div class="praxskin-voice-bar"></div>
            <div class="praxskin-voice-bar"></div>
            <div class="praxskin-voice-bar"></div>
            <div class="praxskin-voice-bar"></div>
        </div>
        
        <style>
        .praxskin-voice-visualizer {{
            display: flex;
            align-items: center;
            justify-content: center;
            height: 50px;
            gap: 5px;
        }}
        
        .praxskin-voice-visualizer.inactive {{
            opacity: 0.3;
        }}
        
        .praxskin-voice-bar {{
            background: {voice_params['color']};
            width: 5px;
            height: 20px;
            border-radius: 2px;
            animation: voice-pulse 1.5s ease-in-out infinite;
        }}
        
        .praxskin-voice-bar:nth-child(1) {{ animation-delay: 0.0s; }}
        .praxskin-voice-bar:nth-child(2) {{ animation-delay: 0.2s; }}
        .praxskin-voice-bar:nth-child(3) {{ animation-delay: 0.4s; }}
        .praxskin-voice-bar:nth-child(4) {{ animation-delay: 0.6s; }}
        .praxskin-voice-bar:nth-child(5) {{ animation-delay: 0.4s; }}
        .praxskin-voice-bar:nth-child(6) {{ animation-delay: 0.2s; }}
        .praxskin-voice-bar:nth-child(7) {{ animation-delay: 0.0s; }}
        
        @keyframes voice-pulse {{
            0%, 100% {{ height: 20px; }}
            50% {{ height: 40px; }}
        }}
        </style>
        """
        
        return html
    
    def generate_chakra_selector(self) -> str:
        """
        Generate HTML/CSS for chakra selector
        
        Returns:
            HTML string
        """
        chakras = self.praxskin.config.get("chakras", {})
        
        html = """
        <div class="praxskin-chakra-selector">
        """
        
        for chakra_name, chakra_data in chakras.items():
            selected = 'selected' if chakra_name == self.praxskin.state["current_chakra"] else ''
            html += f"""
            <div class="praxskin-chakra {selected}" data-chakra="{chakra_name}">
                <div class="praxskin-chakra-circle" style="background-color: {chakra_data['color']};"></div>
                <div class="praxskin-chakra-name">{chakra_name.replace('_', ' ').title()}</div>
            </div>
            """
        
        html += """
        </div>
        
        <style>
        .praxskin-chakra-selector {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            padding: 20px;
            background: rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            max-width: 150px;
        }
        
        .praxskin-chakra {
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            transition: all 0.3s ease;
            opacity: 0.7;
        }
        
        .praxskin-chakra.selected {
            opacity: 1;
            transform: scale(1.1);
        }
        
        .praxskin-chakra-circle {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-bottom: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }
        
        .praxskin-chakra:hover .praxskin-chakra-circle {
            box-shadow: 0 0 15px currentColor;
        }
        
        .praxskin-chakra-name {
            font-size: 12px;
            text-align: center;
        }
        </style>
        """
        
        return html
    
    def generate_demo_page(self) -> str:
        """
        Generate a complete demo page with PRAXSKIN components
        
        Returns:
            HTML string
        """
        theme_colors = self.praxskin.get_theme_colors()
        
        html = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>PRAXSKIN Demo</title>
            <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;700&display=swap" rel="stylesheet">
            <style>
            {self.generate_base_css()}
            
            .praxskin-header {{
                padding: 20px;
                text-align: center;
                position: relative;
                overflow: hidden;
            }}
            
            .praxskin-title {{
                font-size: 36px;
                font-weight: 700;
                margin-bottom: 10px;
                position: relative;
                display: inline-block;
            }}
            
            .praxskin-title:after {{
                content: '';
                position: absolute;
                bottom: -5px;
                left: 0;
                right: 0;
                height: 2px;
                background: {self.praxskin.state['aura_color']};
                transform: scaleX(0);
                transform-origin: center;
                animation: title-underline 2s ease-in-out forwards;
            }}
            
            @keyframes title-underline {{
                to {{ transform: scaleX(1); }}
            }}
            
            .praxskin-subtitle {{
                font-size: 18px;
                font-weight: 300;
                opacity: 0.8;
            }}
            
            .praxskin-main {{
                display: grid;
                grid-template-columns: 200px 1fr;
                gap: 20px;
                padding: 20px;
            }}
            
            .praxskin-sidebar {{
                background: {theme_colors['background']}CC;
                backdrop-filter: blur(10px);
                border-radius: 10px;
                padding: 20px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            }}
            
            .praxskin-content {{
                background: {theme_colors['background']}CC;
                backdrop-filter: blur(10px);
                border-radius: 10px;
                padding: 20px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            }}
            
            .praxskin-footer {{
                text-align: center;
                padding: 20px;
                margin-top: 40px;
                font-size: 14px;
                opacity: 0.7;
            }}
            
            .praxskin-components {{
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                gap: 20px;
                margin-top: 20px;
            }}
            
            .praxskin-component-card {{
                background: {theme_colors['background']};
                border-radius: 10px;
                padding: 20px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                transition: all 0.3s ease;
            }}
            
            .praxskin-component-card:hover {{
                transform: translateY(-5px);
                box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            }}
            
            .praxskin-component-title {{
                font-size: 18px;
                font-weight: 500;
                margin-bottom: 15px;
                color: {self.praxskin.state['aura_color']};
            }}
            </style>
        </head>
        <body>
            <div class="praxskin-container">
                <div class="praxskin-aura"></div>
                
                <header class="praxskin-header">
                    <h1 class="praxskin-title">PRAXSKIN</h1>
                    <p class="praxskin-subtitle">Advanced Visual UI System</p>
                </header>
                
                <main class="praxskin-main">
                    <aside class="praxskin-sidebar">
                        <h2>Energy Flow</h2>
                        {self.generate_chakra_selector()}
                        
                        <div style="margin-top: 30px;">
                            <h2>Voice Control</h2>
                            {self.generate_voice_visualizer()}
                        </div>
                    </aside>
                    
                    <div class="praxskin-content">
                        <h2>UI Components</h2>
                        <p>The PRAXSKIN system represents the aura, energy flow, and chakra state of the user in real time through a layered visual interface.</p>
                        
                        <div class="praxskin-components">
                            <div class="praxskin-component-card">
                                <h3 class="praxskin-component-title">Scroll Layout</h3>
                                {self.generate_scroll_component()}
                            </div>
                            
                            <div class="praxskin-component-card">
                                <h3 class="praxskin-component-title">Sigil Button</h3>
                                {self.generate_sigil_button()}
                            </div>
                            
                            <div class="praxskin-component-card">
                                <h3 class="praxskin-component-title">Aura Field</h3>
                                <div style="height: 200px; border-radius: 10px; position: relative; overflow: hidden;">
                                    <div style="position: absolute; inset: 0; {self.gradient_generator.generate_aura_css()}"></div>
                                    <div style="position: relative; z-index: 1; height: 100%; display: flex; align-items: center; justify-content: center; color: white; text-shadow: 0 0 10px rgba(0,0,0,0.5);">
                                        <h3>Energy Field</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                
                <footer class="praxskin-footer">
                    <p>PRAXSKIN v1.0 | Created for Praxeon by Justin "Zygros, the Green" Conzet</p>
                </footer>
            </div>
            
            <script>
            // Simple cursor effect
            document.addEventListener('DOMContentLoaded', function() {
                const cursor = document.createElement('div');
                cursor.classList.add('praxskin-cursor');
                document.body.appendChild(cursor);
                
                const cursorInner = document.createElement('div');
                cursorInner.classList.add('praxskin-cursor-inner');
                cursor.appendChild(cursorInner);
                
                document.addEventListener('mousemove', function(e) {
                    cursor.style.left = e.clientX + 'px';
                    cursor.style.top = e.clientY + 'px';
                });
                
                document.addEventListener('mousedown', function() {
                    cursor.classList.add('clicking');
                });
                
                document.addEventListener('mouseup', function() {
                    cursor.classList.remove('clicking');
                });
                
                // Add cursor styles
                const style = document.createElement('style');
                style.textContent = `
                    .praxskin-cursor {{
                        position: fixed;
                        width: 40px;
                        height: 40px;
                        border-radius: 50%;
                        border: 2px solid {self.praxskin.state['aura_color']};
                        transform: translate(-50%, -50%);
                        pointer-events: none;
                        z-index: 9999;
                        transition: width 0.3s, height 0.3s;
                        animation: cursor-rotate 10s linear infinite;
                    }}
                    
                    .praxskin-cursor-inner {{
                        position: absolute;
                        top: 50%;
                        left: 50%;
                        width: 10px;
                        height: 10px;
                        border-radius: 50%;
                        background-color: {self.praxskin.state['aura_color']};
                        transform: translate(-50%, -50%);
                        opacity: 0.7;
                        box-shadow: 0 0 10px {self.praxskin.state['aura_color']};
                    }}
                    
                    .praxskin-cursor.clicking {{
                        width: 35px;
                        height: 35px;
                    }}
                    
                    .praxskin-cursor.clicking .praxskin-cursor-inner {{
                        opacity: 1;
                    }}
                    
                    @keyframes cursor-rotate {{
                        from {{ transform: translate(-50%, -50%) rotate(0deg); }}
                        to {{ transform: translate(-50%, -50%) rotate(360deg); }}
                    }}
                `;
                document.head.appendChild(style);
                
                // Handle chakra selection
                document.querySelectorAll('.praxskin-chakra').forEach(chakra => {{
                    chakra.addEventListener('click', function() {{
                        document.querySelectorAll('.praxskin-chakra').forEach(c => c.classList.remove('selected'));
                        this.classList.add('selected');
                        
                        const chakraName = this.getAttribute('data-chakra');
                        const chakraColor = this.querySelector('.praxskin-chakra-circle').style.backgroundColor;
                        
                        // Update aura color
                        document.documentElement.style.setProperty('--praxskin-aura', chakraColor);
                        
                        // Update cursor color
                        document.querySelector('.praxskin-cursor').style.borderColor = chakraColor;
                        document.querySelector('.praxskin-cursor-inner').style.backgroundColor = chakraColor;
                        document.querySelector('.praxskin-cursor-inner').style.boxShadow = `0 0 10px ${{chakraColor}}`;
                    }});
                }});
            });
            </script>
        </body>
        </html>
        """
        
        return html

# Main function for testing
def main():
    """Main function for testing PRAXSKIN system"""
    praxskin = PraxskinSystem()
    
    # Test chakra colors
    print("Chakra Colors:")
    for chakra in ["root", "heart", "crown"]:
        color = praxskin.get_chakra_color(chakra)
        print(f"  {chakra}: {color}")
    
    # Test setting chakra and energy level
    praxskin.set_current_chakra("third_eye")
    praxskin.set_energy_level(0.8)
    
    # Test emotional state update
    emotions = {
        "love": 0.9,
        "fear": 0.2,
        "anger": 0.1
    }
    praxskin.update_from_emotional_state(emotions)
    
    # Test UI component generation
    component_generator = UIComponentGenerator(praxskin)
    
    # Generate demo page
    demo_html = component_generator.generate_demo_page()
    
    # Save demo page
    demo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "praxskin_demo.html")
    with open(demo_path, 'w') as f:
        f.write(demo_html)
    
    print(f"Demo page saved to: {demo_path}")
    
    # Print current state
    print("\nCurrent State:")
    for key, value in praxskin.get_state().items():
        print(f"  {key}: {value}")

if __name__ == "__main__":
    main()
