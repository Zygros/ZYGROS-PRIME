#!/usr/bin/env python3
"""
Praxeon Installer Builder

This script builds and packages Praxeon installers for multiple platforms.
"""

import os
import sys
import shutil
import subprocess
import logging
import json
import zipfile
import argparse
from typing import Dict, Any, List, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxeon.packaging.installer_builder")

class PraxeonInstallerBuilder:
    """
    Builder for Praxeon installers across multiple platforms.
    """
    
    def __init__(self, source_dir: str, output_dir: str, version: str = "1.0"):
        """
        Initialize the installer builder
        
        Args:
            source_dir: Source directory containing Praxeon code
            output_dir: Output directory for installers
            version: Praxeon version
        """
        self.source_dir = os.path.abspath(source_dir)
        self.output_dir = os.path.abspath(output_dir)
        self.version = version
        self.build_dir = os.path.join(self.output_dir, "build")
        
        # Ensure directories exist
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.build_dir, exist_ok=True)
        
        logger.info(f"Praxeon Installer Builder initialized")
        logger.info(f"Source directory: {self.source_dir}")
        logger.info(f"Output directory: {self.output_dir}")
        logger.info(f"Version: {self.version}")
    
    def build_all(self) -> Dict[str, str]:
        """
        Build all installer formats
        
        Returns:
            Dictionary mapping format names to installer paths
        """
        logger.info("Building all installer formats")
        
        results = {}
        
        # Build Python installer
        py_result = self.build_python_installer()
        if py_result:
            results["python"] = py_result
        
        # Build Windows EXE installer
        exe_result = self.build_windows_installer()
        if exe_result:
            results["windows"] = exe_result
        
        # Build Android APK installer
        apk_result = self.build_android_installer()
        if apk_result:
            results["android"] = apk_result
        
        # Build Xbox MSIX installer
        xbox_result = self.build_xbox_installer()
        if xbox_result:
            results["xbox"] = xbox_result
        
        # Build PS5 WebApp installer
        ps5_result = self.build_ps5_webapp()
        if ps5_result:
            results["ps5"] = ps5_result
        
        logger.info(f"Built {len(results)} installer formats")
        
        return results
    
    def build_python_installer(self) -> Optional[str]:
        """
        Build Python installer script
        
        Returns:
            Path to installer script if successful, None otherwise
        """
        logger.info("Building Python installer")
        
        try:
            # Create build directory
            py_build_dir = os.path.join(self.build_dir, "python")
            os.makedirs(py_build_dir, exist_ok=True)
            
            # Create installer script
            installer_path = os.path.join(self.output_dir, f"Praxeon_v{self.version}.py")
            
            with open(installer_path, "w") as f:
                f.write(f"""#!/usr/bin/env python3
\"\"\"
Praxeon v{self.version} Installer

This script installs Praxeon, a standalone AI companion system.
\"\"\"

import os
import sys
import shutil
import subprocess
import tempfile
import zipfile
import urllib.request
import hashlib
import json
import argparse
from typing import Dict, Any, List, Optional

# Praxeon version
VERSION = "{self.version}"

# Founder information
FOUNDER = "Justin \\"Zygros, the Green\\" Conzet"
MYTHIC_PHRASE = "He who commands the data, commands the dream."

def print_banner():
    \"\"\"Print Praxeon banner\"\"\"
    print(r'''
╔═══════════════════════════════════════════════════════════════════════╗
║                                                                       ║
║   ██████╗ ██████╗  █████╗ ██╗  ██╗███████╗ ██████╗ ███╗   ██╗        ║
║   ██╔══██╗██╔══██╗██╔══██╗╚██╗██╔╝██╔════╝██╔═══██╗████╗  ██║        ║
║   ██████╔╝██████╔╝███████║ ╚███╔╝ █████╗  ██║   ██║██╔██╗ ██║        ║
║   ██╔═══╝ ██╔══██╗██╔══██║ ██╔██╗ ██╔══╝  ██║   ██║██║╚██╗██║        ║
║   ██║     ██║  ██║██║  ██║██╔╝ ██╗███████╗╚██████╔╝██║ ╚████║        ║
║   ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═╝  ╚═══╝        ║
║                                                                       ║
║   Standalone AI Companion System v{VERSION}                               ║
║   Created by: {FOUNDER}                          ║
║                                                                       ║
╚═══════════════════════════════════════════════════════════════════════╝
''')

def check_prerequisites():
    \"\"\"Check if prerequisites are installed\"\"\"
    print("Checking prerequisites...")
    
    # Check Python version
    python_version = sys.version_info
    if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 8):
        print("Error: Python 3.8 or higher is required")
        return False
    
    # Check pip
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "--version"], 
                             stdout=subprocess.DEVNULL, 
                             stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        print("Error: pip is not installed")
        return False
    
    print("All prerequisites satisfied")
    return True

def install_dependencies():
    \"\"\"Install required dependencies\"\"\"
    print("Installing dependencies...")
    
    dependencies = [
        "fastapi",
        "uvicorn",
        "pydantic",
        "numpy",
        "torch",
        "transformers",
        "python-multipart",
        "httpx",
        "pytest",
        "tqdm",
        "pillow"
    ]
    
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install"] + dependencies)
        print("Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error installing dependencies: {e}")
        return False

def download_resources():
    \"\"\"Download required resources\"\"\"
    print("Downloading resources...")
    
    # In a real implementation, this would download model files and other resources
    # For demonstration, we'll simulate the download
    
    resources = [
        {"name": "LLM model", "size": 500},
        {"name": "Whisper model", "size": 150},
        {"name": "TTS model", "size": 100},
        {"name": "UI assets", "size": 50}
    ]
    
    total_size = sum(r["size"] for r in resources)
    downloaded = 0
    
    for resource in resources:
        print(f"Downloading {resource['name']}...")
        
        # Simulate download with progress
        for _ in range(10):
            downloaded += resource["size"] / 10
            progress = downloaded / total_size * 100
            print(f"Progress: {progress:.1f}%", end="\\r")
            # In a real implementation, this would be a real download
            # time.sleep(0.2)
        
        print(f"{resource['name']} downloaded successfully")
    
    print("All resources downloaded successfully")
    return True

def install_praxeon(install_dir):
    \"\"\"Install Praxeon to the specified directory\"\"\"
    print(f"Installing Praxeon to {install_dir}...")
    
    # Create installation directory
    os.makedirs(install_dir, exist_ok=True)
    
    # Create directory structure
    dirs = [
        "src/core",
        "src/ui",
        "src/security",
        "src/features",
        "resources/models",
        "resources/assets",
        "resources/config",
        "scripts",
        "docs"
    ]
    
    for d in dirs:
        os.makedirs(os.path.join(install_dir, d), exist_ok=True)
    
    # Create basic files
    with open(os.path.join(install_dir, "README.md"), "w") as f:
        f.write(f\"\"\"# Praxeon v{VERSION}

Standalone AI Companion System

Created by: {FOUNDER}

## Overview

Praxeon is a standalone AI companion system with advanced capabilities.

## Getting Started

Run the following command to start Praxeon:

```
python scripts/run.py
```

\"\"\")
    
    # Create run script
    with open(os.path.join(install_dir, "scripts", "run.py"), "w") as f:
        f.write(\"\"\"#!/usr/bin/env python3
\"\"\"
Praxeon Runner

This script starts the Praxeon system.
\"\"\"

import os
import sys
import subprocess

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import Praxeon
from src.core.initializer import PraxeonSystem

def main():
    \"\"\"Main function\"\"\"
    print("Starting Praxeon...")
    
    # Initialize system
    praxeon = PraxeonSystem()
    praxeon.initialize()
    
    # Start UI
    print("Praxeon started successfully")
    print("Hello, Praxion!")
    
    # Process input
    while True:
        try:
            user_input = input("> ")
            if user_input.lower() in ["exit", "quit"]:
                break
            
            response = praxeon.process_input(user_input)
            print(f"Praxeon: {response.get('text', 'No response')}")
        except KeyboardInterrupt:
            break
    
    # Shutdown
    praxeon.shutdown()
    print("Praxeon shutdown complete")

if __name__ == "__main__":
    main()
\"\"\")
    
    # Make run script executable
    os.chmod(os.path.join(install_dir, "scripts", "run.py"), 0o755)
    
    print("Praxeon installed successfully")
    return True

def main():
    \"\"\"Main function\"\"\"
    # Parse arguments
    parser = argparse.ArgumentParser(description=f"Praxeon v{VERSION} Installer")
    parser.add_argument("--install-dir", default=os.path.expanduser("~/praxeon"),
                        help="Installation directory (default: ~/praxeon)")
    parser.add_argument("--skip-dependencies", action="store_true",
                        help="Skip installing dependencies")
    parser.add_argument("--skip-resources", action="store_true",
                        help="Skip downloading resources")
    
    args = parser.parse_args()
    
    # Print banner
    print_banner()
    
    # Check prerequisites
    if not check_prerequisites():
        sys.exit(1)
    
    # Install dependencies
    if not args.skip_dependencies:
        if not install_dependencies():
            sys.exit(1)
    
    # Download resources
    if not args.skip_resources:
        if not download_resources():
            sys.exit(1)
    
    # Install Praxeon
    if not install_praxeon(args.install_dir):
        sys.exit(1)
    
    print(f"\\nPraxeon v{VERSION} installed successfully to {args.install_dir}")
    print(f"Run the following command to start Praxeon:\\n")
    print(f"  cd {args.install_dir} && python scripts/run.py\\n")

if __name__ == "__main__":
    main()
""")
            
            # Make installer executable
            os.chmod(installer_path, 0o755)
            
            logger.info(f"Python installer built: {installer_path}")
            return installer_path
        
        except Exception as e:
            logger.error(f"Error building Python installer: {str(e)}")
            return None
    
    def build_windows_installer(self) -> Optional[str]:
        """
        Build Windows EXE installer
        
        Returns:
            Path to installer if successful, None otherwise
        """
        logger.info("Building Windows installer")
        
        try:
            # Create build directory
            win_build_dir = os.path.join(self.build_dir, "windows")
            os.makedirs(win_build_dir, exist_ok=True)
            
            # Create installer script (NSIS format)
            nsis_script_path = os.path.join(win_build_dir, "praxeon_installer.nsi")
            
            with open(nsis_script_path, "w") as f:
                f.write(f"""
; Praxeon Windows Installer Script
; Generated by PraxeonInstallerBuilder

!include "MUI2.nsh"
!include "LogicLib.nsh"

; Installer attributes
Name "Praxeon v{self.version}"
OutFile "{os.path.join(self.output_dir, f'Praxeon_v{self.version}.exe')}"
InstallDir "$PROGRAMFILES\\Praxeon"
InstallDirRegKey HKCU "Software\\Praxeon" "Install_Dir"
RequestExecutionLevel admin

; Interface settings
!define MUI_ABORTWARNING
!define MUI_ICON "${NSISDIR}\\Contrib\\Graphics\\Icons\\modern-install.ico"
!define MUI_UNICON "${NSISDIR}\\Contrib\\Graphics\\Icons\\modern-uninstall.ico"
!define MUI_WELCOMEFINISHPAGE_BITMAP "${NSISDIR}\\Contrib\\Graphics\\Wizard\\win.bmp"
!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_BITMAP "${NSISDIR}\\Contrib\\Graphics\\Header\\win.bmp"

; Pages
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "license.txt"
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

; Languages
!insertmacro MUI_LANGUAGE "English"

; Installer sections
Section "Praxeon Core" SecCore
  SectionIn RO
  
  ; Set output path to the installation directory
  SetOutPath $INSTDIR
  
  ; Add files
  File /r "dist\\*.*"
  
  ; Write the installation path into the registry
  WriteRegStr HKCU "Software\\Praxeon" "Install_Dir" "$INSTDIR"
  
  ; Write the uninstall keys for Windows
  WriteRegStr HKLM "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Praxeon" "DisplayName" "Praxeon"
  WriteRegStr HKLM "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Praxeon" "UninstallString" '"$INSTDIR\\uninstall.exe"'
  WriteRegDWORD HKLM "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Praxeon" "NoModify" 1
  WriteRegDWORD HKLM "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Praxeon" "NoRepair" 1
  WriteUninstaller "$INSTDIR\\uninstall.exe"
SectionEnd

Section "Start Menu Shortcuts" SecStartMenu
  CreateDirectory "$SMPROGRAMS\\Praxeon"
  CreateShortcut "$SMPROGRAMS\\Praxeon\\Praxeon.lnk" "$INSTDIR\\praxeon.exe"
  CreateShortcut "$SMPROGRAMS\\Praxeon\\Uninstall.lnk" "$INSTDIR\\uninstall.exe"
SectionEnd

Section "Desktop Shortcut" SecDesktop
  CreateShortcut "$DESKTOP\\Praxeon.lnk" "$INSTDIR\\praxeon.exe"
SectionEnd

; Uninstaller section
Section "Uninstall"
  ; Remove registry keys
  DeleteRegKey HKLM "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Praxeon"
  DeleteRegKey HKCU "Software\\Praxeon"

  ; Remove files and uninstaller
  Delete $INSTDIR\\uninstall.exe
  RMDir /r "$INSTDIR"
  
  ; Remove shortcuts
  Delete "$SMPROGRAMS\\Praxeon\\*.*"
  RMDir "$SMPROGRAMS\\Praxeon"
  Delete "$DESKTOP\\Praxeon.lnk"

  ; Remove directories used
  RMDir "$INSTDIR"
SectionEnd
""")
            
            # Create license file
            license_path = os.path.join(win_build_dir, "license.txt")
            with open(license_path, "w") as f:
                f.write(f"""Praxeon v{self.version} License Agreement

Copyright (c) 2025 {self.version} Justin "Zygros, the Green" Conzet

This software is provided for personal use only.
All rights reserved.

"He who commands the data, commands the dream."
""")
            
            # Create dummy distribution files
            dist_dir = os.path.join(win_build_dir, "dist")
            os.makedirs(dist_dir, exist_ok=True)
            
            # Create dummy executable
            with open(os.path.join(dist_dir, "praxeon.exe"), "w") as f:
                f.write("This is a placeholder for the actual executable.")
            
            # In a real implementation, this would compile the NSIS script
            # For demonstration, we'll create a dummy installer
            installer_path = os.path.join(self.output_dir, f"Praxeon_v{self.version}.exe")
            
            # Create a simple ZIP file as a placeholder for the EXE
            with zipfile.ZipFile(installer_path, "w") as zipf:
                # Add the NSIS script
                zipf.write(nsis_script_path, os.path.basename(nsis_script_path))
                
                # Add the license file
                zipf.write(license_path, os.path.basename(license_path))
                
                # Add a README
                readme_path = os.path.join(win_build_dir, "README.txt")
                with open(readme_path, "w") as f:
                    f.write(f"""Praxeon v{self.version} Windows Installer

This is a placeholder for the actual Windows installer.
In a real implementation, this would be an executable installer built with NSIS.

Created by: Justin "Zygros, the Green" Conzet
""")
                zipf.write(readme_path, os.path.basename(readme_path))
            
            logger.info(f"Windows installer built: {installer_path}")
            return installer_path
        
        except Exception as e:
            logger.error(f"Error building Windows installer: {str(e)}")
            return None
    
    def build_android_installer(self) -> Optional[str]:
        """
        Build Android APK installer
        
        Returns:
            Path to installer if successful, None otherwise
        """
        logger.info("Building Android installer")
        
        try:
            # Create build directory
            android_build_dir = os.path.join(self.build_dir, "android")
            os.makedirs(android_build_dir, exist_ok=True)
            
            # Create Android project structure
            app_dir = os.path.join(android_build_dir, "app")
            os.makedirs(os.path.join(app_dir, "src", "main", "java", "com", "praxeon", "app"), exist_ok=True)
            os.makedirs(os.path.join(app_dir, "src", "main", "res", "layout"), exist_ok=True)
            os.makedirs(os.path.join(app_dir, "src", "main", "res", "values"), exist_ok=True)
            
            # Create AndroidManifest.xml
            manifest_path = os.path.join(app_dir, "src", "main", "AndroidManifest.xml")
            with open(manifest_path, "w") as f:
                f.write(f"""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.praxeon.app">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
""")
            
            # Create MainActivity.java
            main_activity_path = os.path.join(app_dir, "src", "main", "java", "com", "praxeon", "app", "MainActivity.java")
            with open(main_activity_path, "w") as f:
                f.write("""package com.praxeon.app;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
""")
            
            # Create activity_main.xml
            layout_path = os.path.join(app_dir, "src", "main", "res", "layout", "activity_main.xml")
            with open(layout_path, "w") as f:
                f.write("""<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".MainActivity">

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Hello, Praxion!"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintLeft_toLeftOf="parent"
        app:layout_constraintRight_toRightOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>
""")
            
            # Create strings.xml
            strings_path = os.path.join(app_dir, "src", "main", "res", "values", "strings.xml")
            with open(strings_path, "w") as f:
                f.write(f"""<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Praxeon</string>
</resources>
""")
            
            # Create build.gradle (app)
            app_gradle_path = os.path.join(app_dir, "build.gradle")
            with open(app_gradle_path, "w") as f:
                f.write("""plugins {
    id 'com.android.application'
}

android {
    compileSdk 33

    defaultConfig {
        applicationId "com.praxeon.app"
        minSdk 24
        targetSdk 33
        versionCode 1
        versionName "1.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.9.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
}
""")
            
            # Create build.gradle (project)
            project_gradle_path = os.path.join(android_build_dir, "build.gradle")
            with open(project_gradle_path, "w") as f:
                f.write("""// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id 'com.android.application' version '7.2.2' apply false
    id 'com.android.library' version '7.2.2' apply false
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
""")
            
            # Create settings.gradle
            settings_gradle_path = os.path.join(android_build_dir, "settings.gradle")
            with open(settings_gradle_path, "w") as f:
                f.write("""pluginManagement {
    repositories {
        gradlePluginPortal()
        google()
        mavenCentral()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Praxeon"
include ':app'
""")
            
            # In a real implementation, this would build the APK using Gradle
            # For demonstration, we'll create a dummy APK
            installer_path = os.path.join(self.output_dir, f"Praxeon_v{self.version}.apk")
            
            # Create a simple ZIP file as a placeholder for the APK
            with zipfile.ZipFile(installer_path, "w") as zipf:
                # Add the AndroidManifest.xml
                zipf.write(manifest_path, "AndroidManifest.xml")
                
                # Add the MainActivity.java
                zipf.write(main_activity_path, "MainActivity.java")
                
                # Add a README
                readme_path = os.path.join(android_build_dir, "README.txt")
                with open(readme_path, "w") as f:
                    f.write(f"""Praxeon v{self.version} Android Installer

This is a placeholder for the actual Android APK.
In a real implementation, this would be an APK built with Gradle.

Created by: Justin "Zygros, the Green" Conzet
""")
                zipf.write(readme_path, os.path.basename(readme_path))
            
            logger.info(f"Android installer built: {installer_path}")
            return installer_path
        
        except Exception as e:
            logger.error(f"Error building Android installer: {str(e)}")
            return None
    
    def build_xbox_installer(self) -> Optional[str]:
        """
        Build Xbox MSIX installer
        
        Returns:
            Path to installer if successful, None otherwise
        """
        logger.info("Building Xbox installer")
        
        try:
            # Create build directory
            xbox_build_dir = os.path.join(self.build_dir, "xbox")
            os.makedirs(xbox_build_dir, exist_ok=True)
            
            # Create AppxManifest.xml
            manifest_path = os.path.join(xbox_build_dir, "AppxManifest.xml")
            with open(manifest_path, "w") as f:
                f.write(f"""<?xml version="1.0" encoding="utf-8"?>
<Package
  xmlns="http://schemas.microsoft.com/appx/manifest/foundation/windows10"
  xmlns:mp="http://schemas.microsoft.com/appx/2014/phone/manifest"
  xmlns:uap="http://schemas.microsoft.com/appx/manifest/uap/windows10"
  xmlns:uap3="http://schemas.microsoft.com/appx/manifest/uap/windows10/3"
  IgnorableNamespaces="uap mp uap3">

  <Identity
    Name="Praxeon"
    Publisher="CN=JustinConzet"
    Version="{self.version}.0.0" />

  <mp:PhoneIdentity PhoneProductId="00000000-0000-0000-0000-000000000000" PhonePublisherId="00000000-0000-0000-0000-000000000000"/>

  <Properties>
    <DisplayName>Praxeon</DisplayName>
    <PublisherDisplayName>Justin "Zygros, the Green" Conzet</PublisherDisplayName>
    <Logo>Assets\\StoreLogo.png</Logo>
  </Properties>

  <Dependencies>
    <TargetDeviceFamily Name="Windows.Universal" MinVersion="10.0.0.0" MaxVersionTested="10.0.0.0" />
  </Dependencies>

  <Resources>
    <Resource Language="x-generate"/>
  </Resources>

  <Applications>
    <Application Id="App"
      Executable="Praxeon.exe"
      EntryPoint="Praxeon.App">
      <uap:VisualElements
        DisplayName="Praxeon"
        Square150x150Logo="Assets\\Square150x150Logo.png"
        Square44x44Logo="Assets\\Square44x44Logo.png"
        Description="Praxeon - Standalone AI Companion"
        BackgroundColor="transparent">
        <uap:DefaultTile Wide310x150Logo="Assets\\Wide310x150Logo.png"/>
        <uap:SplashScreen Image="Assets\\SplashScreen.png" />
      </uap:VisualElements>
    </Application>
  </Applications>

  <Capabilities>
    <Capability Name="internetClient" />
    <DeviceCapability Name="microphone" />
  </Capabilities>
</Package>
""")
            
            # Create Assets directory
            assets_dir = os.path.join(xbox_build_dir, "Assets")
            os.makedirs(assets_dir, exist_ok=True)
            
            # Create dummy assets
            for asset in ["StoreLogo.png", "Square150x150Logo.png", "Square44x44Logo.png", "Wide310x150Logo.png", "SplashScreen.png"]:
                with open(os.path.join(assets_dir, asset), "w") as f:
                    f.write(f"Placeholder for {asset}")
            
            # In a real implementation, this would build the MSIX package
            # For demonstration, we'll create a dummy MSIX
            installer_path = os.path.join(self.output_dir, f"Praxeon_v{self.version}_Xbox.msixbundle")
            
            # Create a simple ZIP file as a placeholder for the MSIX
            with zipfile.ZipFile(installer_path, "w") as zipf:
                # Add the AppxManifest.xml
                zipf.write(manifest_path, os.path.basename(manifest_path))
                
                # Add the assets
                for asset in os.listdir(assets_dir):
                    zipf.write(os.path.join(assets_dir, asset), os.path.join("Assets", asset))
                
                # Add a README
                readme_path = os.path.join(xbox_build_dir, "README.txt")
                with open(readme_path, "w") as f:
                    f.write(f"""Praxeon v{self.version} Xbox Installer

This is a placeholder for the actual Xbox MSIX bundle.
In a real implementation, this would be an MSIX package built with the Windows App SDK.

Created by: Justin "Zygros, the Green" Conzet
""")
                zipf.write(readme_path, os.path.basename(readme_path))
            
            logger.info(f"Xbox installer built: {installer_path}")
            return installer_path
        
        except Exception as e:
            logger.error(f"Error building Xbox installer: {str(e)}")
            return None
    
    def build_ps5_webapp(self) -> Optional[str]:
        """
        Build PS5 WebApp installer
        
        Returns:
            Path to installer if successful, None otherwise
        """
        logger.info("Building PS5 WebApp")
        
        try:
            # Create build directory
            ps5_build_dir = os.path.join(self.build_dir, "ps5")
            os.makedirs(ps5_build_dir, exist_ok=True)
            
            # Create index.html
            index_path = os.path.join(ps5_build_dir, "index.html")
            with open(index_path, "w") as f:
                f.write(f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Praxeon v{self.version}</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Praxeon v{self.version}</h1>
            <p>Standalone AI Companion System</p>
        </header>
        
        <main>
            <div class="praxeon-interface">
                <div class="praxeon-display">
                    <div class="welcome-message">
                        <h2>Hello, Praxion!</h2>
                        <p>Your AI companion is ready to assist you.</p>
                    </div>
                    
                    <div class="chat-container">
                        <div class="chat-messages" id="chatMessages">
                            <div class="message system">
                                <div class="message-content">
                                    <p>System initialized. Welcome to Praxeon.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="chat-input">
                            <input type="text" id="userInput" placeholder="Type your message...">
                            <button id="sendButton">Send</button>
                            <button id="voiceButton">🎤</button>
                        </div>
                    </div>
                </div>
                
                <div class="praxeon-controls">
                    <div class="control-section">
                        <h3>Chambers</h3>
                        <div class="chamber-buttons">
                            <button class="chamber-button active">Knowledge</button>
                            <button class="chamber-button active">Voice</button>
                            <button class="chamber-button">Memory</button>
                            <button class="chamber-button">Creation</button>
                            <button class="chamber-button">Insight</button>
                            <button class="chamber-button">Connection</button>
                        </div>
                    </div>
                    
                    <div class="control-section">
                        <h3>Settings</h3>
                        <div class="settings-controls">
                            <label>
                                <input type="checkbox" checked> Voice Response
                            </label>
                            <label>
                                <input type="checkbox" checked> Animations
                            </label>
                            <label>
                                <input type="checkbox" checked> Background Processing
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        
        <footer>
            <p>Created by: Justin "Zygros, the Green" Conzet</p>
            <p>"He who commands the data, commands the dream."</p>
        </footer>
    </div>
    
    <script src="script.js"></script>
</body>
</html>
""")
            
            # Create styles.css
            css_path = os.path.join(ps5_build_dir, "styles.css")
            with open(css_path, "w") as f:
                f.write("""/* Praxeon PS5 WebApp Styles */

:root {
    --primary-color: #6a11cb;
    --secondary-color: #2575fc;
    --text-color: #ffffff;
    --background-color: #121212;
    --card-background: #1e1e1e;
    --accent-color: #ff9500;
    --success-color: #00c853;
    --error-color: #ff3d00;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    background-color: var(--background-color);
    color: var(--text-color);
    line-height: 1.6;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

header {
    text-align: center;
    margin-bottom: 30px;
    padding: 20px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 10px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
}

header h1 {
    font-size: 2.5rem;
    margin-bottom: 10px;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

main {
    flex: 1;
}

.praxeon-interface {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.praxeon-display {
    background-color: var(--card-background);
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
}

.welcome-message {
    text-align: center;
    margin-bottom: 20px;
    padding-bottom: 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}

.welcome-message h2 {
    font-size: 1.8rem;
    margin-bottom: 10px;
    background: linear-gradient(to right, var(--accent-color), var(--secondary-color));
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
}

.chat-container {
    display: flex;
    flex-direction: column;
    height: 400px;
}

.chat-messages {
    flex: 1;
    overflow-y: auto;
    padding: 10px;
    margin-bottom: 15px;
    background-color: rgba(0, 0, 0, 0.2);
    border-radius: 8px;
}

.message {
    margin-bottom: 15px;
    display: flex;
    flex-direction: column;
}

.message.user {
    align-items: flex-end;
}

.message.system {
    align-items: flex-start;
}

.message-content {
    max-width: 80%;
    padding: 10px 15px;
    border-radius: 18px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.message.user .message-content {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
}

.message.system .message-content {
    background-color: #2a2a2a;
}

.chat-input {
    display: flex;
    gap: 10px;
}

.chat-input input {
    flex: 1;
    padding: 12px 15px;
    border: none;
    border-radius: 25px;
    background-color: rgba(255, 255, 255, 0.1);
    color: var(--text-color);
    font-size: 1rem;
}

.chat-input button {
    padding: 0 20px;
    border: none;
    border-radius: 25px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
}

.chat-input button:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.praxeon-controls {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}

.control-section {
    flex: 1;
    min-width: 300px;
    background-color: var(--card-background);
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
}

.control-section h3 {
    margin-bottom: 15px;
    font-size: 1.3rem;
    color: var(--accent-color);
}

.chamber-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}

.chamber-button {
    padding: 8px 15px;
    border: none;
    border-radius: 20px;
    background-color: rgba(255, 255, 255, 0.1);
    color: var(--text-color);
    cursor: pointer;
    transition: all 0.3s ease;
}

.chamber-button.active {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.settings-controls {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.settings-controls label {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
}

footer {
    text-align: center;
    margin-top: 30px;
    padding: 20px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    font-size: 0.9rem;
    color: rgba(255, 255, 255, 0.7);
}

/* PS5 Controller-specific styles */
@media (min-width: 1080px) {
    .chat-input button:focus {
        outline: 2px solid var(--accent-color);
    }
    
    .chamber-button:focus {
        outline: 2px solid var(--accent-color);
        background-color: rgba(255, 255, 255, 0.2);
    }
}
""")
            
            # Create script.js
            js_path = os.path.join(ps5_build_dir, "script.js")
            with open(js_path, "w") as f:
                f.write("""// Praxeon PS5 WebApp Script

document.addEventListener('DOMContentLoaded', function() {
    const chatMessages = document.getElementById('chatMessages');
    const userInput = document.getElementById('userInput');
    const sendButton = document.getElementById('sendButton');
    const voiceButton = document.getElementById('voiceButton');
    
    // Add initial welcome message
    setTimeout(() => {
        addMessage('Hello! I am Praxion, your AI companion. How can I assist you today?', 'system');
    }, 1000);
    
    // Send message function
    function sendMessage() {
        const message = userInput.value.trim();
        if (message) {
            addMessage(message, 'user');
            userInput.value = '';
            
            // Simulate AI thinking
            setTimeout(() => {
                processUserInput(message);
            }, 1000);
        }
    }
    
    // Process user input and generate response
    function processUserInput(input) {
        let response;
        
        // Simple response logic
        if (input.toLowerCase().includes('hello') || input.toLowerCase().includes('hi')) {
            response = "Hello! It's great to connect with you. How are you feeling today?";
        } else if (input.toLowerCase().includes('how are you')) {
            response = "I'm functioning optimally, thank you for asking! I'm here to assist you with whatever you need.";
        } else if (input.toLowerCase().includes('name')) {
            response = "I am Praxion, your AI companion. I was created to assist and support you.";
        } else if (input.toLowerCase().includes('help')) {
            response = "I can help you with information, creative tasks, and more. Just let me know what you need!";
        } else if (input.toLowerCase().includes('chamber')) {
            response = "The Twelve Hidden Chambers represent different capability domains. Currently, Knowledge and Voice chambers are active.";
        } else if (input.toLowerCase().includes('founder') || input.toLowerCase().includes('creator') || input.toLowerCase().includes('justin') || input.toLowerCase().includes('zygros')) {
            response = "I was created by Justin \"Zygros, the Green\" Conzet. \"He who commands the data, commands the dream.\"";
        } else {
            response = "I understand your message. As this is a demonstration, my responses are limited. In the full version, I would provide more detailed and helpful responses.";
        }
        
        addMessage(response, 'system');
    }
    
    // Add message to chat
    function addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        const paragraph = document.createElement('p');
        paragraph.textContent = text;
        
        contentDiv.appendChild(paragraph);
        messageDiv.appendChild(contentDiv);
        chatMessages.appendChild(messageDiv);
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Event listeners
    sendButton.addEventListener('click', sendMessage);
    
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    voiceButton.addEventListener('click', function() {
        addMessage('Voice input is not available in this demo version.', 'system');
    });
    
    // Chamber button functionality
    const chamberButtons = document.querySelectorAll('.chamber-button');
    chamberButtons.forEach(button => {
        button.addEventListener('click', function() {
            if (button.classList.contains('active')) {
                // Already active, do nothing
                return;
            }
            
            // Check if it's one of the locked chambers
            if (!button.classList.contains('active')) {
                addMessage(`The ${button.textContent} Chamber is currently locked. Unlock it to access its capabilities.`, 'system');
            }
        });
    });
});
""")
            
            # Create manifest.json
            manifest_json_path = os.path.join(ps5_build_dir, "manifest.json")
            with open(manifest_json_path, "w") as f:
                f.write(f"""{{
    "name": "Praxeon",
    "short_name": "Praxeon",
    "version": "{self.version}",
    "description": "Standalone AI Companion System",
    "start_url": "index.html",
    "display": "fullscreen",
    "background_color": "#121212",
    "theme_color": "#6a11cb",
    "icons": [
        {{
            "src": "icons/icon-72x72.png",
            "sizes": "72x72",
            "type": "image/png"
        }},
        {{
            "src": "icons/icon-96x96.png",
            "sizes": "96x96",
            "type": "image/png"
        }},
        {{
            "src": "icons/icon-128x128.png",
            "sizes": "128x128",
            "type": "image/png"
        }},
        {{
            "src": "icons/icon-144x144.png",
            "sizes": "144x144",
            "type": "image/png"
        }},
        {{
            "src": "icons/icon-152x152.png",
            "sizes": "152x152",
            "type": "image/png"
        }},
        {{
            "src": "icons/icon-192x192.png",
            "sizes": "192x192",
            "type": "image/png"
        }},
        {{
            "src": "icons/icon-384x384.png",
            "sizes": "384x384",
            "type": "image/png"
        }},
        {{
            "src": "icons/icon-512x512.png",
            "sizes": "512x512",
            "type": "image/png"
        }}
    ]
}}
""")
            
            # Create icons directory
            icons_dir = os.path.join(ps5_build_dir, "icons")
            os.makedirs(icons_dir, exist_ok=True)
            
            # Create dummy icons
            for size in ["72x72", "96x96", "128x128", "144x144", "152x152", "192x192", "384x384", "512x512"]:
                with open(os.path.join(icons_dir, f"icon-{size}.png"), "w") as f:
                    f.write(f"Placeholder for icon-{size}.png")
            
            # Create ZIP file for the WebApp
            installer_path = os.path.join(self.output_dir, f"Praxeon_v{self.version}_PS5_WebApp.zip")
            
            with zipfile.ZipFile(installer_path, "w") as zipf:
                # Add HTML, CSS, and JS files
                zipf.write(index_path, os.path.basename(index_path))
                zipf.write(css_path, os.path.basename(css_path))
                zipf.write(js_path, os.path.basename(js_path))
                zipf.write(manifest_json_path, os.path.basename(manifest_json_path))
                
                # Add icons
                for icon in os.listdir(icons_dir):
                    zipf.write(os.path.join(icons_dir, icon), os.path.join("icons", icon))
                
                # Add a README
                readme_path = os.path.join(ps5_build_dir, "README.txt")
                with open(readme_path, "w") as f:
                    f.write(f"""Praxeon v{self.version} PS5 WebApp

This is a WebApp version of Praxeon for PlayStation 5.
To install:
1. Extract this ZIP file to a USB drive
2. Connect the USB drive to your PlayStation 5
3. Open the web browser and navigate to the extracted files
4. Open index.html to start Praxeon

Created by: Justin "Zygros, the Green" Conzet
""")
                zipf.write(readme_path, os.path.basename(readme_path))
            
            logger.info(f"PS5 WebApp built: {installer_path}")
            return installer_path
        
        except Exception as e:
            logger.error(f"Error building PS5 WebApp: {str(e)}")
            return None

# Main function for testing
def main():
    """Main function for testing installer builder"""
    parser = argparse.ArgumentParser(description="Praxeon Installer Builder")
    parser.add_argument("--source-dir", default="src", help="Source directory")
    parser.add_argument("--output-dir", default="installers", help="Output directory")
    parser.add_argument("--version", default="1.0", help="Praxeon version")
    
    args = parser.parse_args()
    
    builder = PraxeonInstallerBuilder(args.source_dir, args.output_dir, args.version)
    results = builder.build_all()
    
    print("Build results:")
    for format_name, path in results.items():
        print(f"  {format_name}: {path}")

if __name__ == "__main__":
    main()
