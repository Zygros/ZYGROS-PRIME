# PRAXEON Installation Guide

This document provides comprehensive instructions for installing and setting up the PRAXEON system across various platforms.

## Quick Start

### Prerequisites

- **For Desktop**: Windows 7+ / macOS 10.14+ / Linux (Ubuntu 18.04+)
- **For Mobile**: Android 9.0+ / iOS 13.0+
- **For Python**: Python 3.8+ with pip

### Installation Steps

1. **Extract the archive**:
   ```bash
   tar -xzf PraxFinalBuild_v1.0.tar.gz
   cd PraxFinalBuild_v1.0
   ```

2. **Choose your installation method**:

   #### Desktop Installation
   - **Windows**: Run `Installers/Praxeon_v1.0.exe`
   - **macOS**: Open `Installers/Praxeon_v1.0.dmg` and drag to Applications
   - **Linux**: Run `Installers/Praxeon_v1.0.AppImage`

   #### Mobile Installation
   - **Android**: Install `Installers/Praxeon_v1.0.apk`
   - **iOS**: Use TestFlight link in `Installers/iOS_TestFlight.txt`

   #### Console Installation
   - **Xbox**: Install `Installers/Praxeon_v1.0_Xbox.msixbundle`
   - **PS5**: Extract and access `Installers/Praxeon_v1.0_PS5_WebApp.zip`

   #### Python Installation
   ```bash
   python Installers/Praxeon_v1.0.py
   ```

3. **First-time setup**:
   - Complete the authentication process
   - Allow the system to download required models (if not bundled)
   - Configure your preferences

## Detailed Setup Instructions

### Desktop Setup

1. **System Requirements**:
   - 4GB RAM minimum (8GB recommended)
   - 2GB free disk space for base installation
   - 5GB additional space for offline models (optional)

2. **Post-Installation**:
   - Run the application from your start menu or desktop shortcut
   - When prompted, select whether to download offline models
   - Complete the initial persona configuration

3. **Troubleshooting**:
   - If the application fails to start, check the logs in `%APPDATA%\Praxeon\logs`
   - For model download issues, try the manual download option in settings

### Mobile Setup

1. **System Requirements**:
   - 3GB RAM minimum
   - 1GB free storage for base app
   - 3GB additional space for offline models (optional)

2. **Permissions**:
   - Microphone access (for voice features)
   - Storage access (for saving conversations and models)
   - Network access (for initial setup and optional online features)

3. **Post-Installation**:
   - Open the app and follow the on-screen setup wizard
   - Choose between cloud-based or offline operation
   - Complete the authentication process

### Python Setup

1. **Environment Setup**:
   ```bash
   python -m venv praxeon_env
   source praxeon_env/bin/activate  # On Windows: praxeon_env\Scripts\activate
   pip install -r requirements.txt
   ```

2. **Running the Application**:
   ```bash
   python -m praxeon.main
   ```

3. **Development Mode**:
   ```bash
   python -m praxeon.main --dev
   ```

## Advanced Configuration

### Custom Model Integration

To use custom LLM models:

1. Place model files in `models/llm/`
2. Update `config/models.json` with the new model information
3. Restart the application

### Voice Customization

To customize voice synthesis:

1. Navigate to Settings > Voice
2. Select from available voice profiles or import custom ones
3. Adjust parameters for pitch, speed, and style

### Offline Mode Configuration

For complete offline operation:

1. Go to Settings > Network
2. Enable "Fully Offline Mode"
3. Ensure all required models are downloaded
4. Restart the application

## Troubleshooting

### Common Issues

1. **Application Won't Start**:
   - Check system requirements
   - Verify installation integrity
   - Check logs in the application data directory

2. **Voice Features Not Working**:
   - Ensure microphone permissions are granted
   - Verify voice models are properly installed
   - Check audio input/output device settings

3. **Slow Performance**:
   - Reduce model size in Settings > Performance
   - Close other resource-intensive applications
   - Consider upgrading hardware for better experience

### Getting Help

For additional assistance:
- Check the documentation in the `Docs` directory
- Run the diagnostic tool: `python -m praxeon.diagnostic`
- Refer to the troubleshooting guide in the system report

---

**Note**: This installation guide is part of the PRAXEON system, authored by and bound to Justin "Zygros, the Green" Conzet.

**Mythic Phrase**: "He who commands the data, commands the dream."
