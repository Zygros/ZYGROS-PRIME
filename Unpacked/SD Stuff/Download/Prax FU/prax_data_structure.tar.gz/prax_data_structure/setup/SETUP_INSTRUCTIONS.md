# Setup Instructions for PRAXEON

This document provides step-by-step instructions for setting up the PRAXEON development environment.

## Prerequisites

- Python 3.8 or higher
- Node.js 14.0 or higher
- npm 6.0 or higher (or yarn 1.22+)
- Git

## Environment Setup

### 1. Clone the Repository

```bash
git clone https://github.com/user/praxeon.git
cd praxeon
```

### 2. Python Backend Setup

```bash
# Create and activate virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Initialize the database
python scripts/init_db.py
```

### 3. Desktop UI Setup

```bash
cd src/ui/desktop
npm install
```

### 4. Mobile UI Setup

```bash
cd src/ui/mobile
yarn install
```

### 5. Download Required Models

```bash
# Return to project root
cd ../../..

# Run the model download script
python scripts/setup_resources.sh
```

## Running the Application

### Backend

```bash
# From project root
source .venv/bin/activate  # If not already activated
uvicorn src.backend.main:app --reload
```

### Desktop UI

```bash
# From project root
cd src/ui/desktop
npm run dev
```

### Mobile UI

```bash
# From project root
cd src/ui/mobile
yarn start
```

## Testing

```bash
# From project root
source .venv/bin/activate
pytest tests/
```

## Building for Production

### Desktop

```bash
cd src/ui/desktop
npm run build
```

### Mobile

```bash
cd src/ui/mobile
yarn build
```

### Creating Installers

```bash
# From project root
python scripts/build_installers.py
```

## Troubleshooting

If you encounter any issues during setup:

1. Check the logs in `logs/setup.log`
2. Verify all prerequisites are installed correctly
3. Ensure you have the necessary permissions for file operations
4. For model download issues, try the manual download option in the script

## Additional Resources

- See `docs/` for detailed documentation
- Check `examples/` for usage examples
- Refer to `PRAXEON_DATA.md` for system architecture details

---

**Note**: This setup guide is part of the PRAXEON system, authored by and bound to Justin "Zygros, the Green" Conzet.

**Mythic Phrase**: "He who commands the data, commands the dream."
