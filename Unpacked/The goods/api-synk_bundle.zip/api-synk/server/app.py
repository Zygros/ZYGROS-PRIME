
from fastapi import FastAPI, HTTPException, Query
from fastapi import Body
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from time import time
import math

app = FastAPI(title="API-SYNK Reference", version="0.1.0")

# -----------------------
# Data models
# -----------------------

class NegotiationRequest(BaseModel):
    client_id: str
    capabilities: Dict[str, Any] = Field(default_factory=dict)

class NegotiationResponse(BaseModel):
    session_id: str
    accepted_protocol: str
    accepted_format: str
    auth_mode: str
    expires_at: str
    hints: Dict[str, Any] = Field(default_factory=dict)

class Candidate(BaseModel):
    endpoint: str
    latency_ms: float
    error_rate: float
    cost_per_1k: float
    health: str
    burst_limit_rps: float = 0

class Objectives(BaseModel):
    weight_latency: float = 0.5
    weight_error: float = 0.3
    weight_cost: float = 0.2

class RouteRequest(BaseModel):
    session_id: str
    candidates: List[Candidate]
    request: Dict[str, Any]
    objectives: Optional[Objectives] = None

class RouteResponse(BaseModel):
    selected_endpoint: str
    score: float
    reasons: List[str]
    applied_limits: Dict[str, Any]

class TranslationRequest(BaseModel):
    source: str
    target: str
    payload: Dict[str, Any]
    mapping: Optional[Dict[str, Any]] = None

class TranslationResponse(BaseModel):
    payload: Dict[str, Any]
    fidelity_score: float
    notes: List[str] = []

# -----------------------
# In-memory stores
# -----------------------
SESSIONS: Dict[str, Dict[str, Any]] = {}
LIMITS: Dict[str, Dict[str, Any]] = {}
METRICS: Dict[str, float] = {
    "requests": 0,
    "success": 0,
    "failures": 0,
    "p95_latency_ms": 0.0,
    "success_rate": 1.0,
    "normalization_coverage": 0.0,
    "translation_fidelity": 0.0,
    "cost_per_1k_effective": 0.0
}
LAT_SAMPLES: List[float] = []

def now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()

def p95(values: List[float]) -> float:
    if not values: return 0.0
    arr = sorted(values)
    idx = int(math.ceil(0.95 * len(arr))) - 1
    return arr[max(0, min(idx, len(arr)-1))]

# -----------------------
# Helper logic
# -----------------------
def score_candidate(c: Candidate, mins, maxs, wL, wE, wC):
    eps = 1e-9
    Lp = (c.latency_ms - mins["lat"]) / (maxs["lat"] - mins["lat"] + eps)
    Cp = (c.cost_per_1k - mins["cost"]) / (maxs["cost"] - mins["cost"] + eps)
    Ep = c.error_rate
    score = wL*(1 - Lp) + wE*(1 - Ep) + wC*(1 - Cp)
    return score, {"L'": Lp, "E": Ep, "C'": Cp}

def update_limits(session_id: str, throttle_rps: float = 50, retry_budget: int = 3):
    LIMITS[session_id] = {
        "session_id": session_id,
        "current_rps": throttle_rps,
        "retry_budget_remaining": retry_budget,
        "brownout": False
    }

# -----------------------
# Routes
# -----------------------

@app.get("/v1/health")
def health():
    return {"status": "ok"}

@app.get("/v1/metrics")
def metrics():
    # compute rolling p95
    METRICS["p95_latency_ms"] = p95(LAT_SAMPLES)
    total = METRICS["requests"]
    succ = METRICS["success"]
    METRICS["success_rate"] = (succ / total) if total else 1.0
    return METRICS

@app.post("/v1/negotiate", response_model=NegotiationResponse)
def negotiate(req: NegotiationRequest = Body(...)):
    # naive acceptance of first capability preferences with secure defaults
    protocol = (req.capabilities.get("protocols") or ["http"])[0]
    accepted_format = (req.capabilities.get("formats") or ["json"])[0]
    auth_mode = (req.capabilities.get("auth") or ["oauth2"])[0]

    session_id = f"synk_{int(time()*1000)}_{req.client_id}"
    SESSIONS[session_id] = {
        "client_id": req.client_id,
        "created_at": now_iso(),
        "protocol": protocol,
        "format": accepted_format,
        "auth": auth_mode
    }
    update_limits(session_id, throttle_rps=req.capabilities.get("rate_limit_budget_rps", 120))

    resp = NegotiationResponse(
        session_id=session_id,
        accepted_protocol=protocol,
        accepted_format=accepted_format,
        auth_mode=auth_mode,
        expires_at=now_iso(),
        hints={
            "throttle_rps": LIMITS[session_id]["current_rps"],
            "retry_budget": LIMITS[session_id]["retry_budget_remaining"],
            "idempotency_required": True
        }
    )
    return resp

@app.get("/v1/limits")
def get_limits(session_id: str = Query(...)):
    if session_id not in LIMITS:
        raise HTTPException(404, "Unknown session")
    return LIMITS[session_id]

@app.post("/v1/translate", response_model=TranslationResponse)
def translate(req: TranslationRequest = Body(...)):
    # Simple passthrough translation demo with identity mapping
    payload = req.payload if not req.mapping else {req.mapping.get(k, k): v for k, v in req.payload.items()}
    fidelity = 1.0 if not req.mapping else 0.97
    return TranslationResponse(payload=payload, fidelity_score=fidelity, notes=["demo-mapping"] if req.mapping else [])

@app.post("/v1/route", response_model=RouteResponse)
def route(req: RouteRequest = Body(...)):
    import random, time as _t
    t0 = _t.time()

    if req.session_id not in SESSIONS:
        raise HTTPException(401, "Unknown session; negotiate first.")

    # basic health filter
    candidates = [c for c in req.candidates if c.health != "down"]
    if not candidates:
        raise HTTPException(503, "No healthy candidates")

    mins = {
        "lat": min(c.latency_ms for c in candidates),
        "cost": min(c.cost_per_1k for c in candidates),
    }
    maxs = {
        "lat": max(c.latency_ms for c in candidates),
        "cost": max(c.cost_per_1k for c in candidates),
    }
    obj = req.objectives or Objectives()
    best = None
    best_score = -1
    reasons = []
    for c in candidates:
        s, comps = score_candidate(c, mins, maxs, obj.weight_latency, obj.weight_error, obj.weight_cost)
        # Simulate circuit-breaker: if error high, penalize
        if c.error_rate > 0.08:
            s *= 0.8
        if s > best_score:
            best_score = s
            best = c
    # Apply rate limits (throttle to min of session and endpoint burst)
    lim = LIMITS.get(req.session_id, {})
    throttle = float(min(lim.get("current_rps", 50), best.burst_limit_rps or 1e9))

    # metrics update
    METRICS["requests"] += 1
    METRICS["success"] += 1
    LAT_SAMPLES.append((random.random()*0.2 + 0.1) * best.latency_ms)  # synthetic

    elapsed = (_t.time() - t0) * 1000.0
    reasons.append(f"selected {best.endpoint} with score={round(best_score,4)}; p95 candidate range {mins['lat']}..{maxs['lat']} ms")

    return RouteResponse(
        selected_endpoint=best.endpoint,
        score=best_score,
        reasons=reasons,
        applied_limits={
            "throttle_rps": throttle,
            "circuit_breaker_open": best.error_rate > 0.15,
            "retry_budget_used": 0
        }
    )
