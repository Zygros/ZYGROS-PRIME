
from server.app import score_candidate
from types import SimpleNamespace as NS

def test_scoring_prefers_low_latency_low_error_low_cost():
    mins = {"lat": 100, "cost": 0.3}
    maxs = {"lat": 300, "cost": 0.9}
    wL, wE, wC = 0.5, 0.3, 0.2
    a = NS(latency_ms=150, error_rate=0.02, cost_per_1k=0.4)
    b = NS(latency_ms=250, error_rate=0.05, cost_per_1k=0.35)
    sa, _ = score_candidate(a, mins, maxs, wL, wE, wC)
    sb, _ = score_candidate(b, mins, maxs, wL, wE, wC)
    assert sa > sb
