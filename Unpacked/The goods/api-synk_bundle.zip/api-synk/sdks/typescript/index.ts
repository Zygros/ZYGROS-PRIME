
export type Capabilities = {
  protocols?: string[];
  auth?: ("oauth2"|"apikey"|"mtls"|"none")[];
  formats?: ("json"|"xml"|"csv")[];
  rate_limit_budget_rps?: number;
};

export class ApiSynkClient {
  baseUrl: string;
  token?: string;
  sessionId?: string;

  constructor(baseUrl: string, token?: string) {
    this.baseUrl = baseUrl.replace(/\/+$/, '');
    this.token = token;
  }

  private headers(): Record<string,string> {
    const h: Record<string,string> = {"Content-Type":"application/json"};
    if (this.token) h["Authorization"] = `Bearer ${this.token}`;
    return h;
  }

  async negotiate(clientId: string, capabilities: Capabilities): Promise<any> {
    const resp = await fetch(`${this.baseUrl}/negotiate`, {
      method: 'POST', headers: this.headers(),
      body: JSON.stringify({client_id: clientId, capabilities})
    });
    if (!resp.ok) throw new Error(`negotiate failed: ${resp.status}`);
    const data = await resp.json();
    this.sessionId = data.session_id;
    return data;
  }

  async translate(source: string, target: string, payload: any, mapping?: Record<string, any>): Promise<any> {
    const body: any = {source, target, payload};
    if (mapping) body.mapping = mapping;
    const resp = await fetch(`${this.baseUrl}/translate`, {
      method: 'POST', headers: this.headers(), body: JSON.stringify(body)
    });
    if (!resp.ok) throw new Error(`translate failed: ${resp.status}`);
    return await resp.json();
  }

  async route(candidates: any[], request: any, objectives?: any): Promise<any> {
    if (!this.sessionId) throw new Error("Call negotiate() first");
    const body: any = {session_id: this.sessionId, candidates, request};
    if (objectives) body.objectives = objectives;
    const resp = await fetch(`${this.baseUrl}/route`, {
      method: 'POST', headers: this.headers(), body: JSON.stringify(body)
    });
    if (!resp.ok) throw new Error(`route failed: ${resp.status}`);
    return await resp.json();
  }

  async limits(): Promise<any> {
    if (!this.sessionId) throw new Error("Call negotiate() first");
    const resp = await fetch(`${this.baseUrl}/limits?session_id=${this.sessionId}`, {
      method: 'GET', headers: this.headers()
    });
    if (!resp.ok) throw new Error(`limits failed: ${resp.status}`);
    return await resp.json();
  }
}
