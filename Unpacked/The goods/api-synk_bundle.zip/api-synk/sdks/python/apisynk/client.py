
import requests
from typing import Dict, Any, Optional

class ApiSynkClient:
    def __init__(self, base_url: str, token: Optional[str] = None, session_id: Optional[str] = None):
        self.base_url = base_url.rstrip('/')
        self.token = token
        self.session_id = session_id

    def _headers(self):
        h = {"Content-Type": "application/json"}
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h

    def negotiate(self, client_id: str, capabilities: Dict[str, Any]) -> Dict[str, Any]:
        resp = requests.post(f"{self.base_url}/negotiate", json={"client_id": client_id, "capabilities": capabilities}, headers=self._headers())
        resp.raise_for_status()
        data = resp.json()
        self.session_id = data["session_id"]
        return data

    def translate(self, source: str, target: str, payload: Dict[str, Any], mapping: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        req = {"source": source, "target": target, "payload": payload}
        if mapping: req["mapping"] = mapping
        resp = requests.post(f"{self.base_url}/translate", json=req, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def route(self, candidates: list, request: Dict[str, Any], objectives: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        if not self.session_id:
            raise RuntimeError("Call negotiate() first to obtain a session_id")
        req = {"session_id": self.session_id, "candidates": candidates, "request": request}
        if objectives: req["objectives"] = objectives
        resp = requests.post(f"{self.base_url}/route", json=req, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def limits(self) -> Dict[str, Any]:
        if not self.session_id:
            raise RuntimeError("No session_id. Call negotiate() first.")
        resp = requests.get(f"{self.base_url}/limits", params={"session_id": self.session_id}, headers=self._headers())
        resp.raise_for_status()
        return resp.json()
