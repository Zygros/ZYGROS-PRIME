# API-SYNK Reference Server

Minimal FastAPI implementation of the API-SYNK spec: negotiation, translation, routing, limits, and ops endpoints.
Includes a simple scoring function, token-bucket-style limits, circuit-breaker, brownout, and basic metrics.

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r server/requirements.txt
uvicorn server.app:app --reload --port 8080
```

## Endpoints
- `POST /v1/negotiate`
- `POST /v1/translate`
- `POST /v1/route`
- `GET  /v1/limits?session_id=...`
- `GET  /v1/health`
- `GET  /v1/metrics`

See `server/openapi.yaml` for the API description.
