
# Common Error Modes & Fixes
1) Dimension mismatch -> add dims_check + pad_crop_guard before commit.
2) Palette off by 1 color -> run palette_check and remap to closest majority.
3) Overfitting to single example -> test invariants via rot90/reflect synth-cases.
4) Component mislabel under symmetry -> canonicalize orientation (north-west priority).
5) Excessive program length -> prune to <=8 ops unless accuracy proofs demand longer.
