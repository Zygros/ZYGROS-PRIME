
# Solver Chain Heuristics — HTC^100 Delta
Goal: Raise official ARC eval toward 85% by improving family-switching, constraint checks, and repair moves.

A. Family Switching (beam=3, vote+repair)
1. Start with geom+colormap. If no exact match after 2 proposals -> branch to symmetry_enforce and pattern_scan.
2. If color histogram shift > 0.2 and connected components stable -> prefer colormap_transform.
3. If axis-aligned mirror reduces description length >= 20% -> symmetry_enforce first.
4. If small islands (<= 3 cells) dominate -> floodfill_ops followed by grouping->recolor.
5. If ruleset remains ambiguous after 3 proposals -> fallback to dsl_synthesis with minimal program search (max 6 ops).

B. Constraint Checks (pre-commit)
- Enforce output dims against inferred transform (flip/rotate/scale).
- Penalize programs longer than 8 ops unless accuracy >= 1.0 on synthetic checks.
- Prefer programs with stable invariants across augmented inputs (rot90, reflect).

C. Repair Moves
- If off-by-one boundary hits: add pad/crop guard.
- If color map mismatch only: apply palette remap via majority voting.
- If component labels shift under symmetry: relabel via canonical orientation (NW-first).

D. Debate Engine Prompts (per round)
- Proposer: State the minimal rule as pseudo-DSL and test on at least 2 counterfactuals.
- Skeptic: Produce a counterexample or show a shorter program with same accuracy.
- Arbiter: Pick the shortest program that survives counterexample; require dimension check and palette remap audit.

E. Quantum Node Selection
- Pareto frontier over (accuracy, program_length, time).
- Tie-breaker: invariant count (higher is better).
