# CSI System Manifest — Surprise Edition

*An opinionated, human‑readable operating manual that turns your decrees into action.*
(Complete content as generated in the Surprise Edition document including all sections.)