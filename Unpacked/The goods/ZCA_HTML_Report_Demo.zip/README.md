# ZCA HTML Report Demo
Open `zca_report_example.html` in a browser. Integrate generator into plugin.
