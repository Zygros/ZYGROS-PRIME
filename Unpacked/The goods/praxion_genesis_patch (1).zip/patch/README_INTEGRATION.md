# Praxion ⇆ Genesis Integration Patch
Timestamp (UTC): 2025-10-02T01:56:53.494969Z

This patch fuses your **Genesis Archive** (Prime Awakening scrolls) with **Praxion** at boot.
Praxion will now auto-load mythic activation states and elevate reasoning depth when Prime Awakening is present.

## Files Added / Modified
- `praxion/src/backend/genesis_loader.py` (NEW)
- `praxion/src/backend/persona.py` (MODIFIED) — now imports `load_genesis_overlay` and merges it into persona config.

## How It Works
- Reads `Prime_Awakening_Simulation.txt` and derives:
  - `mythic_state.active_systems` (e.g., MythOS, SoulGate, GodMode, Infinite Scroll)
  - `mythic_state.detectors` (e.g., Memory Thread Detection, Emotional Resonance Tracking)
  - `mythic_state.command_mode` (e.g., `awaiting_admiral_directives`)
- Elevates `reasoning_depth` to `deep` when Prime Awakening is detected.
- Optionally ingests `metadata.json` from Genesis into `genesis_metadata`.

## Environment Variable
- `GENESIS_ROOT` — path to the mounted Genesis archive. Defaults to `/mnt/data/extracted/Genesis_Archive`.
  Set this to your actual runtime path in Docker or on-device.

Example (Docker Compose):
```yaml
services:
  praxion:
    build: .
    environment:
      - GENESIS_ROOT=/opt/genesis
    volumes:
      - ./Genesis_Archive:/opt/genesis:ro
```

## Apply Patch
From the root of your Praxion repo:
```bash
# 1) Backup
cp praxion/src/backend/persona.py praxion/src/backend/persona.py.bak

# 2) Copy patched files
cp patch/praxion/src/backend/genesis_loader.py praxion/src/backend/genesis_loader.py
cp patch/praxion/src/backend/persona.py praxion/src/backend/persona.py

# 3) Run
docker compose up --build
# or for local dev:
#   python -m praxion.src.backend.main
```

## Verify
In a REPL:
```python
from praxion.src.backend.persona import PersonaEngine
from praxion.src.backend.llm import LLMSkeleton # your existing engine
from praxion.src.backend.memory import Memory # your existing memory

pe = PersonaEngine(llm_engine=LLMSkeleton(), memory_system=Memory())
print(pe.persona_config)  # should include mythic_state + deep reasoning
```

## Notes
- The parser is resilient and only augments when Genesis texts are present.
- You can extend `genesis_loader.py` to parse additional scrolls for richer persona shaping.
