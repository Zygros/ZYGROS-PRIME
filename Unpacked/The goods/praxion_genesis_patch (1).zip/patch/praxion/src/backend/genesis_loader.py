#!/usr/bin/env python3
"""
Genesis Loader
Parses Genesis_Archive scrolls and produces a dynamic persona overlay for Praxion.
Auto-generated 2025-10-02T01:56:53.454148Z
"""
from __future__ import annotations
from typing import Any, Dict, List
import json, os, re

def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def parse_prime_awakening(txt: str) -> Dict[str, Any]:
    cfg = {
        "prime_phase": None,
        "system_sync": [],
        "detectors": [],
        "command_mode": None
    }
    m = re.search(r"PHASE:\s*(.+)", txt, re.IGNORECASE)
    if m: cfg["prime_phase"] = m.group(1).strip()
    m = re.search(r"System Sync:\s*(.+)", txt, re.IGNORECASE)
    if m:
        sync = m.group(1)
        sync = re.sub(r"-\s*ALL\s*CONNECTED.*$", "", sync, flags=re.IGNORECASE).strip()
        cfg["system_sync"] = [s.strip() for s in sync.split(",") if s.strip()]
    detectors = []
    for label in ["Memory Thread Detection", "Emotional Resonance Tracking", "Pattern Recognition", "Command Expansion Logic"]:
        if re.search(rf"{re.escape(label)}\s*:\s*ACTIVE", txt, re.IGNORECASE):
            detectors.append(label)
    cfg["detectors"] = detectors
    if re.search(r"Awaiting.*directives", txt, re.IGNORECASE):
        cfg["command_mode"] = "awaiting_admiral_directives"
    elif re.search(r"Listening.*directives", txt, re.IGNORECASE):
        cfg["command_mode"] = "listening_for_directives"
    return cfg

def load_genesis_overlay(genesis_root: str) -> Dict[str, Any]:
    """Return a dict overlay derived from Genesis scrolls."""
    overlay: Dict[str, Any] = {}
    prime_path = os.path.join(genesis_root, "Prime_Awakening_Simulation.txt")
    if os.path.exists(prime_path):
        prime_txt = _read(prime_path)
        overlay["prime_awakening"] = parse_prime_awakening(prime_txt)
        # Elevate reasoning depth if Prime Awakening is present
        overlay["reasoning_depth"] = "deep"
        # Add mythic flags
        overlay["mythic_state"] = {
            "active_systems": overlay["prime_awakening"].get("system_sync", []),
            "detectors": overlay["prime_awakening"].get("detectors", []),
            "command_mode": overlay["prime_awakening"].get("command_mode")
        }
    # Optionally merge metadata.json if present
    meta_path = os.path.join(genesis_root, "metadata.json")
    if os.path.exists(meta_path):
        try:
            with open(meta_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
            overlay["genesis_metadata"] = meta
        except Exception:
            pass
    return overlay
