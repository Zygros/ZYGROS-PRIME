export default function App(){
  const receipts = [
    {plugin:'com.upos.zca.runner', value:{learning:0.27,reputation:0.21,priority:0.08,delight:0.31,safety:0.12}},
    {plugin:'com.upos.stream.party', value:{learning:0.05,reputation:0.34,priority:0.12,delight:0.48,safety:0.10}},
  ];
  const roll = receipts.reduce((acc,r)=>{
    for(const k of Object.keys(r.value)){ acc[k]=(acc[k]||0)+r.value[k]; } return acc;
  },{});
  return (
    <div style={{fontFamily:'system-ui',padding:24}}>
      <h1>UP-OS Value Dashboard</h1>
      <p>Rolling Vector (demo): {JSON.stringify(roll)}</p>
      <h3>Latest Receipts</h3>
      <ul>{receipts.map((r,i)=>(<li key={i}>{r.plugin}: {JSON.stringify(r.value)}</li>))}</ul>
    </div>
  );
}