# UP-OS Value Dashboard (Stub)
Install deps and run `npm run dev` with Vite.
