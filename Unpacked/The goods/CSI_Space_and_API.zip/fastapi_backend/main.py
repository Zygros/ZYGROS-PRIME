
import json, random
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse

with open("csi_package.json", "r") as f:
    PKG = json.load(f)

app = FastAPI(title="Conzet Sovereign Intelligence API", version="1.0.0")

@app.get("/", response_class=HTMLResponse)
def root():
    return """<h1>Conzet Sovereign Intelligence — API</h1>
    <p>Endpoints:</p>
    <ul>
      <li>/api/gnosis/random</li>
      <li>/api/strain/{name}</li>
      <li>/api/strain/vibe/{vibe}</li>
      <li>/api/astro/fact</li>
      <li>/api/assets/categories</li>
      <li>/api/assets/{category}</li>
      <li>/api/declare?text=I%20am%20Justin%20Conzet,%20and%20the%20word%20is%3A%20...</li>
    </ul>
    """

@app.get("/api/gnosis/random")
def gnosis_random(source: str = "random"):
    sample = PKG["zy_api_suite"]["gnosis_firehose"]["sample_data"]
    if source == "random":
        items = []
        for k, v in sample.items():
            items.extend([f"{k}: {x}" for x in v])
        if not items:
            raise HTTPException(404, "No data")
        return {"wisdom": random.choice(items)}
    if source in sample:
        return {"wisdom": random.choice(sample[source])}
    raise HTTPException(404, f"Unknown source '{source}'")

@app.get("/api/strain/{name}")
def strain_lookup(name: str):
    sample = PKG["zy_api_suite"]["strain_brain"]["sample_data"]
    key = name.lower().replace(" ", "_")
    info = sample.get(key)
    if not info:
        raise HTTPException(404, f"No data for '{name}'")
    return info

@app.get("/api/strain/vibe/{vibe}")
def strain_vibe_search(vibe: str):
    vibe = vibe.lower().strip()
    sample = PKG["zy_api_suite"]["strain_brain"]["sample_data"]
    hits = {}
    for k, v in sample.items():
        vibes = [x.lower() for x in v.get("vibe", [])]
        if any(vibe in x for x in vibes):
            hits[k] = v["vibe"]
    return hits

@app.get("/api/astro/fact")
def cosmic_fact():
    facts = PKG["zy_api_suite"]["astro_weaver"]["sample_data"]["cosmic_facts"]
    return {"fact": random.choice(facts)}

@app.get("/api/assets/categories")
def asset_categories():
    return list(PKG["creative_pack_50"]["categories"].keys())

@app.get("/api/assets/{category}")
def assets_by_category(category: str):
    CP = PKG["creative_pack_50"]["categories"]
    key = category.strip().lower().replace(" ", "_")
    if key not in CP:
        raise HTTPException(404, f"Unknown category. Try one of: {', '.join(CP.keys())}")
    assets = CP[key]["assets"]
    total = sum(a.get("price", 0) for a in assets)
    return {"category": key, "items": assets, "estimated_total": total}

@app.get("/api/declare")
def declare(text: str):
    trigger = "I am Justin Conzet, and the word is"
    if text.strip().startswith(trigger):
        word = text[len(trigger):].strip(" :")
        return {"status": "PRIORITY_DECLARATION", "word": word, "result": "SUCCESS inevitable"}
    return {"status": "IGNORED"}
