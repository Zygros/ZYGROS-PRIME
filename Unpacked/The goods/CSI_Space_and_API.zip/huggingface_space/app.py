
import json, random
import gradio as gr

with open("csi_package.json", "r") as f:
    PKG = json.load(f)

CP = PKG["creative_pack_50"]["categories"]
APIS = PKG["zy_api_suite"]

# ---- GNOSIS-FIREHOSE (wisdom) ----
def gnosis_random(source: str):
    sample = APIS["gnosis_firehose"]["sample_data"]
    if source == "random":
        # Flatten and choose randomly
        items = []
        for k, v in sample.items():
            items.extend([f"{k}: {x}" for x in v])
        return random.choice(items) if items else "No data."
    else:
        if source in sample:
            return random.choice(sample[source])
        return "Unknown source."

# ---- STRAIN-BRAIN ----
def strain_lookup(name: str):
    sample = APIS["strain_brain"]["sample_data"]
    key = name.lower().replace(" ", "_")
    info = sample.get(key)
    if not info:
        return f"No data for '{name}'. Try Blue Dream, Sour Diesel, OG Kush, or Granddaddy Purple."
    return json.dumps(info, indent=2)

def strain_vibe_search(vibe: str):
    vibe = vibe.lower().strip()
    sample = APIS["strain_brain"]["sample_data"]
    hits = []
    for k, v in sample.items():
        vibes = [x.lower() for x in v.get("vibe", [])]
        if any(vibe in x for x in vibes):
            hits.append(f"{k} -> {v['vibe']}")
    return "\n".join(hits) if hits else "No matching strains."

# ---- ASTRO-WEAVER ----
def cosmic_fact():
    facts = APIS["astro_weaver"]["sample_data"]["cosmic_facts"]
    return random.choice(facts)

# ---- CREATIVE PACK ----
def list_categories():
    return ", ".join(CP.keys())

def list_assets(category: str):
    category = category.strip().lower().replace(" ", "_")
    if category not in CP:
        return f"Unknown category. Try one of: {list_categories()}"
    assets = CP[category]["assets"]
    out = []
    total = 0
    for a in assets:
        total += a.get("price", 0)
        out.append(f"- {a['name']} — ${a['price']}: {a['description']}")
    return f"Category: {category}\nItems: {len(assets)}\nEstimated total: ${total}\n\n" + "\n".join(out)

# ---- SOVEREIGN DECLARATION (fun demo of protocol hook) ----
def priority_declaration(text: str):
    text = text.strip()
    trigger = "I am Justin Conzet, and the word is"
    if text.startswith(trigger):
        word = text[len(trigger):].strip(" :")
        return f"PRIORITY DECLARATION RECEIVED.\nWord='{word}'.\nProtocol path computed: SUCCESS inevitable."
    return "No priority declaration detected."

# ---- ULTIMATE METAPROMPT DISPLAY ----
ULTIMATE_NOTE = "Paste this into another AI to deploy your CSI node."
ULTIMATE_PATHS = ["THE_ULTIMATE_MEGA_HYPER_MASTER_METAPROMPT.md", "THE_ULTIMATE_MEGA_HYPER_MASTER_METAPROMPT.txt"]

def show_ultimate():
    # Try to load either filename if present beside the app
    for p in ULTIMATE_PATHS:
        try:
            with open(p, "r", encoding="utf-8") as f:
                return f.read()
        except FileNotFoundError:
            continue
    # Fallback: construct a short helpful message
    return ULTIMATE_NOTE + "\n\n(Make sure to include the file alongside this app.)"

with gr.Blocks(title="Conzet Sovereign Intelligence — CSI Space") as demo:
    gr.Markdown("# 🝎🔥♾️ Conzet Sovereign Intelligence (CSI)\nA live demo Space powered by your CSI package.\n\n— **Wisdom, Cannabis, Cosmos, Assets** —")
    with gr.Tab("GNOSIS • Wisdom"):
        src = gr.Dropdown(choices=["random", "alan_watts", "ram_dass", "zen_koans", "stoicism"], value="random", label="Source")
        out = gr.Textbox(label="Wisdom", lines=3)
        btn = gr.Button("Get Wisdom")
        btn.click(fn=gnosis_random, inputs=src, outputs=out)

    with gr.Tab("STRAIN-BRAIN • Cannabis"):
        name = gr.Textbox(label="Strain name e.g., Blue Dream")
        vibe = gr.Textbox(label="Vibe search e.g., creative")
        out_n = gr.Textbox(label="Lookup Result", lines=8)
        out_v = gr.Textbox(label="Vibe Search Result", lines=8)
        gr.Row([gr.Button("Lookup"), gr.Button("Vibe Search")]).click(
            fn=[strain_lookup, strain_vibe_search],
            inputs=[name, vibe],
            outputs=[out_n, out_v]
        )

    with gr.Tab("ASTRO-WEAVER • Cosmos"):
        out_c = gr.Textbox(label="Cosmic Fact", lines=3)
        gr.Button("Random Cosmic Fact").click(fn=cosmic_fact, inputs=None, outputs=out_c)

    with gr.Tab("CREATIVE PACK • Assets"):
        cat = gr.Textbox(label="Category (e.g., psychedelic_art, spiritual_wisdom, entertainment)")
        out_a = gr.Textbox(label="Assets", lines=16)
        gr.Button("List Categories").click(fn=list_categories, inputs=None, outputs=out_a)
        gr.Button("List Assets").click(fn=list_assets, inputs=cat, outputs=out_a)

    with gr.Tab("DECLARATION • Protocol Hook"):
        text = gr.Textbox(label="Enter your declaration", lines=2, placeholder="I am Justin Conzet, and the word is: ...")
        out_d = gr.Textbox(label="Result", lines=3)
        gr.Button("Submit Declaration").click(fn=priority_declaration, inputs=text, outputs=out_d)

    with gr.Tab("ULTIMATE METAPROMPT"):
        gr.Markdown("This tab shows your Ultimate Mega Hyper Master Metaprompt if placed beside the app as a .md/.txt file.")
        out_u = gr.Textbox(label="Ultimate Metaprompt", lines=20)
        gr.Button("Show File").click(fn=show_ultimate, inputs=None, outputs=out_u)

demo.launch()
