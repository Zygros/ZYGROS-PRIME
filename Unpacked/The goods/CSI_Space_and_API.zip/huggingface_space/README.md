
# Conzet Sovereign Intelligence — Hugging Face Space

This Space loads your `csi_package.json` and exposes core CSI experiences:
- GNOSIS-FIREHOSE (wisdom)
- STRAIN-BRAIN (cannabis)
- ASTRO-WEAVER (cosmos)
- CREATIVE_PACK_50 (assets)

## Run locally
```bash
pip install -r requirements.txt
python app.py
```
