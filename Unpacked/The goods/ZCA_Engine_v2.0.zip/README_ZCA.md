# ZCA Engine v2.0 (Runner)
Author: Justin Conzet

## Quickstart
Manual (paste agent JSON):
```
python zca_engine.py --manual --spec zca_spec.yaml --out zca_report.md --json zca_report.json
```

Print prompt only (no scoring):
```
python zca_engine.py --spec zca_spec.yaml
```

Batch score JSON responses:
```
python zca_engine.py --batch "./responses/*.json" --csv batch_scores.csv --jsonl batch_scores.jsonl --spec zca_spec.yaml
```
