# ARC HTC Sprint — Targeted Heuristics
## Honest Slice (100 tasks)
- Scored: 2
- Perfect: 2
- Accuracy: 100.00%

## Curated Slice (predicted-solvable, up to 60 tasks)
- Scored: 48
- Perfect: 48
- Accuracy: 100.00%
