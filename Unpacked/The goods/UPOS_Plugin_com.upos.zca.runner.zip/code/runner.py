import os, sys, json, subprocess, pathlib

def main():
    # UP-OS passes inputs via STDIN or env; here we read a local file or env
    cfg = {}
    try:
        cfg = json.load(sys.stdin)
    except Exception:
        pass
    # Fallback to envs
    mode = cfg.get("mode") or os.environ.get("UPOS_MODE","prompt")
    spec = cfg.get("spec_path") or os.environ.get("UPOS_SPEC","./code/zca_spec.yaml")
    out_md = cfg.get("out_md") or "./out/zca_report.md"
    out_json = cfg.get("out_json") or "./out/zca_report.json"
    batch = cfg.get("batch_glob")

    pathlib.Path("./out").mkdir(parents=True, exist_ok=True)

    cmd = ["python3","./code/zca_engine.py","--spec", spec]
    if mode == "manual":
        # Just print prompt and exit; UP-OS can route it to a target agent externally
        # For now, output prompt to stdout and declare ok
        prompt = subprocess.check_output(cmd).decode("utf-8","ignore")
        print(json.dumps({"ok": True, "prompt": prompt}))
        return 0
    elif mode == "prompt":
        prompt = subprocess.check_output(cmd).decode("utf-8","ignore")
        print(json.dumps({"ok": True, "prompt": prompt}))
        return 0
    elif mode == "batch" and batch:
        cmd = ["python3","./code/zca_engine.py","--batch", batch, "--csv","./out/batch_scores.csv","--jsonl","./out/batch_scores.jsonl","--spec", spec]
        subprocess.check_call(cmd)
        print(json.dumps({"ok": True, "batch_csv":"./out/batch_scores.csv", "batch_jsonl":"./out/batch_scores.jsonl"}))
        return 0
    else:
        print(json.dumps({"ok": False, "error":"invalid-mode"}))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
