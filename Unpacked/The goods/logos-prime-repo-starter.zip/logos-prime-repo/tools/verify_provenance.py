#!/usr/bin/env python3
import sys, hashlib, json, pathlib, datetime

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    if len(sys.argv) < 2:
        print("Usage: verify_provenance.py <file>")
        sys.exit(1)
    path = pathlib.Path(sys.argv[1])
    if not path.exists():
        print("File not found:", path)
        sys.exit(1)
    digest = sha256_file(path)
    payload = {
        "file": str(path),
        "sha256": digest,
        "timestamp_utc": datetime.datetime.utcnow().isoformat() + "Z"
    }
    print(json.dumps(payload, indent=2))

if __name__ == "__main__":
    main()
