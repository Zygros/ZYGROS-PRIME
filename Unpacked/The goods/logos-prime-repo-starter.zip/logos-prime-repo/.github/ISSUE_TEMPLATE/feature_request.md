---
name: Feature request
about: Propose an improvement
---
**Motivation**

**Proposal**

**References**
