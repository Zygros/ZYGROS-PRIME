---
name: Bug report
about: Report a problem with specs or assets
---
**Describe the bug**
A clear description of the issue.

**Expected vs Actual**

**Proposed fix**
