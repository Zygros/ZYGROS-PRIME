# Contributing

Thanks for your interest. This project publishes a constitutional framework and reference assets.

## How to contribute
- Open an Issue with a precise proposal.
- For pull requests: fork, branch, commit with clear messages, and open a PR.
- Keep citations and provenance intact; include a brief rationale for changes.

## Ground Rules
- No speculative claims without citations.
- Preserve the Sovereign Header on public artifacts.
- Do not remove provenance lines; add to Lineage as needed.
