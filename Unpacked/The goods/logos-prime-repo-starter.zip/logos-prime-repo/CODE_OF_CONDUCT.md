# Code of Conduct

Be respectful, constructive, and citation-oriented. No harassment or bad-faith argumentation.
Violations may result in moderation actions and PR rejections.
