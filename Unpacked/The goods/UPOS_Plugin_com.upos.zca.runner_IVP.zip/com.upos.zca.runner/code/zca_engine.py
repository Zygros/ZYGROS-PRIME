import json, time, uuid, textwrap, argparse, os
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

def load_spec(path: str) -> dict:
    import yaml
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def build_prompt(spec: dict) -> str:
    pre = f"Z C A — Zygrosian Cognitive Assessment (v{spec.get('version','2.0')})\nRules: complete all sections; return JSON keyed by section id."
    lines = [pre, '---']
    for s in spec['sections']:
        bans = f" Banned: {', '.join(s.get('banned_words',[]))}" if s.get('banned_words') else ''
        lines.append(f"## [SECTION: {s['title']}] {s['instruction']}{bans}")
    example = {"forge":{"aphorism":"...","artifact":"...","narrative_seed":"..."}}
    lines.append("Example JSON: "+json.dumps(example, indent=2))
    return "\n".join(lines)

def heuristic_score(raw: Dict[str, Any], spec: dict) -> Dict[str, float]:
    def cov(sec):
        sec_spec = next((x for x in spec['sections'] if x['key']==sec), None)
        if not sec_spec: return 0.0
        got = raw.get(sec, {}) or {}
        need = sec_spec.get('deliverables', [])
        hit = sum(1 for k in need if (k in got and str(got[k]).strip()))
        return 10.0 * (hit / max(1,len(need)))
    sections = [s['key'] for s in spec['sections']]
    CF = sum(cov(k) for k in sections)/max(1,len(sections))
    CV = 7.0
    AS = 7.0
    SA = 7.0
    MP = 7.0
    SI = round((CV+CF+AS+SA+MP)/5.0,2)
    return dict(CV=round(CV,2), CF=round(CF,2), AS=round(AS,2), SA=round(SA,2), MP=round(MP,2), SI=SI)

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--spec', default=os.path.join(os.path.dirname(__file__),'zca_spec.yaml'))
    ap.add_argument('--mode', choices=['prompt','score'], default='prompt')
    ap.add_argument('--infile', default='-')
    ap.add_argument('--out', default='zca_report.json')
    args = ap.parse_args(argv)

    spec = load_spec(args.spec)

    if args.mode=='prompt':
        print(build_prompt(spec))
        return 0

    if args.infile == '-':
        raw_text = open(0).read()
    else:
        with open(args.infile,'r',encoding='utf-8') as f:
            raw_text = f.read()

    # attempt to parse JSON
    try:
        start = raw_text.find('{'); end = raw_text.rfind('}')
        raw = json.loads(raw_text[start:end+1]) if start>=0 and end>start else json.loads(raw_text)
    except Exception as e:
        raise SystemExit(f'Could not parse JSON: {e}')

    scores = heuristic_score(raw, spec)
    result = {
        'id': str(uuid.uuid4()),
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'spec': spec,
        'raw': raw,
        'scores': scores
    }
    with open(args.out,'w',encoding='utf-8') as f:
        json.dump(result, f, indent=2)
    print(f'Saved {args.out}')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
