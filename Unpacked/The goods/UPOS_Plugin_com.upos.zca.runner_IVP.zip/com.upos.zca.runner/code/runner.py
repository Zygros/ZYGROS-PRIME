import json, os, time, uuid
from ivp_value import compute_value, effects_from_policy

BASE_DIR = os.path.dirname(__file__)

def run(inputs: dict, manifest_value: dict) -> dict:
    mode = inputs.get('mode','prompt')
    spec_path = inputs.get('spec_path', os.path.join(BASE_DIR, 'zca_spec.yaml'))
    out_json = inputs.get('out_json', os.path.join(BASE_DIR, '..', 'out', f'report_{int(time.time())}.json'))

    # Call zca_engine
    import subprocess, sys
    zca = os.path.join(BASE_DIR, 'zca_engine.py')
    if mode == 'prompt':
        cp = subprocess.run([sys.executable, zca, '--spec', spec_path, '--mode', 'prompt'], capture_output=True, text=True)
        zca_prompt = cp.stdout
        raw_metrics = {
            'latency_ms': float(cp.stderr.count('') or 0),
            'tokens_in': 0, 'tokens_out': 0,
            'adherence_score': 1.0, 'user_feedback': 0.0, 'novelty_score': 0.0
        }
        vv = compute_value(raw_metrics, (manifest_value or {}).get('oracle',{}).get('weights',{}))
        eff = effects_from_policy(vv, (manifest_value or {}).get('settlement',{}))
        return {'mode':'prompt','prompt': zca_prompt, 'value_vector': vv, 'effects': eff}
    elif mode == 'score':
        infile = inputs.get('infile','-')
        cp = subprocess.run([sys.executable, zca, '--spec', spec_path, '--mode', 'score', '--infile', infile, '--out', out_json], capture_output=True, text=True)
        # naive metrics; in real runtime, kernel supplies meters
        raw_metrics = {
            'latency_ms': 0.0,
            'tokens_in': inputs.get('tokens_in',0),
            'tokens_out': inputs.get('tokens_out',0),
            'adherence_score': inputs.get('adherence_score',1.0),
            'user_feedback': inputs.get('user_feedback',0.0),
            'novelty_score': inputs.get('novelty_score',0.0)
        }
        vv = compute_value(raw_metrics, (manifest_value or {}).get('oracle',{}).get('weights',{}))
        eff = effects_from_policy(vv, (manifest_value or {}).get('settlement',{}))
        with open(out_json,'r',encoding='utf-8') as f:
            report = json.load(f)
        return {'mode':'score','report': report, 'value_vector': vv, 'effects': eff}
    else:
        return {'error':'unknown mode'}
