from math import exp
from typing import Dict, Any

AXES = ["learning","reputation","priority","delight","safety"]

def compute_value(raw: Dict[str, float], weights: Dict[str, Dict[str, float]]) -> Dict[str, float]:
    v = {k: 0.0 for k in AXES}
    # derived features
    tokens_saved_per_k = max(0.0, (raw.get("baseline_tokens_out",0)-raw.get("tokens_out",0))/1000.0)
    features = {
        "tokens_saved_per_k": tokens_saved_per_k,
        "latency_ms": float(raw.get("latency_ms", 0.0)),
        "adherence_score": float(raw.get("adherence_score", 0.0)),
        "user_feedback": float(raw.get("user_feedback", 0.0)),
        "novelty_score": float(raw.get("novelty_score", 0.0)),
        "watch_time_s": float(raw.get("watch_time_s", 0.0)),
        "policy_viol": float(raw.get("policy_viol", 0.0)),
    }
    for axis, fmap in (weights or {}).items():
        total = 0.0
        for feat, w in fmap.items():
            total += float(w) * float(features.get(feat, 0.0))
        v[axis] = total
    # clip to [-1, 1]
    for k in v:
        v[k] = max(-1.0, min(1.0, v[k]))
    return v

def roll_vector(prev: Dict[str,float], delta: Dict[str,float], dt_seconds: float, half_life_hours: float) -> Dict[str,float]:
    if not prev: prev = {k:0.0 for k in AXES}
    tau = max(1e-6, half_life_hours*3600.0)  # seconds
    decay = exp(-dt_seconds / tau)
    out = {}
    for k in AXES:
        out[k] = prev.get(k,0.0) * decay + delta.get(k,0.0)
        out[k] = max(-3.0, min(3.0, out[k]))  # wider clip for accumulated values
    return out

def effects_from_policy(v: Dict[str,float], policy: Dict[str,Any]) -> list:
    effs = []
    effects = (policy or {}).get("effects", {}) if policy else {}
    def over(th: Dict[str,float]) -> bool:
        return all(v.get(k,0.0) >= th.get(k,0.0) for k in th.keys())
    for name, rule in effects.items():
        th = rule.get("threshold", {})
        if over(th):
            effs.append(name)
    return effs
