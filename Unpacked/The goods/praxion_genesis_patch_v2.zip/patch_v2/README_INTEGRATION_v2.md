# Praxion ⇆ Genesis Integration Patch — v2
UTC: 2025-10-02T02:02:29.292851Z

- Parses `GPT_Prime_Command_Book.txt` → exposes `command_registry` and `active_role`.
- Applies soft locks at boot: `min_reasoning_depth=deep`, `enforce_mythic_state=True`.

**Verify** via GET /personas/current
