# SACC — Sovereign AI Command Console (Termux-friendly)

A visual, command-first console to coordinate your AI apps (ChatGPT, Gemini, Claude, Perplexity, Grok) from your Android phone (Termux).
It opens the apps via URLs, shows prebuilt Sovereign prompts, and lets you copy them to the clipboard with one key.

## Quick Start (Android / Termux)

```bash
# 1) Extract and enter
unzip SACC.zip -d SACC && cd SACC

# 2) Install dependencies (Rich + Prompt Toolkit + PyYAML, and termux-api tools)
bash install_termux.sh

# 3) Launch the console
python sacc.py
```

### Controls
- Arrow keys / j k: move
- Enter: select
- q: quit
- c: copy current prompt to clipboard (Termux clipboard)
- o: open selected app (via termux-open-url or xdg-open)
- s: save current prompt to `logs/` with timestamp

## Files
- `sacc.py` — Main TUI console
- `requirements.txt` — Python deps
- `install_termux.sh` — One-shot installer for Termux
- `config.yaml` — Configuration for links and behavior
- `bin/open_url.sh` — Helper to open URLs (Termux-aware)
- `prompts/*.txt` — Sovereign prompt templates per app
- `logs/` — Saved prompts and actions (autocreated)

## Notes
- Opening native apps relies on Android link handling. If the official app is installed, links should open there; otherwise they open in the browser.
- Clipboard needs Termux:API. The installer sets this up.
