#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

echo "[*] Updating packages..."
pkg update -y
pkg install -y python tsu termux-api coreutils

echo "[*] Upgrading pip and installing Python deps..."
python -m pip install --upgrade pip
pip install -r requirements.txt

echo "[*] Ensuring executable helpers..."
chmod +x bin/open_url.sh

echo "[*] Done. Launch with: python sacc.py"
