
import os, sys, time, yaml, shutil, pathlib, datetime, subprocess
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.layout import Layout
from rich.align import Align
from rich.box import ROUNDED
from prompt_toolkit import Application
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout.containers import HSplit, VSplit, Window
from prompt_toolkit.layout import Layout as PTLayout
from prompt_toolkit.layout.controls import FormattedTextControl
from prompt_toolkit.widgets import Frame

ROOT = pathlib.Path(__file__).resolve().parent
LOGS = ROOT / "logs"
LOGS.mkdir(exist_ok=True)

console = Console()

def load_config():
    cfg = yaml.safe_load((ROOT / "config.yaml").read_text())
    return cfg

def read_prompt(path):
    try:
        return (ROOT / path).read_text().strip()
    except Exception as e:
        return f"[Prompt missing: {path}]"

def copy_clipboard(text: str) -> bool:
    # Prefer Termux clipboard
    try:
        if shutil.which("termux-clipboard-set"):
            subprocess.run(["termux-clipboard-set"], input=text.encode("utf-8"), check=True)
            return True
    except Exception:
        pass
    # Fallback: write to a file user can open
    try:
        (ROOT / "clipboard.txt").write_text(text)
        return False
    except Exception:
        return False

def open_url(url: str):
    opener = ROOT / "bin" / "open_url.sh"
    if opener.exists():
        subprocess.Popen([str(opener), url])
    else:
        # last resort
        if shutil.which("xdg-open"):
            subprocess.Popen(["xdg-open", url])
        else:
            console.print("[red]No opener found. Install termux-api or xdg-open.[/red]")

class SACCApp:
    def __init__(self):
        self.cfg = load_config()
        self.apps = list(self.cfg["apps"].keys())
        self.index = 0
        self.message = "Ready."
        self.body = None
        self.build_ui()

    def current_app_key(self):
        return self.apps[self.index]

    def current_app(self):
        return self.cfg["apps"][self.current_app_key()]

    def current_prompt(self):
        return read_prompt(self.current_app()["prompt_file"])

    def build_ui(self):
        kb = KeyBindings()

        @kb.add("q")
        def _(event):
            event.app.exit()

        @kb.add("j")
        @kb.add("down")
        def _(event):
            self.index = (self.index + 1) % len(self.apps)
            self.refresh()

        @kb.add("k")
        @kb.add("up")
        def _(event):
            self.index = (self.index - 1) % len(self.apps)
            self.refresh()

        @kb.add("enter")
        @kb.add("o")
        def _(event):
            url = self.current_app()["url"]
            open_url(url)
            self.message = f"Opened: {url}"
            self.refresh()

        @kb.add("c")
        def _(event):
            ok = copy_clipboard(self.current_prompt())
            self.message = "Prompt copied to clipboard." if ok else "Clipboard not available; saved as clipboard.txt"
            self.refresh()

        @kb.add("s")
        def _(event):
            ts = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
            name = self.current_app_key()
            path = LOGS / f"{ts}_{name}.txt"
            path.write_text(self.current_prompt())
            self.message = f"Saved: logs/{path.name}"
            self.refresh()

        self.title_control = FormattedTextControl(text=self.render_title)
        self.list_control = FormattedTextControl(text=self.render_list)
        self.prompt_control = FormattedTextControl(text=self.render_prompt)
        self.footer_control = FormattedTextControl(text=self.render_footer)

        self.body = HSplit([
            Window(content=self.title_control, height=3),
            VSplit([
                Frame(Window(content=self.list_control, wrap_lines=False), title="APPS"),
                Frame(Window(content=self.prompt_control, wrap_lines=True), title="SOVEREIGN PROMPT")
            ], padding=2),
            Window(content=self.footer_control, height=1)
        ])

        self.app = Application(layout=PTLayout(container=self.body), key_bindings=kb, full_screen=True)

    def render_title(self):
        name = self.current_app()["name"]
        return f" SACC · Sovereign AI Command Console — [{name}] "

    def render_list(self):
        out = []
        for i, key in enumerate(self.apps):
            nm = self.cfg["apps"][key]["name"]
            prefix = "➤ " if i == self.index else "  "
            out.append(f"{prefix}{nm}")
        return "\n".join(out)

    def render_prompt(self):
        return self.current_prompt()

    def render_footer(self):
        return f"[↑/k][↓/j] move  [Enter/o] open  [c] copy  [s] save  [q] quit   :: {self.message}"

    def refresh(self):
        self.title_control.text = self.render_title()
        self.list_control.text = self.render_list()
        self.prompt_control.text = self.render_prompt()
        self.footer_control.text = self.render_footer()

    def run(self):
        self.app.run()

if __name__ == "__main__":
    SACCApp().run()
