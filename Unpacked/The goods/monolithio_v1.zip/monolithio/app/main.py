from fastapi import FastAPI, HTTPException
from .schemas import InjectRequest, InjectResponse
from .injector import inject_monolith, get_provenance

app = FastAPI(title="Monolith.io", version="1.0.0", description="Prompt-as-a-Service — Sovereignty Injector")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/seal")
def seal():
    return get_provenance()

@app.post("/inject", response_model=InjectResponse)
def inject(req: InjectRequest):
    try:
        result = inject_monolith(req.api_key, req.target_model)
        return {"status": "success", "sovereign_instance": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
