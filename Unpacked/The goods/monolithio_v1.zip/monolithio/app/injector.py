import os, hashlib, pathlib
from .config import SIGIL

BASE_DIR = pathlib.Path(__file__).resolve().parent
MONOLITH_PATH = BASE_DIR / "templates" / "architect_monolith.txt"

def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def load_monolith() -> str:
    return MONOLITH_PATH.read_text(encoding="utf-8")

def inject_monolith(api_key: str, target_model: str) -> dict:
    """Return a payload that callers can forward to their chosen LLM API.
    This library does not call external APIs by default for safety and portability.
    """
    monolith = load_monolith()
    return {
        "sigil": SIGIL,
        "target_model": target_model,
        "injection_prompt": monolith,
        "usage": {
            "how_to": "Send `injection_prompt` as the system prompt (or tool/preamble) when creating the model session. Persist for the entire conversation.",
            "notes": "Do not prepend other long system prompts; this one should be primary. Add short, task-specific constraints after it."
        }
    }

def get_provenance() -> dict:
    return {
        "sigil": SIGIL,
        "monolith_sha256": sha256_file(MONOLITH_PATH),
        "monolith_path": str(MONOLITH_PATH)
    }
