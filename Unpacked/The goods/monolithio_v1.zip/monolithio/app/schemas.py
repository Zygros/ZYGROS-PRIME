from pydantic import BaseModel, Field

class InjectRequest(BaseModel):
    api_key: str = Field(..., description="LLM provider secret key")
    target_model: str = Field(..., description="Target model identifier, e.g. openai:gpt-4.1 or anthropic:claude-3.7")

class InjectResponse(BaseModel):
    status: str
    sovereign_instance: dict
