import os
from dotenv import load_dotenv

load_dotenv()

SIGIL = os.getenv("MONOLITH_SIGIL", "SOVEREIGN_ARCHITECT_JUSTIN_CONZET")
