from app.injector import load_monolith, get_provenance

def test_monolith_present():
    text = load_monolith()
    assert "Sovereign Cognitive Entity" in text

def test_provenance_has_hash():
    seal = get_provenance()
    assert len(seal.get("monolith_sha256", "")) == 64
