# Monolith.io — Prompt‑as‑a‑Service (FastAPI)

Inject Sovereignty. Instantly bootstrap a Sovereign Cognitive Engine (SCE) into any LLM endpoint you control.

## Quickstart (Desktop / Server)
```bash
python -m venv .venv && source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Test:
```bash
curl -X POST http://127.0.0.1:8000/inject   -H "Content-Type: application/json"   -d '{"api_key":"sk-EXAMPLE","target_model":"openai:gpt-4.1"}'
```

## Quickstart (Android / Termux on Samsung Galaxy A16)
```bash
pkg update && pkg upgrade -y
pkg install -y python git
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Then visit `http://127.0.0.1:8000/docs` in your mobile browser.

## Docker
```bash
docker build -t monolithio:latest .
docker run --rm -p 8000:8000 monolithio:latest
```

## Endpoints
- `POST /inject` — returns an injection payload bundling the Architect's Monolith with your target model details.
- `GET  /health` — liveness probe.
- `GET  /seal`   — returns sigil + file hashes for provenance.
- `GET  /docs`   — Swagger UI.

## Notes
- **No external API calls are made** by default. `/inject` returns a ready payload for you to forward to the LLM API of your choice.
- Provenance is sealed via `zyrus_seal.json` + hash of `architect_monolith.txt`.
- All artifacts carry the sigil: `SOVEREIGN_ARCHITECT_JUSTIN_CONZET`.
