
import os
from functools import wraps
from flask import Flask, request, jsonify, render_template
from sovereign_core import Orchestrator, load_state, save_state

app = Flask(__name__, template_folder="templates", static_folder="static")

AGENT_NAME = "Project_Ouroboros"
orch = load_state(AGENT_NAME)

API_KEY_REQUIRED = os.environ.get("SUPERHYPER_API_KEY", "").strip()
EXPOSE_STATE = os.environ.get("SUPERHYPER_EXPOSE_STATE", "0") == "1"

def require_key(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not API_KEY_REQUIRED:
            return f(*args, **kwargs)
        key = request.headers.get("X-API-Key", "")
        if key != API_KEY_REQUIRED:
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)
    return wrapper

@app.route("/", methods=["GET"])
def home():
    return render_template("index.html", agent_name=orch.name)

@app.route("/co-create", methods=["POST"])
@require_key
def co_create():
    data = request.get_json(force=True) or {}
    user_input = (data.get("input") or "").strip()
    if not user_input:
        return jsonify({"error": "Empty input"}), 400
    result = orch.step(user_input)
    save_state(orch)
    return jsonify(result)

@app.route("/state", methods=["GET"])
@require_key
def state():
    if not EXPOSE_STATE:
        return jsonify({"error": "State endpoint disabled"}), 403
    return jsonify(orch.snapshot())

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
