
# SuperHyper Sovereign v2 (Planner→Solver→Critic)

An upgraded local-first scaffold that demonstrates **recursive cognition**, **ReAct-style tool use**, **Reflexion-style self-critique**, a **constitutional self-check**, and a tiny **multi-agent loop** (planner → solver → critic → commit).

## Quickstart (Android · Termux)

1) Install Termux (F-Droid preferred). In Termux:
```bash
pkg update -y && pkg install -y python clang git
pip install --upgrade pip
```
2) Unzip the project and run:
```bash
cd superhyper_v2
pip install -r requirements.txt
# optional security: export SUPERHYPER_API_KEY to require a key on requests
# export SUPERHYPER_API_KEY="your_key_here"
# optional: export SUPERHYPER_EXPOSE_STATE=1 to enable /state
python app.py
```
3) Open **http://127.0.0.1:5000** in your phone browser.
   - Try: `search: reflexion` or `search: local first`

## Security

- If `SUPERHYPER_API_KEY` is set, requests must include header `X-API-Key: <value>`.
- `/state` is disabled by default. Enable with `SUPERHYPER_EXPOSE_STATE=1` for debugging only.

## What’s new in v2

- **Reflexion**: The critic’s notes fold back into the committed memory.
- **ReAct**: If your input begins with `search:`, the solver executes a demo tool call.
- **Constitutional filter**: Adds light-touch annotations when text appears to violate principles.
- **Multi-agent loop**: Planner proposes, solver acts/thinks, critic evaluates; orchestrator commits.
- **Local-first**: All state stays in `sovereign_state.json` unless you choose to sync elsewhere.

## Extend it

- Replace `_tool_search` with your real tools (retrievers, local indexes, APIs).
- Store memories in SQLite or a vector DB; keep JSON as a daily export.
- Add more agents (router, safety, explainer) and let them debate one round before commit.
- Harden with auth, rate-limiters, and audit logs.
