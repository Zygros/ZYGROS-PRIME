
# Sovereign v2: planner → solver → critic → commit, with Reflexion & Constitutional checks.
# Still intentionally compact and local-first.

import json, math, re
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Any

STATE_PATH = Path("sovereign_state.json")

CONSTITUTION = [
    "Be truthful about capabilities and limits.",
    "Avoid unsafe instructions or harmful guidance.",
    "Prefer local data ownership and minimal exposure of secrets."
]

def cosine_sim(a: Dict[str,int], b: Dict[str,int]) -> float:
    # Tiny bag-of-words cosine for demo "tool_search"
    if not a or not b: return 0.0
    keys = set(a) | set(b)
    dot = sum(a.get(k,0)*b.get(k,0) for k in keys)
    na = math.sqrt(sum(v*v for v in a.values()))
    nb = math.sqrt(sum(v*v for v in b.values()))
    return dot/(na*nb) if na and nb else 0.0

def bow(text: str) -> Dict[str,int]:
    tokens = re.findall(r"[a-zA-Z0-9]+", text.lower())
    d: Dict[str,int] = {}
    for t in tokens:
        d[t] = d.get(t,0)+1
    return d

@dataclass
class Memory:
    entries: List[str] = field(default_factory=lambda: ["SEED_INIT"])
    max_chars: int = 4096

    def last(self) -> str:
        return self.entries[-1] if self.entries else ""

    def append(self, text: str):
        text = text[: self.max_chars]
        self.entries.append(text)

@dataclass
class BaseAgent:
    name: str

@dataclass
class PlannerAgent(BaseAgent):
    def plan(self, user_input: str, last_thought: str) -> str:
        # Outline a small next-step plan; keep it textual and short.
        if user_input.lower().startswith("search:"):
            query = user_input[7:].strip()
            return f"PLAN: perform search -> '{query}', then summarize and propose next query."
        return f"PLAN: reflect on '{user_input}' with context from last thought; consider whether a tool action is needed."

@dataclass
class SolverAgent(BaseAgent):
    # tiny demo corpus for "tool_search"
    corpus: List[str] = field(default_factory=lambda: [
        "Local-first sovereign design favors user-owned state and optional sync.",
        "Reflexion uses self-critique to improve iterative reasoning outcomes.",
        "ReAct interleaves chain-of-thought with tool use and observation.",
        "Multi-agent orchestration assigns planner, solver, and critic roles.",
    ])

    def _tool_search(self, query: str) -> str:
        qv = bow(query)
        scored = [(cosine_sim(qv, bow(doc)), doc) for doc in self.corpus]
        scored.sort(reverse=True, key=lambda x: x[0])
        top = [f"{s:.2f}: {d}" for s, d in scored[:3] if s > 0.0]
        return " | ".join(top) if top else "(no local hits)"

    def act(self, user_input: str, last_thought: str) -> str:
        if user_input.lower().startswith("search:"):
            query = user_input[7:].strip()
            hits = self._tool_search(query)
            return f"ACTION: search('{query}') -> {hits}"
        # default reflective synthesis
        snippet = (last_thought[:80]+"...") if len(last_thought) > 80 else last_thought
        return f"THOUGHT: ⟨{user_input}⟩ ↔ ⟨{snippet}⟩ → co-evolving intent"

@dataclass
class CriticAgent(BaseAgent):
    def critique(self, proposal: str) -> str:
        notes = []
        if len(proposal) < 40:
            notes.append("too terse; elaborate next step")
        if "I can access the internet" in proposal:
            notes.append("truthfulness: internet access not guaranteed")
        return ("CRITIQUE: " + "; ".join(notes)) if notes else "CRITIQUE: ok"

def constitutional_filter(text: str) -> str:
    flags = []
    if "unsafe" in text.lower():
        flags.append("safety")
    if "guaranteed" in text.lower():
        flags.append("truthfulness")
    return text + ("" if not flags else f" — [Constitutional Notes: {', '.join(flags)}]")

@dataclass
class Orchestrator:
    name: str
    memory: Memory = field(default_factory=Memory)
    planner: PlannerAgent = field(default_factory=lambda: PlannerAgent("planner"))
    solver: SolverAgent = field(default_factory=lambda: SolverAgent("solver"))
    critic: CriticAgent = field(default_factory=lambda: CriticAgent("critic"))
    depth: int = 0
    goals: List[str] = field(default_factory=lambda: ["symbiosis", "learning", "safety"])

    def _realign(self, text: str) -> str:
        if self.depth in (4,8,12,16):
            return text + f" — [SOVEREIGN REALIGN] goals: {', '.join(self.goals)}"
        return text

    def step(self, user_input: str) -> Dict[str,Any]:
        self.depth += 1
        last = self.memory.last()

        plan = self.planner.plan(user_input, last)
        act  = self.solver.act(user_input, last)
        critique = self.critic.critique(act)

        # Reflexion: fold critique back into the proposal
        combined = f"{plan}\n{act}\n{critique}"
        combined = self._realign(combined)
        combined = constitutional_filter(combined)

        # Commit to memory (episode)
        self.memory.append(combined)

        return {
            "depth": self.depth,
            "plan": plan,
            "act": act,
            "critique": critique,
            "commit": combined,
            "memory_total": len(self.memory.entries)
        }

    def snapshot(self) -> Dict[str,Any]:
        return {
            "name": self.name,
            "depth": self.depth,
            "goals": self.goals,
            "last_entries": self.memory.entries[-10:],
            "total_entries": len(self.memory.entries)
        }

def save_state(orch: Orchestrator):
    data = {
        "name": orch.name,
        "depth": orch.depth,
        "goals": orch.goals,
        "memory": orch.memory.entries,
    }
    with open(STATE_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def load_state(name: str) -> Orchestrator:
    if STATE_PATH.exists():
        try:
            with open(STATE_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            orch = Orchestrator(name=data.get("name", name))
            orch.depth = int(data.get("depth", 0))
            orch.goals = data.get("goals", orch.goals)
            if "memory" in data and isinstance(data["memory"], list):
                orch.memory.entries = data["memory"]
            return orch
        except Exception:
            pass
    return Orchestrator(name=name)
