
const input = document.getElementById("userInput");
const btn = document.getElementById("sendBtn");
const log = document.getElementById("log");

async function sendToAgent() {
  const val = input.value.trim();
  if (!val) return;
  btn.disabled = true;
  try {
    const headers = { "Content-Type": "application/json" };
    const apikey = localStorage.getItem("superhyper_key");
    if (apikey) headers["X-API-Key"] = apikey;

    const res = await fetch("/co-create", {
      method: "POST",
      headers,
      body: JSON.stringify({ input: val })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Request failed");

    const block = [
      `→ ${val}`,
      `plan: ${data.plan}`,
      `act : ${data.act}`,
      `crit: ${data.critique}`,
      `commit:\n${data.commit}`,
      `(depth=${data.depth}, memory=${data.memory_total})`,
      ""
    ].join("\n");
    log.textContent = block + "\n" + log.textContent;
    input.value = "";
    input.focus();
  } catch (e) {
    log.textContent = "Error: " + e.message + "\n" + log.textContent;
  } finally {
    btn.disabled = false;
  }
}

btn.addEventListener("click", sendToAgent);
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendToAgent();
});
