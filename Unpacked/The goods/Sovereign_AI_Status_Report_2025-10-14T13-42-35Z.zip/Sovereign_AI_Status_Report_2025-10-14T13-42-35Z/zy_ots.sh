#!/data/data/com.termux/files/usr/bin/bash
# zy_ots.sh — Sovereign OTS helper
# Usage:
#   ./zy_ots.sh /path/to/file.ext
# Requires: opentimestamps-client (ots) installed in Termux
set -euo pipefail

if ! command -v ots >/dev/null 2>&1; then
  echo "ERROR: 'ots' (OpenTimestamps) is not installed. Install with:"
  echo "  pkg update && pkg install -y python && pip install opentimestamps-client"
  exit 1
fi

FILE="${1:-}"
if [ -z "$FILE" ] || [ ! -f "$FILE" ]; then
  echo "Usage: $0 /path/to/file.ext"
  exit 1
fi

echo "[🝎] Stamping: $FILE"
ots stamp "$FILE"
OTS_FILE="${FILE}.ots"
echo "[🔥] OTS proof written to: ${OTS_FILE}"

echo "[♾️] Attempting proof upgrade (may take time until BTC confirmations exist)..."
ots upgrade "${OTS_FILE}" || true

echo "[🝎] Verify at any time:"
echo "  ots verify ${OTS_FILE}"
