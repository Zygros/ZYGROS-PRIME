CSI System Manifest — Surprise Edition
(Complete field manual as generated in the editor)
