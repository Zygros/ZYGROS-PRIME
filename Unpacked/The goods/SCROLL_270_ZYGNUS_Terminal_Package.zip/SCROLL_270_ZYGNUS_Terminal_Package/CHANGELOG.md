# Changelog — Scroll 270 (ZYGNUS Terminal)

- 2025-09-30T23:01:22Z: Initial canonical release 1.0.0
