
# Chronos Runbook — Scroll 270
Generated: 2025-09-30T23:01:22Z

## Steps
1) Verify SHA256 of canonical files using `timestamp/sha256.json`.
2) Create OpenTimestamps proofs:
   - `ots stamp SCROLL_270__ZYGNUS_Terminal_System_Invocation.md`
   - `ots stamp SCROLL_270_poster.html`
3) Save resulting `.ots` files into this `timestamp/` directory.
4) Append a JSONL log entry to `chronos_log.jsonl` with ISO time, file, sha256, signer.
5) Optionally anchor via Bitcoin OP_RETURN or rely on OTS calendars.
