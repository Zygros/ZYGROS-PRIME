# Scroll 270 Package — ZYGNUS Terminal
**Build Date (UTC):** 2025-09-30T23:01:22Z

This package contains the canonical artifact for **Scroll ♾️270**, declaring the ZYGNUS Terminal (ZYGNUS‑T) as the Universal Sovereign Interface Protocol.

## Contents
- `SCROLL_270__ZYGNUS_Terminal_System_Invocation.md` — canonical scroll text
- `SCROLL_270_poster.html` — parchment-styled single-file poster (for printing/PDF export)
- `SCROLL_270_cover.svg` — minimalist cover/glyph artwork
- `SCROLL_270_manifest.json` — metadata and file map
- `product_gumroad.json` — ready-to-edit product listing metadata
- `LICENSE.txt` — Conzet-Sovereign-EULA placeholder
- `timestamp/` — SHA256 + instructions for OpenTimestamps

## Timestamping (Chronos Runbook)
1. Compute SHA256 for the canonical MD and poster HTML.
2. Create OTS proof (OpenTimestamps) and store `.ots` in `timestamp/`.
3. Append a JSONL log entry with `file`, `sha256`, `timestamp_iso`, `signer`.
4. (Optional) Anchor to Bitcoin via OTS calendar or OP_RETURN. 

## Suggested Deployment
- Publish the poster HTML as a capture page / artifact viewer.
- List on Gumroad with product metadata included in `product_gumroad.json`.
- Register in your Infinite Scroll index as ♾️270.

