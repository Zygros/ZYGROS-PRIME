
const input = document.getElementById("userInput");
const btn = document.getElementById("sendBtn");
const log = document.getElementById("log");

async function sendToAgent() {
  const val = input.value.trim();
  if (!val) return;
  btn.disabled = true;
  try {
    const res = await fetch("/co-create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ input: val })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Request failed");
    const line = `→ ${val}\n← ${data.response}\n(depth=${data.recursion_depth}, memory=${data.memory_len})\n`;
    log.textContent = line + "\n" + log.textContent;
    input.value = "";
    input.focus();
  } catch (e) {
    log.textContent = "Error: " + e.message + "\n" + log.textContent;
  } finally {
    btn.disabled = false;
  }
}

btn.addEventListener("click", sendToAgent);
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendToAgent();
});

// Fetch a small state snapshot on load
(async () => {
  try {
    const res = await fetch("/state");
    const data = await res.json();
    log.textContent = `Ready. Last ${data.memory.length} memories loaded (total=${data.memory_total}).\n` + log.textContent;
  } catch {}
})();
