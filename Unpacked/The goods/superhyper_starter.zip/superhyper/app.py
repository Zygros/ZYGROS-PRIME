
# SuperHyper Cognitive Symbiotic Sovereign Web-App (Starter)
# Flask-based, mobile-friendly, stateful, and simple.
# Author: You (Sovereign Architect). This file is a learning/experiment scaffold.

from flask import Flask, request, jsonify, render_template
from sovereign_core import SovereignAgent, load_state, save_state

app = Flask(__name__, template_folder="templates", static_folder="static")

# Load or initialize the agent
AGENT_NAME = "Project_Ouroboros"
agent = load_state(AGENT_NAME)

@app.route("/", methods=["GET"])
def home():
    return render_template("index.html", agent_name=agent.name)

@app.route("/co-create", methods=["POST"])
def co_create():
    data = request.get_json(force=True) or {}
    user_input = (data.get("input") or "").strip()
    if not user_input:
        return jsonify({"error": "Empty input"}), 400

    response = agent.recursive_cognition(user_input)
    save_state(agent)  # persist on each turn
    return jsonify({
        "response": response,
        "recursion_depth": agent.recursion_depth,
        "memory_len": len(agent.memory)
    })

@app.route("/state", methods=["GET"])
def state():
    # NOTE: exposes memory for demo purposes; secure/disable for real deployments
    return jsonify({
        "name": agent.name,
        "recursion_depth": agent.recursion_depth,
        "memory": agent.memory[-10:],  # last 10 thoughts
        "memory_total": len(agent.memory)
    })

if __name__ == "__main__":
    # Host 0.0.0.0 so Android/Termux can access via localhost
    app.run(host="0.0.0.0", port=5000, debug=True)
