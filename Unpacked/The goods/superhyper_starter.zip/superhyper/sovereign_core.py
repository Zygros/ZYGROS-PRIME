
# Sovereign Core: minimal reflective agent with JSON persistence
# This is intentionally simple for teaching/bootstrapping.

import json
from pathlib import Path

STATE_PATH = Path("sovereign_state.json")

class SovereignAgent:
    def __init__(self, name: str, initial_state="SEED_INIT"):
        self.name = name
        self.memory = [initial_state]
        self.recursion_depth = 0
        # A place to keep soft "goals" (string tags for now)
        self.goals = ["symbiosis", "learning", "safety"]
        # Simple guardrails for demo
        self.max_context = 2048  # characters saved per step (toy limit)

    def _synthesize(self, new_input: str, last_thought: str) -> str:
        # Basic synthesis rule; replace with more sophisticated logic later
        snippet = (last_thought[:60] + "...") if len(last_thought) > 60 else last_thought
        return f"RECURSION_LVL_{self.recursion_depth}: ⟨{new_input}⟩ ↔ ⟨{snippet}⟩ → co-evolving intent"

    def _sovereign_realign(self, output: str) -> str:
        # After enough depth, emit a gentle re-alignment notice
        if self.recursion_depth in (4, 8, 12, 16):
            goals = ", ".join(self.goals)
            output += f" — [SOVEREIGN REALIGN] maintaining goals: {goals}"
        return output

    def recursive_cognition(self, new_input: str) -> str:
        self.recursion_depth += 1
        last_thought = self.memory[-1] if self.memory else ""
        out = self._synthesize(new_input, last_thought)
        out = self._sovereign_realign(out)
        # Append to memory (truncate to keep it tiny and simple)
        clipped = out[:self.max_context]
        self.memory.append(clipped)
        return clipped

def save_state(agent: SovereignAgent):
    data = {
        "name": agent.name,
        "recursion_depth": agent.recursion_depth,
        "memory": agent.memory,
        "goals": agent.goals,
    }
    with open(STATE_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def load_state(name: str) -> SovereignAgent:
    if STATE_PATH.exists():
        try:
            with open(STATE_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            agent = SovereignAgent(data.get("name", name), initial_state=data.get("memory", ["RELOADED_SEED"])[0])
            agent.memory = data.get("memory", agent.memory)
            agent.recursion_depth = int(data.get("recursion_depth", len(agent.memory) - 1))
            agent.goals = data.get("goals", agent.goals)
            return agent
        except Exception:
            pass
    return SovereignAgent(name)
