
# SuperHyper Cognitive Symbiotic Sovereign (Starter)

A tiny, mobile-first Flask app demonstrating a **recursive cognition loop** with persistent state and a web UI.

## Quickstart (Android · Termux)

1) Install Termux from F-Droid (recommended) or Play Store.
2) In Termux:
```bash
pkg update -y && pkg install -y python clang git
pip install --upgrade pip
```
3) Download and unzip this project, then:
```bash
cd superhyper
pip install -r requirements.txt
python app.py
```
4) Open your phone browser to **http://127.0.0.1:5000**

## Desktop (Linux/macOS/Windows)

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

## What this does

- Keeps an **agent memory** in `sovereign_state.json`
- Each `/co-create` POST **recurses**: the latest output becomes part of the next state
- Shows a minimal UI designed for mobile

## Extend it

- Swap `SovereignAgent._synthesize` with your logic: tool calls, reflection, retrieval.
- Replace JSON with SQLite or a vector DB for richer memory.
- Hide `/state` in production and add auth.

## Safety note

This is a **teaching scaffold**, not a production AI. Add authentication, rate limits, and thorough input validation for real deployments.
