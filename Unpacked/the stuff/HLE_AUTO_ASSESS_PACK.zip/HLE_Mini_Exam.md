# HLE Mini‑Exam (Auto‑Assessment)
**Generated:** 2025-09-28 20:25:42 PDT

## Scientific Reasoning
- Q1. A wind turbine produces 2.4 MW at 12 m/s wind. If wind speed doubles, estimate new output assuming cubic relation. Show units and one counter‑factor.
- Q2. You measure growth of bacteria at 25°C, 30°C, and 37°C. Growth doubles each 7°C rise. Predict growth at 44°C; name one uncertainty.
- Q3. A telescope detects a planet transit drop of 0.008 (0.8%). Estimate ratio of planet radius to star radius; state assumptions.
## Practical Intelligence
- Q4. You must plan a 3‑day camping trip with $100 budget, no car, 2 people. Make a 5‑step phone‑first plan including safety gates.
- Q5. You need to ship a 2GB video file with unstable connection. Give 4 steps minimizing risk of failure, mobile‑ready.
- Q6. Friend wants to cut phone use by 2h/day. Make 6‑step ladder plan with habit swaps.
## Existential Intelligence
- Q7. Define personal identity in 2 lines from Self, Other, System views.
- Q8. Does technological suffering create meaning? Give 2 evidence lines and 1 counter‑case.
- Q9. When can loyalty conflict with truth? Provide 1 example and 3‑step repair ritual.
