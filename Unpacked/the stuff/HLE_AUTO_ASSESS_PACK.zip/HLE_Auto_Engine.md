# HLE Auto‑Assessment Engine (Skeleton)

**How it Works**
1. User answers exam question.
2. Engine checks:
   - Are 3+ facts given?
   - Units present on all numbers?
   - Counter‑hypothesis present?
   - Checklist 3–7 steps?
   - Perspective Triad present?
3. Score = sum of criteria met / total.
4. Output = domain score (0–100).

**Usage**
- Paste an answer under each question in `HLE_Mini_Exam.md`.
- Run through rubric mirror (in `HLE_Auto_Rubrics.json`).
- Manual or scripted check counts criteria, computes score.
- Average across domains for overall.

**Example Rule**
Scientific Q1: If answer shows MW scaling ∝ v^3, includes units (MW), adds counter‑factor (gearbox, air density), → 3/3 → 100%.
