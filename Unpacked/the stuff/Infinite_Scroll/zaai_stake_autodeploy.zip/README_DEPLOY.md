# ZAAI Stake Auto-Deploy (One Command)

## Deploy
1) Install Docker + Docker Compose.
2) Unzip this folder.
3) (Optional) Edit `.env` — your Stake URL is already set. Leave ENABLE_ENGINE=false for now.
4) Run:
   docker compose up -d

- The landing site is now live at http://localhost:8080 (or your server's IP:8080).
- To enable the outreach engine later, set ENABLE_ENGINE=true in `.env` and `docker compose up -d engine`.

## Files
- site/ -> static landing page that links directly to your Stake referral
- engine/ -> Conzet Auto-Traffic Engine (messages include Stake templates)
- .env -> already contains PAYMENT_URL=https://stake.us/?c=1WinataTime

## Stop
   docker compose down

## Update
   docker compose build --no-cache && docker compose up -d
