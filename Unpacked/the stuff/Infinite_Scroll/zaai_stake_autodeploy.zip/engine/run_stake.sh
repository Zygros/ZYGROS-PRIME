#!/usr/bin/env bash
set -euo pipefail

if [ ! -f ".env" ]; then
  echo "Missing .env. Copy .env.example to .env and fill credentials."
  exit 1
fi

# Replace the message path by passing --template
python3 scripts/scheduler.py --send hook --template messages/stake_hook.txt --subject "Your Stake invite is live"
sleep 2
echo "For follow-ups:"
echo "python3 scripts/scheduler.py --send followup --template messages/stake_followup.txt --subject 'Reminder — bonus is waiting'"
echo "python3 scripts/scheduler.py --send last_call --template messages/stake_last_call.txt --subject 'LAST CALL — bonus ends soon'"
