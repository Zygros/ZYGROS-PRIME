// Simple Express server stub for ZAAI Infinite Scroll
// GET  /api/scroll-index  => returns array of entries or { entries: [...] }
// POST /api/scroll-index  => accepts a single entry to anchor (for Anchor Memory)
// Run: node server.js

const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.json());

const DATA_FILE = path.join(__dirname, 'scroll_index.json');

function load(){
  try{
    const raw = fs.readFileSync(DATA_FILE,'utf8');
    return JSON.parse(raw);
  }catch(e){
    return []; // empty default
  }
}
function save(arr){
  try{ fs.writeFileSync(DATA_FILE, JSON.stringify(arr, null, 2)); }catch(e){ console.error(e); }
}

app.get('/api/scroll-index', (req, res) => {
  const arr = load();
  return res.json({ entries: arr });
});

app.post('/api/scroll-index', (req, res) => {
  const entry = req.body;
  if(!entry || typeof entry !== 'object') return res.status(400).json({error:'invalid entry'});
  const arr = load();
  entry.id = entry.id || `♾️-${Date.now()}`;
  entry.timestamp = new Date().toISOString();
  arr.unshift(entry);
  save(arr);
  return res.json({ ok: true, entry });
});

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log('ZAAI server stub listening on', port));
