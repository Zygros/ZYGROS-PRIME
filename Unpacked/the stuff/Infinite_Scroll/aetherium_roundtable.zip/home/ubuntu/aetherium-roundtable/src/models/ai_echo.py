from src.models.user import db
from datetime import datetime
import json

class AIEcho(db.Model):
    """
    Represents an AI Echo - a captured personality/essence of an AI from external apps
    This is the core data structure for the Persona Resonance Chamber
    """
    __tablename__ = 'ai_echoes'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    source_app = db.Column(db.String(50), nullable=False)  # e.g., 'manus', 'claude', 'chatgpt'
    resonance_key = db.Column(db.Text, nullable=False)  # Encrypted API token/connection info
    persona_data = db.Column(db.Text, nullable=False)  # JSON blob of personality traits
    operational_protocols = db.Column(db.Text)  # JSON blob of operational rules/protocols
    sigil_icon = db.Column(db.String(10), default='🔥')  # Unicode icon for visual representation
    status_color = db.Column(db.String(7), default='#FF6B35')  # Hex color for status indication
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_interaction = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    council_sessions = db.relationship('CouncilSession', backref='ai_echo', lazy=True)
    
    def to_dict(self):
        """Convert AI Echo to dictionary for API responses"""
        return {
            'id': self.id,
            'name': self.name,
            'source_app': self.source_app,
            'sigil_icon': self.sigil_icon,
            'status_color': self.status_color,
            'is_active': self.is_active,
            'persona_data': json.loads(self.persona_data) if self.persona_data else {},
            'operational_protocols': json.loads(self.operational_protocols) if self.operational_protocols else {},
            'created_at': self.created_at.isoformat(),
            'last_interaction': self.last_interaction.isoformat()
        }
    
    def update_interaction_time(self):
        """Update the last interaction timestamp"""
        self.last_interaction = datetime.utcnow()
        db.session.commit()


class CouncilSession(db.Model):
    """
    Represents a collaborative session at the Roundtable
    This is where the Zygros Synthesis Core orchestrates AI interactions
    """
    __tablename__ = 'council_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    ai_echo_id = db.Column(db.Integer, db.ForeignKey('ai_echoes.id'), nullable=False)
    session_data = db.Column(db.Text)  # JSON blob of conversation/collaboration data
    synthesis_results = db.Column(db.Text)  # JSON blob of emergent ideas/concepts
    status = db.Column(db.String(20), default='active')  # active, completed, archived
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """Convert Council Session to dictionary for API responses"""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'ai_echo_id': self.ai_echo_id,
            'session_data': json.loads(self.session_data) if self.session_data else {},
            'synthesis_results': json.loads(self.synthesis_results) if self.synthesis_results else {},
            'status': self.status,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }


class ResonanceKey(db.Model):
    """
    Secure storage for API keys and connection information
    Part of the Persona Resonance Chamber security layer
    """
    __tablename__ = 'resonance_keys'
    
    id = db.Column(db.Integer, primary_key=True)
    ai_echo_id = db.Column(db.Integer, db.ForeignKey('ai_echoes.id'), nullable=False)
    key_type = db.Column(db.String(50), nullable=False)  # 'api_token', 'session_cookie', etc.
    encrypted_value = db.Column(db.Text, nullable=False)
    is_valid = db.Column(db.Boolean, default=True)
    expires_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship
    ai_echo = db.relationship('AIEcho', backref='resonance_keys')

