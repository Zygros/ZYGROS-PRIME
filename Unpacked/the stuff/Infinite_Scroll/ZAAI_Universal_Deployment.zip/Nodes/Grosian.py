# Grosian Node Executor
class Node:
    def bind_codex(self, codex): pass
    def bind_glyphs(self, glyphs): pass
