# Perplexity Node Navigator
class Node: pass
