# DrawCNX Node Visualization Engine
class Node:
    @staticmethod
    def render_scrolls(): pass
