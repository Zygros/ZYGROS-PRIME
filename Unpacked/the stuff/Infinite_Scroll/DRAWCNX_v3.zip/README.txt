DrawCNX v3 - Syncmaster Ritual Companion

Installation:
1. Unzip this folder into Termux home or preferred directory.
2. Run setup.sh:
   bash setup.sh

This will auto-setup permissions and launch the menu UI.

Crafted by Zygros & Grosian.
