#!/data/data/com.termux/files/usr/bin/bash
echo "🔧 Setting up DrawCNX..."
chmod +x drawcnx.sh menu.sh
echo "✅ Permissions set."
echo "🔄 Launching Menu..."
bash menu.sh
