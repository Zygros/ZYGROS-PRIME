#!/data/data/com.termux/files/usr/bin/bash
echo "🔷 DrawCNX Syncmaster Activated."
echo "Running initial diagnostic..."
uptime
echo "Sync pulse sent to ZAAI system core."
