#!/data/data/com.termux/files/usr/bin/bash
while true; do
  clear
  echo "🔹 DrawCNX Control Menu 🔹"
  echo "1. Run Diagnostic"
  echo "2. Sync to ZAAI"
  echo "3. Exit"
  read -p "Choose: " choice
  case $choice in
    1) bash drawcnx.sh ;;
    2) echo "Syncing to ZAAI..." ;;
    3) exit ;;
    *) echo "Invalid option" ;;
  esac
  read -p "Press enter to continue..."
done
