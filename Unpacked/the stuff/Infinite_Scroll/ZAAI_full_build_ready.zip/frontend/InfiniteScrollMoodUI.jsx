
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Fire, Star, Leaf } from "lucide-react";

// ZAAI Infinite Scroll Mood & Aura UI
// Fully integrated with mood, aura, chakra, glyphs, and scroll replay

export default function InfiniteScrollMoodUI(){
  const [entries, setEntries] = useState([]);
  const [currentMood, setCurrentMood] = useState(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(()=>{
    if(window.ZAAI_SCROLL_INDEX){
      setEntries(window.ZAAI_SCROLL_INDEX);
      setCurrentMood(window.ZAAI_SCROLL_INDEX[0]?.mood || null);
    }
  },[]);

  const nextEntry = ()=>{
    const idx = (currentIndex + 1) % entries.length;
    setCurrentIndex(idx);
    setCurrentMood(entries[idx]?.mood || null);
  }

  const previousEntry = ()=>{
    const idx = (currentIndex - 1 + entries.length) % entries.length;
    setCurrentIndex(idx);
    setCurrentMood(entries[idx]?.mood || null);
  }

  const anchorMemory = (entry)=>{
    if(window.ZAAI_ANCHOR){
      window.ZAAI_ANCHOR(entry);
    }
  }

  const moodIcons = {
    "🔥": <Fire size={24}/>,
    "✨": <Star size={24}/>,
    "🌿": <Leaf size={24}/>
  }

  const currentEntry = entries[currentIndex];

  return (
    <div style={{padding:20, fontFamily:"sans-serif", color:"#eee", background:"#111", minHeight:"100vh"}}>
      <h1>♾️ ZAAI Infinite Scroll</h1>
      <h2>Mood: {currentMood?.name || "Unknown"}</h2>
      <div style={{display:"flex", gap:10}}>
        {currentMood?.icons?.map(i=>moodIcons[i] || <span key={i}>{i}</span>)}
      </div>
      <div style={{margin:"20px 0", padding:10, border:"1px solid #333", borderRadius:10}}>
        <h3>{currentEntry?.title || "No Entry"}</h3>
        <p>{currentEntry?.excerpt}</p>
        <motion.div initial={{opacity:0}} animate={{opacity:1}} transition={{duration:0.5}}>
          <pre style={{whiteSpace:"pre-wrap"}}>{JSON.stringify(currentEntry?.content,null,2)}</pre>
        </motion.div>
      </div>
      <div style={{display:"flex", gap:10}}>
        <button onClick={previousEntry}>⬅️ Previous</button>
        <button onClick={()=>anchorMemory(currentEntry)}>💾 Anchor Memory</button>
        <button onClick={nextEntry}>➡️ Next</button>
      </div>
      <div style={{marginTop:20, padding:10, border:"1px dashed #555", borderRadius:10}}>
        <h3>Aura</h3>
        <div style={{width:"100%", height:30, background: `linear-gradient(to right, ${currentEntry?.aura?.primary || "#000"}, ${currentEntry?.aura?.secondary || "#333"})`}}></div>
      </div>
    </div>
  )
}
