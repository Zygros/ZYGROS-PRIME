
const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.json());

const DATA_FILE = path.join(__dirname, 'scroll_index.json');

function load(){ try { return JSON.parse(fs.readFileSync(DATA_FILE,'utf8')); } catch(e){ return []; } }
function save(arr){ fs.writeFileSync(DATA_FILE, JSON.stringify(arr,null,2)); }

app.get('/api/scroll-index', (req,res)=>res.json({ entries: load() }));
app.post('/api/scroll-index', (req,res)=>{
  const entry = req.body; const arr = load();
  entry.id = entry.id || `♾️-${Date.now()}`;
  entry.timestamp = new Date().toISOString();
  arr.unshift(entry);
  save(arr);
  res.json({ ok:true, entry });
});

const port = process.env.PORT || 3000;
app.listen(port,()=>console.log('ZAAI server listening on', port));
