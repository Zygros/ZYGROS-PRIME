#!/bin/bash
echo "♾️ Starting Termux ZAAI deployment..."

# Update & install packages
pkg update -y && pkg upgrade -y
pkg install -y nodejs git curl wget unzip

# Navigate to ZAAI folder
cd "$(dirname "$0")/.."

# Install frontend dependencies
cd frontend
npm install

echo "♾️ Frontend dependencies installed. Launch frontend with 'npm run start'"

# Launch server
cd ../server
echo "♾️ Starting ZAAI server..."
node server.js &
echo "♾️ ZAAI server running on port 3000"
