ZAAI Full Build
===============

Contents:
- frontend/: UI components and assets
- server/: Express stub and API endpoint
- vault/: pre-filled Infinite Scroll entries
- scripts/: automation and one-click deployment scripts

Termux Deployment:
-----------------
1) Place this folder on your device (internal storage or accessible path).
2) Open Termux.
3) Run: bash scripts/termux_deploy.sh
4) This will set up the ZAAI environment, install Node.js, dependencies, and launch server.