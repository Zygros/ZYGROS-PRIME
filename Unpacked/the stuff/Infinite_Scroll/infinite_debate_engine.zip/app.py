from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import os

db = SQLAlchemy()
migrate = Migrate()

def create_app():
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv("DATABASE_URI", "sqlite:///infinite_debate.db")
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    migrate.init_app(app, db)

    from models import Persona, DebateEntry, ScrollRecord

    from debate_1 import debate_bp
    from terminal import terminal_bp

    app.register_blueprint(debate_bp, url_prefix="/api")
    app.register_blueprint(terminal_bp, url_prefix="/terminal")

    @app.route("/")
    def index():
        return render_template("index.html")

    return app

if __name__ == "__main__":
    create_app().run(debug=True, host="0.0.0.0", port=5000)
