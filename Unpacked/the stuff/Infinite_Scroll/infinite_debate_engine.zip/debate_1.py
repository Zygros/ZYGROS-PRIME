from flask import Blueprint, jsonify, request
from app import db
from debate import create_persona, add_debate_entry, synthesize_debate
from models import Persona, DebateEntry

debate_bp = Blueprint("debate", __name__)

@debate_bp.route("/personas/initialize", methods=["POST"])
def initialize_personas():
    data = request.get_json() or {}
    names = data.get("names", ["Omega Grosian", "Gemini", "Grok", "Perplexity"])
    created = []
    for n in names:
        p = create_persona(n)
        created.append({"id": p.id, "name": p.name})
    return jsonify({"created": created}), 201

@debate_bp.route("/debates", methods=["POST"])
def post_entry():
    data = request.get_json()
    persona_id = data.get("persona_id")
    content = data.get("content")
    if not content:
        return jsonify({"error": "content required"}), 400
    e = add_debate_entry(persona_id, content, metadata=data.get("metadata"))
    return jsonify({"id": e.id, "created_at": e.created_at.isoformat()}), 201

@debate_bp.route("/synthesize", methods=["GET"])
def synthesize():
    limit = int(request.args.get("limit", 10))
    out = synthesize_debate(limit)
    return jsonify(out)
