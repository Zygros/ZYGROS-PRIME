from flask import Blueprint, request, jsonify
import os

terminal_bp = Blueprint("terminal", __name__)

@terminal_bp.route("/", methods=["POST"])
def run_command():
    payload = request.get_json() or {}
    command = payload.get("command")
    args = payload.get("args", {})
    if not command:
        return jsonify({"error": "command required"}), 400

    if command == "create_file":
        filename = args.get("filename")
        content = args.get("content", "")
        if not filename:
            return jsonify({"error": "filename required"}), 400
        sandbox_dir = os.path.abspath("sandbox")
        os.makedirs(sandbox_dir, exist_ok=True)
        path = os.path.join(sandbox_dir, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return jsonify({"status": "ok", "path": path}), 201

    elif command == "list_sandbox":
        sandbox_dir = os.path.abspath("sandbox")
        os.makedirs(sandbox_dir, exist_ok=True)
        files = os.listdir(sandbox_dir)
        return jsonify({"files": files}), 200

    else:
        return jsonify({"error": "unknown command"}), 400
