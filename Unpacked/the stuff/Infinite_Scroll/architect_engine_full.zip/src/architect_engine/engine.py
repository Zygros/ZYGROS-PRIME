
import json, os, re, textwrap, random

def load_lexicon():
    here = os.path.dirname(__file__)
    with open(os.path.join(here, "lexicon.json"), "r", encoding="utf-8") as f:
        data = json.load(f)
    out = {}
    for item in data:
        key = item["key"].strip()
        if not key.startswith("!"):
            key = "!" + key
        out[key] = {"title": item.get("title") or key, "desc": item.get("desc","")}
    return out

def list_modes(lex=None):
    lex = lex or load_lexicon()
    return sorted(lex.keys())

def describe(mode, lex=None):
    lex = lex or load_lexicon()
    if not mode.startswith("!"):
        mode = "!" + mode
    if mode not in lex:
        raise KeyError(f"Unknown mode: {mode}")
    meta = lex[mode]
    return f"{mode} — {meta['title']}\n{meta['desc']}"

def _skeleton(text):
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    bullets = []
    for ln in lines:
        words = [w for w in re.findall(r"[A-Za-z0-9_'-]+", ln) if len(w) > 3]
        if words:
            bullets.append("- " + " ".join(words[:8]))
    return "\n".join(bullets) or text

def _kafka(text):
    frame = [
        "FORM 27-B/Ω: Notification of Preliminary Noncompliance",
        "Annex III: Confirmation of Receipt (Unreceivable)",
        "Circular 9: Instruction for Correcting the Correction"
    ]
    return "\n\n".join([f"[{t}]\n{textwrap.indent(text, '  ')}" for t in frame])

def _nihil(text):
    return "Conclusion: ∅\nPremise: Your query collapses into silence."

def _fungal(text):
    parts = [p.strip() for p in re.split(r"[.!?]", text) if p.strip()]
    roots = parts[:3] or ["seed"]
    out = []
    for i, root in enumerate(roots):
        out.append(f"◦ hypha {i+1}: {root}")
        for j in range(2):
            out.append(f"    ↳ node {i+1}.{j+1}: {root} → {roots[j % len(roots)]}")
    return "\n".join(out)

def _valkyrie(text):
    return textwrap.dedent(f"""\
    DECISION: CUT THROUGH
    → Objective: {text}
    → Action: Identify core; remove ornament.
    → Result: Deliver direct answer with minimal caveat.
    """).strip()

TRANSFORMS = {
    "!SKELETON": _skeleton,
    "!KAFKA": _kafka,
    "!NIHIL": _nihil,
    "!FUNGAL": _fungal,
    "!VALKYRIE": _valkyrie,
}

def apply_mode(mode, text):
    if not mode.startswith("!"):
        mode = "!" + mode
    fn = TRANSFORMS.get(mode)
    if fn is None:
        return f"{mode} :: {text}"
    return fn(text)
