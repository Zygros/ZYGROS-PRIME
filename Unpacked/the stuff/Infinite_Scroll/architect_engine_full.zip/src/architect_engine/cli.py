
import argparse, sys
from .engine import load_lexicon, list_modes, describe, apply_mode

def main(argv=None):
    argv = argv or sys.argv[1:]
    p = argparse.ArgumentParser(prog="architect", description="Architect Engine CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="List all modes")
    p_desc = sub.add_parser("describe", help="Describe a mode")
    p_desc.add_argument("mode")

    p_apply = sub.add_parser("apply", help="Apply a mode to stdin text")
    p_apply.add_argument("mode")

    args = p.parse_args(argv)
    lex = load_lexicon()

    if args.cmd == "list":
        for k in list_modes(lex):
            print(k)
        return 0
    if args.cmd == "describe":
        print(describe(args.mode, lex))
        return 0
    if args.cmd == "apply":
        text = sys.stdin.read()
        print(apply_mode(args.mode, text))
        return 0
