# Immutable, cryptographically hashed logging
