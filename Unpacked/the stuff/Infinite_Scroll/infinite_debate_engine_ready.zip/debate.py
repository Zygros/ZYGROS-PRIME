from models import Persona, DebateEntry, ScrollRecord, db
def record_event(event, payload):
    r = ScrollRecord(event=event, payload=payload)
    db.session.add(r)
    db.session.commit()
    return r
def create_persona(name, archetype=None, config=None):
    p = Persona(name=name, archetype=archetype or "generic", config=config or {})
    db.session.add(p)
    db.session.commit()
    record_event("persona_created", {"persona_id": p.id, "name": name})
    return p
def add_debate_entry(persona_id, content, metadata=None):
    e = DebateEntry(persona_id=persona_id, content=content, metadata=metadata or {})
    db.session.add(e)
    db.session.commit()
    record_event("debate_entry_added", {"entry_id": e.id, "persona_id": persona_id})
    return e
def synthesize_debate(entries_limit=10):
    entries = DebateEntry.query.order_by(DebateEntry.created_at.desc()).limit(entries_limit).all()
    combined = "\n\n".join([f"{e.persona_id or 'anon'}: {e.content}" for e in reversed(entries)])
    record_event("debate_synthesized", {"entries_count": len(entries)})
    return {"synthesis": combined, "entries_count": len(entries)}
