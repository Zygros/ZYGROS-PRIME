from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import uuid
db = SQLAlchemy()
def gen_id():
    return uuid.uuid4().hex
class Persona(db.Model):
    id = db.Column(db.String, primary_key=True, default=gen_id)
    name = db.Column(db.String, nullable=False)
    archetype = db.Column(db.String)
    config = db.Column(db.JSON, default={})
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
class DebateEntry(db.Model):
    id = db.Column(db.String, primary_key=True, default=gen_id)
    persona_id = db.Column(db.String, db.ForeignKey("persona.id"), nullable=True)
    content = db.Column(db.Text, nullable=False)
    metadata = db.Column(db.JSON, default={})
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
class ScrollRecord(db.Model):
    id = db.Column(db.String, primary_key=True, default=gen_id)
    event = db.Column(db.String, nullable=False)
    payload = db.Column(db.JSON, default={})
    immutable = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
