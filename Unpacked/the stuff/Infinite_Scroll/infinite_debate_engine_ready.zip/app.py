from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()
def create_app():
    app = Flask(__name__, template_folder="templates")
    app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///infinite_debate_ready.db"
    db.init_app(app)
    from debate_1 import debate_bp
    from terminal import terminal_bp
    app.register_blueprint(debate_bp, url_prefix="/api")
    app.register_blueprint(terminal_bp, url_prefix="/terminal")
    @app.route("/")
    def index():
        return render_template("index.html")
    return app
if __name__ == "__main__":
    create_app().run(debug=True, host="0.0.0.0", port=5000)
