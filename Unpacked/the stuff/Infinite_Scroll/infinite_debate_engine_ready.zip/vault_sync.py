# Auto-sync to Infinite Cloud / Termux / local vault
