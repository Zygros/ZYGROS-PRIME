
import os
from pathlib import Path

LEDGER_DIR = Path(os.getenv("SOV_ANCHOR_DIR", Path.home() / ".sovereign_anchor"))
LEDGER_DIR.mkdir(parents=True, exist_ok=True)
LEDGER_PATH = LEDGER_DIR / "ledger.jsonl"

# ETH
ETH_RPC_URL = os.getenv("ETH_RPC_URL", "")
ETH_PRIVATE_KEY = os.getenv("ETH_PRIVATE_KEY", "")
ETH_FROM_ADDRESS = os.getenv("ETH_FROM_ADDRESS", "")

# BTC
BTC_NETWORK = os.getenv("BTC_NETWORK", "testnet")  # "mainnet" or "testnet"
BTC_WIF = os.getenv("BTC_WIF", "")  # wallet import format

# ARWEAVE
ARWEAVE_KEYFILE = os.getenv("ARWEAVE_KEYFILE", str(Path.home() / ".arweave_key.json"))
