
# Simplified OP_RETURN anchoring using bitcoinlib.
# For production, manage fees, UTXOs, and change carefully.

from .config import BTC_NETWORK, BTC_WIF
from .hash_and_stamp import timestamp_utc, sha256_text
from .ledger import append_entry

from bitcoinlib.wallets import HDWallet
from bitcoinlib.services.services import Service

def anchor_text_btc(name: str, text: str) -> dict:
    if not BTC_WIF:
        raise RuntimeError("BTC_WIF not set")
    ts = timestamp_utc()
    h = sha256_text(text)

    # Create a temporary wallet from WIF
    wallet_name = f"sovereign_anchor_{BTC_NETWORK}"
    try:
        w = HDWallet.create(wallet_name, keys=BTC_WIF, network=BTC_NETWORK, witness_type='segwit', db_uri='sqlite://')
    except Exception:
        w = HDWallet(wallet_name)

    # Build OP_RETURN tx
    op_return_msg = bytes.fromhex(h)
    tx = w.send_to(op_return_msg, 0, output_type='op_return')  # value 0 sats to OP_RETURN data
    tx.info()
    txid = tx.txid

    entry = {
        "name": name,
        "timestamp": ts,
        "sha256": h,
        "btc_txid": txid,
        "network": f"bitcoin-{BTC_NETWORK}",
    }
    append_entry(entry)
    return entry
