
from .config import ETH_RPC_URL, ETH_PRIVATE_KEY, ETH_FROM_ADDRESS
from .hash_and_stamp import timestamp_utc, sha256_text
from .ledger import append_entry

from web3 import Web3
from web3.middleware import construct_sign_and_send_raw_middleware

def anchor_text_eth(name: str, text: str) -> dict:
    if not ETH_RPC_URL or not ETH_PRIVATE_KEY or not ETH_FROM_ADDRESS:
        raise RuntimeError("ETH env not set: ETH_RPC_URL, ETH_PRIVATE_KEY, ETH_FROM_ADDRESS required")
    w3 = Web3(Web3.HTTPProvider(ETH_RPC_URL))
    acct = w3.eth.account.from_key(ETH_PRIVATE_KEY)
    w3.middleware_onion.add(construct_sign_and_send_raw_middleware(acct))

    ts = timestamp_utc()
    h = sha256_text(text)
    data_hex = "0x" + h  # put the hash into tx data

    nonce = w3.eth.get_transaction_count(ETH_FROM_ADDRESS)
    tx = {
        "nonce": nonce,
        "to": None,                 # contract creation style (data-only)
        "value": 0,
        "gas": 120000,
        "maxFeePerGas": w3.to_wei("30", "gwei"),
        "maxPriorityFeePerGas": w3.to_wei("2", "gwei"),
        "data": data_hex,
        "chainId": w3.eth.chain_id,
    }
    tx_hash = w3.eth.send_transaction(tx)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

    entry = {
        "name": name,
        "timestamp": ts,
        "sha256": h,
        "eth_txid": receipt.transactionHash.hex(),
        "network": "ethereum",
    }
    append_entry(entry)
    return entry
