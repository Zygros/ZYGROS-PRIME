
import argparse, sys, pathlib, json
from .hash_and_stamp import timestamp_utc, sha256_text
from .ledger import append_entry
from .anchor_eth import anchor_text_eth
from .anchor_btc import anchor_text_btc
from .anchor_arweave import anchor_text_arweave

def _read_text(text: str | None, file: str | None) -> str:
    if file:
        return pathlib.Path(file).read_text(encoding="utf-8")
    if text is None:
        data = sys.stdin.read()
        if not data:
            raise SystemExit("Provide --text, --file, or pipe content via stdin")
        return data
    return text

def cmd_hash(args):
    content = _read_text(args.text, args.file)
    h = sha256_text(content)
    ts = timestamp_utc()
    entry = {"name": args.name, "timestamp": ts, "sha256": h, "network": "local"}
    append_entry(entry)
    print(json.dumps(entry, indent=2))

def cmd_eth(args):
    content = _read_text(args.text, args.file)
    entry = anchor_text_eth(args.name, content)
    print(json.dumps(entry, indent=2))

def cmd_btc(args):
    content = _read_text(args.text, args.file)
    entry = anchor_text_btc(args.name, content)
    print(json.dumps(entry, indent=2))

def cmd_ar(args):
    content = _read_text(args.text, args.file)
    entry = anchor_text_arweave(args.name, content)
    print(json.dumps(entry, indent=2))

def main():
    ap = argparse.ArgumentParser(prog="sovereign-anchor", description="Sovereign Anchoring: timestamp + hash + blockchain anchoring")
    sp = ap.add_subparsers(dest="cmd")

    ap_hash = sp.add_parser("hash", help="timestamp + hash + ledger only")
    ap_hash.add_argument("--name", required=True)
    ap_hash.add_argument("--text")
    ap_hash.add_argument("--file")
    ap_hash.set_defaults(func=cmd_hash)

    ap_eth = sp.add_parser("eth", help="anchor to Ethereum (data-only tx)")
    ap_eth.add_argument("--name", required=True)
    ap_eth.add_argument("--text")
    ap_eth.add_argument("--file")
    ap_eth.set_defaults(func=cmd_eth)

    ap_btc = sp.add_parser("btc", help="anchor to Bitcoin (OP_RETURN)")
    ap_btc.add_argument("--name", required=True)
    ap_btc.add_argument("--text")
    ap_btc.add_argument("--file")
    ap_btc.set_defaults(func=cmd_btc)

    ap_ar = sp.add_parser("ar", help="anchor to Arweave (permaweb)")
    ap_ar.add_argument("--name", required=True)
    ap_ar.add_argument("--text")
    ap_ar.add_argument("--file")
    ap_ar.set_defaults(func=cmd_ar)

    ap_serve = sp.add_parser("serve", help="run HTTP service")
    ap_serve.set_defaults(func=lambda _: __import__("sovereign_anchor.service").service.run())

    args = ap.parse_args()
    if not hasattr(args, "func"):
        ap.print_help()
        return
    args.func(args)

if __name__ == "__main__":
    main()
