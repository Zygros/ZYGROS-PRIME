
from .hash_and_stamp import timestamp_utc, sha256_text
from .ledger import append_entry
from .config import ARWEAVE_KEYFILE

import json, os
import arweave

def anchor_text_arweave(name: str, text: str) -> dict:
    if not os.path.exists(ARWEAVE_KEYFILE):
        raise RuntimeError(f"Arweave keyfile not found at {ARWEAVE_KEYFILE}")
    ts = timestamp_utc()
    h = sha256_text(text)

    wallet = arweave.Wallet(ARWEAVE_KEYFILE)
    tx = arweave.Transaction(wallet, data=text.encode("utf-8"))
    tx.add_tag("App-Name", "SovereignAnchor")
    tx.add_tag("Content-Type", "text/plain")
    tx.add_tag("Name", name)
    tx.add_tag("SHA256", h)
    tx.sign()
    tx.send()

    entry = {
        "name": name,
        "timestamp": ts,
        "sha256": h,
        "arweave_id": tx.id,
        "network": "arweave",
    }
    append_entry(entry)
    return entry
