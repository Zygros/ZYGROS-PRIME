
from .config import LEDGER_PATH
import json, os
from typing import Dict

def append_entry(entry: Dict):
    with open(LEDGER_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
