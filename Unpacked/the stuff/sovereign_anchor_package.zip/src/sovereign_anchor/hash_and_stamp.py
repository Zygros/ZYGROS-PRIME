
import hashlib, json
from datetime import datetime, timezone

def timestamp_utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))
