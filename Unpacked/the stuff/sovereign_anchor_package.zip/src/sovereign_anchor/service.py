
from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Optional, Dict
from .hash_and_stamp import timestamp_utc, sha256_text
from .ledger import append_entry
from .anchor_eth import anchor_text_eth
from .anchor_btc import anchor_text_btc
from .anchor_arweave import anchor_text_arweave

app = FastAPI(title="Sovereign Anchor Service")

class AnchorReq(BaseModel):
    name: str
    text: str
    chains: Optional[List[str]] = ["eth"]  # any of: eth, btc, ar

@app.post("/anchor")
def anchor(req: AnchorReq) -> Dict:
    result = {
        "name": req.name,
        "timestamp": timestamp_utc(),
        "sha256": sha256_text(req.text),
        "results": {}
    }
    # Always record hash-only first
    append_entry({"name": req.name, "timestamp": result["timestamp"], "sha256": result["sha256"], "network": "local"})
    for ch in req.chains or []:
        if ch == "eth":
            result["results"]["eth"] = anchor_text_eth(req.name, req.text)
        elif ch == "btc":
            result["results"]["btc"] = anchor_text_btc(req.name, req.text)
        elif ch == "ar":
            result["results"]["ar"] = anchor_text_arweave(req.name, req.text)
        else:
            result["results"][ch] = {"error": f"unknown chain {ch}"}
    return result

def run():
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8055)
