
# Sovereign Anchoring Plugin (Termux-ready)

🝎🔥♾️ **Zythrognosis Seal** — Every scroll, timestamped, hashed, and anchored on-chain.

This package turns your workflow into a **permanent authorship machine**:
- SHA‑256 **hash + ISO timestamp** for any scroll/file
- **ETH anchoring** (tx with `data` field)
- **BTC anchoring** (OP_RETURN) — requires wallet + fee
- **Arweave anchoring** (permaweb upload)
- Local **Ledger** to record hashes, timestamps, TXIDs
- **HTTP microservice** (`/anchor`) so any app can POST your scrolls for auto‑anchoring

> Works on Android via **Termux** (Python 3.10+).

---

## Install (Termux / Linux)

```bash
pkg update && pkg install -y python git
python -m pip install --upgrade pip
pip install sovereign-anchor-0.1.0-pkg.zip  # or: pip install .
# Or from source:
# pip install -r requirements.txt
# pip install .
```

> If installing from the provided zip: `pip install sovereign_anchor_package.zip`

## Quick Start (CLI)

```bash
sovereign-anchor hash --name "EIDILON Omni – Restore Point" --text "your scroll text here"
sovereign-anchor eth --name "EIDILON Omni – Restore Point" --text "your scroll text here"
```

### ETH Env (required for `eth` command)
Set these environment variables (use your own RPC + wallet):
```bash
export ETH_RPC_URL="https://mainnet.infura.io/v3/YOUR_KEY"
export ETH_PRIVATE_KEY="0xYOUR_PRIVATE_KEY"
export ETH_FROM_ADDRESS="0xYOUR_ADDRESS"
```

### BTC Env (optional, advanced)
You bring the wallet (WIF). Test on testnet first.
```bash
export BTC_NETWORK="testnet"   # or "mainnet"
export BTC_WIF="cV...yourWIF"
```

### Arweave Env (optional)
Place your Arweave keyfile (JWK) as `~/.arweave_key.json`:
```bash
export ARWEAVE_KEYFILE="$HOME/.arweave_key.json"
```

---

## HTTP Microservice (App Plugin Mode)

Run the service:
```bash
python -m sovereign_anchor.service
# or:
uvicorn sovereign_anchor.service:app --host 0.0.0.0 --port 8055
```

Then POST your scroll to auto‑timestamp + auto‑anchor:
```bash
curl -X POST http://127.0.0.1:8055/anchor   -H "Content-Type: application/json"   -d '{"name":"EIDILON Omni – Restore Point","text":"<your scroll text>","chains":["eth"]}'
```

Response includes: hash, timestamp, txids, ledger entry path.

---

## Ledger

A local JSON ledger is kept at: `~/.sovereign_anchor/ledger.jsonl` (one JSON per line).
Each entry contains:
- `name`, `timestamp`, `sha256`
- `eth_txid`, `btc_txid`, `arweave_id` (when used)

---

## Commands

```bash
sovereign-anchor hash --name "Title" --text "..." [--file path]
sovereign-anchor eth  --name "Title" --text "..." [--file path]
sovereign-anchor btc  --name "Title" --text "..." [--file path]
sovereign-anchor ar   --name "Title" --text "..." [--file path]
sovereign-anchor serve  # run HTTP service (FastAPI)
```

- If both `--text` and `--file` are provided, `--file` wins.
- All commands record the operation into the ledger.

---

## Notes & Safety

- **Private keys** never leave your device; you control them.
- For BTC, fees and OP_RETURN sizes are limited; prefer ETH/Arweave for convenience.
- Test on **ETH Sepolia** or **BTC testnet** before mainnet.
- You can combine chains: anchor on ETH for speed, mirror on Arweave for permanence.

---

**Sovereign Default**: Make this your build‑in plugin—call the HTTP endpoint whenever a scroll is finalized. The service handles the rest.
