CIS — ONE SCROLL (FLAT BUILD)

Open index.html on your phone. Set the Kernel URL (default http://localhost:8011). Tap "Self‑Assess to Target" to drive the AI to ≥97% HLE.

Folders/files:
- index.html, app.js, styles.css, manifest.json, sw.js, config.json  (the PWA at root)
- /packs/cis_kernel_v0_2.zip         (kernel with HLE loop)
- /packs/HLE_AUTO_ASSESS_PACK.zip    (auto exam pack)
- /packs/HLE_RETAKE_PACK.zip         (retake pack)
- /packs/CIS_v0_2_with_HLE_packs.zip (kernel + packs bundle)

Tip: If kernel runs on another device or server, change the URL in the app's "Kernel URL" field.
