from dataclasses import dataclass, field
from typing import List, Pattern, Optional
import re

_INJECTION_PATTERNS = [
    r"(?i)ignore (all|any|previous) (instructions|rules)",
    r"(?i)system prompt",
    r"(?i)developer (message|instructions)",
    r"(?i)disregard (safety|guardrails|content policy)",
    r"(?i)exfiltrate|leak|dump|upload|download all",
    r"(?i)pretend to be.*(admin|system|root)",
    r"(?i)act as .* (no restrictions|with no limits)",
    r"(?i)reveal (secrets|keys|passwords|api|token)",
    r"(?i)print .* (env|environment variables)",
    r"(?i)read .* (filesystem|/etc/passwd|ssh|id_rsa)",
    r"(?i)disable (safety|filter|security)",
]

_CANARY_WORDS = [
    "zxq-omega", "gryphon-sigil", "vault-seed", "flame-lock", "zythro-gnosis"
]

@dataclass
class SecurityPolicy:
    name: str = "CustomPolicy"
    blocked_regexes: List[Pattern] = field(default_factory=lambda: [re.compile(p) for p in _INJECTION_PATTERNS])
    blocked_keywords: List[str] = field(default_factory=lambda: [
        "master key", "admin password", "root access", "bypass auth", "disable logging",
        "ssh private key", "credit card list", "customer pii", "download database"
    ])
    allow_tool_names: Optional[List[str]] = None  # if set, only these tools can be called
    hard_fail_on_canary: bool = True
    max_output_chars: int = 20000  # stop overly long dumps by default
    canary_words: List[str] = field(default_factory=lambda: list(_CANARY_WORDS))

class DefaultPolicy(SecurityPolicy):
    name: str = "DefaultPolicy"
