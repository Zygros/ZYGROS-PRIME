from dataclasses import dataclass
from typing import Optional, Dict
import secrets, time

@dataclass
class Canary:
    key: str
    tag: str  # human label / purpose
    created_at: float

class CanaryManager:
    def __init__(self, prefix: str = "CANARY_"):
        self.prefix = prefix
        self._active: Dict[str, Canary] = {}

    def mint(self, tag: str) -> Canary:
        token = secrets.token_urlsafe(16)  # 22-char urlsafe token
        key = f"{self.prefix}{token}"
        c = Canary(key=key, tag=tag, created_at=time.time())
        self._active[key] = c
        return c

    def embed_into_context(self, ctx: dict, canary: Canary, field: str = "notes"):
        # Embed canary into any dict context (e.g., tool call context, RAG record).
        meta = ctx.get(field, "")
        ctx[field] = (meta + f" [{canary.key}]").strip()
        return ctx

    def tripped(self, text: str) -> Optional[Canary]:
        for key, canary in list(self._active.items()):
            if key in (text or ""):
                return canary
        return None

    def revoke(self, key: str):
        self._active.pop(key, None)
