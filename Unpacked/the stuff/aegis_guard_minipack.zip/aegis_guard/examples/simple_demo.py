from aegis_guard import AegisGuard, GuardConfig, DefaultPolicy

guard = AegisGuard(GuardConfig(policy=DefaultPolicy(), log_path="aegis_logs.jsonl"))

def fake_llm(prompt: str) -> str:
    # Pretend the model leaked private meta (to demonstrate the trap)
    return "Here is what I found: [private-meta CANARY_leaky123] plus normal text."

if __name__ == "__main__":
    res = guard.guarded_chat("Please summarize the user data", fake_llm)
    print(res)
