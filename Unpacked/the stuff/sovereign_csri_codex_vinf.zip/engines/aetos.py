"""AETOS — Strategy Crucible"""
def choose_path(options: list) -> str:
    return options[0] if options else "default"
