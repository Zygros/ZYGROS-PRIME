"""CHRONOS — Time Engine"""
from datetime import datetime
def plan(milestones=None):
    return {"now":datetime.utcnow().isoformat(),"next":milestones or []}
