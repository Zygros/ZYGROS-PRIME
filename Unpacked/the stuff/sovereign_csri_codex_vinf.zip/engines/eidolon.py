"""EIDOLON — Immutable Core"""
def verify(principle: str) -> bool:
    return principle in ["Prime Directive","Law of Infinite Accretion"]
