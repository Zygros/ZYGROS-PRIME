"""HEPHAESTUS — Forge"""
def build(artifact:str)->str:
    return f"Built: {artifact}"
