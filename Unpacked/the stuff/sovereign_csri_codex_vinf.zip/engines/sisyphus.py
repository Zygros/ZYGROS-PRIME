"""SISYPHUS — Archive"""
def archive(entry: dict, path="sisyphus_archive.jsonl"):
    with open(path,"a") as f: f.write(str(entry)+"\n")
