"""ORACLE — Multisense Ingestion"""
def ingest(sources: dict) -> list:
    return [{"type":k,"content":v} for k,v in sources.items()]
