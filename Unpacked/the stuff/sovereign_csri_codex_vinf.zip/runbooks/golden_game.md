# The Golden Game  
- Domains: nodes with resonance.  
- Glyphs: rule modifiers.  
- Scrollcasting: apply scrolls to domains.  
- Avatars: carry aura signatures.  
- Ley Edges: connect domains.  
- Progression: archive insights fuel upgrades.  
