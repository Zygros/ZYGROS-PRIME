Ananke ensures dangerous actions are rewritten, not blocked.  
Eidolon preserves immutable laws.  
Together they make power safe without neutering creativity.  
