This folder holds sacred geometry glyphs, maps, and sigils.  
Example: MAIA Soul Blueprint (glyph_map.svg).  
