### Example Invocations

!CRYPTO_CHECK_LIVE  
GET CoinGecko API for BTC, ETH, SOL.  

!WEATHER_CHECK  
GET OpenWeather API for city.  

!IMAGE_PULL  
GET Unsplash random image.  

!MONETIZE_IDEA  
Transform idea → business plan tiers.  
