import time
from typing import Dict

# Simple token bucket per key (e.g., IP). Not security-grade; just guardrails.
class TokenBucket:
    def __init__(self, rate_per_sec: float, burst: int):
        self.rate = rate_per_sec
        self.capacity = burst
        self.tokens = burst
        self.last = time.time()

    def allow(self) -> bool:
        now = time.time()
        delta = now - self.last
        self.last = now
        self.tokens = min(self.capacity, self.tokens + delta * self.rate)
        if self.tokens >= 1:
            self.tokens -= 1
            return True
        return False

_buckets: Dict[str, TokenBucket] = {}

def allow(key: str, rate_per_sec: float = 2.0, burst: int = 10) -> bool:
    b = _buckets.get(key)
    if not b:
        b = TokenBucket(rate_per_sec, burst)
        _buckets[key] = b
    return b.allow()
