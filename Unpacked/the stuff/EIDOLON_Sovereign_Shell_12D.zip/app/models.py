from pydantic import BaseModel, Field, constr
from typing import List, Optional

class InvokeRequest(BaseModel):
    mode: constr(strip_whitespace=True, to_upper=True) = Field(..., description="Codex mode to apply, e.g., FUNGAL, SKELETON")
    text: constr(strip_whitespace=True, min_length=1, max_length=50000)

class BatchItem(BaseModel):
    id: Optional[str] = None
    mode: constr(strip_whitespace=True, to_upper=True)
    text: constr(strip_whitespace=True, min_length=1, max_length=50000)

class BatchRequest(BaseModel):
    items: List[BatchItem]

class InvokeResponse(BaseModel):
    mode: str
    input_tokens: int
    output_tokens: int
    result: str
    policy_note: str
    request_id: str

class BatchResponseItem(BaseModel):
    id: Optional[str] = None
    mode: str
    result: str
    ok: bool
    error: Optional[str] = None

class BatchResponse(BaseModel):
    results: List[BatchResponseItem]

class ModeInfo(BaseModel):
    name: str
    description: str
    examples: List[str]

class CodexList(BaseModel):
    modes: List[ModeInfo]
    policy_allowlist: List[str]

class Stats(BaseModel):
    uptime_seconds: int
    requests_total: int
    cache_hits: int
    cache_misses: int
    rate_limited: int
