from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import JSONResponse, StreamingResponse, HTMLResponse
from uuid import uuid4
import hashlib, time, asyncio
from app.models import InvokeRequest, InvokeResponse, CodexList, ModeInfo, BatchRequest, BatchResponse, BatchResponseItem, Stats
from app.policy import POLICY_ALLOWLIST, POLICY_NOTES
from app.codex import CODEX_REGISTRY, LISTING
from app import cache as cachemod
from app import rate_limit as rl

START = time.time()
REQS = 0
CACHE_HITS = 0
CACHE_MISSES = 0
RATE_LIMITED = 0

app = FastAPI(title="EIDOLON Sovereign Shell (12D)", version="1.2.0")

def cache_key(mode: str, text: str) -> str:
    h = hashlib.sha256((mode + "::" + text).encode()).hexdigest()
    return h

@app.get("/")
async def console():
    # Serve static console
    return HTMLResponse(open("static/index.html","r",encoding="utf-8").read())

@app.get("/health")
async def health():
    return {"status": "ok", "version": app.version}

@app.get("/codex", response_model=CodexList)
async def codex():
    modes = [ModeInfo(**m) for m in LISTING if m["name"] in POLICY_ALLOWLIST]
    return CodexList(modes=modes, policy_allowlist=sorted(list(POLICY_ALLOWLIST)))

@app.get("/stats", response_model=Stats)
async def stats():
    uptime = int(time.time() - START)
    return Stats(uptime_seconds=uptime, requests_total=REQS, cache_hits=CACHE_HITS, cache_misses=CACHE_MISSES, rate_limited=RATE_LIMITED)

async def apply_mode(mode: str, text: str) -> str:
    handler = CODEX_REGISTRY[mode]["fn"]
    # Simulate small async work; handlers are CPU-light string ops
    return handler(text)

@app.post("/invoke", response_model=InvokeResponse)
async def invoke(req: InvokeRequest, request: Request):
    global REQS, CACHE_HITS, CACHE_MISSES, RATE_LIMITED
    REQS += 1

    client = request.client.host if request.client else "unknown"
    if not rl.allow(client):
        RATE_LIMITED += 1
        raise HTTPException(status_code=429, detail="Rate limit exceeded.")

    mode = req.mode.upper()
    if mode not in POLICY_ALLOWLIST:
        raise HTTPException(status_code=403, detail=f"Mode '{mode}' is not permitted by policy.")
    if mode not in CODEX_REGISTRY:
        raise HTTPException(status_code=404, detail=f"Mode '{mode}' not found.")

    key = cache_key(mode, req.text)
    cached = cachemod.cache_get(key)
    if cached is not None:
        CACHE_HITS += 1
        output = cached
    else:
        CACHE_MISSES += 1
        output = await apply_mode(mode, req.text)
        cachemod.cache_set(key, output)

    in_tokens = len(req.text.split())
    out_tokens = len(output.split())
    rid = str(uuid4())
    note = POLICY_NOTES.get(mode, "")

    return InvokeResponse(
        mode=mode,
        input_tokens=in_tokens,
        output_tokens=out_tokens,
        result=output,
        policy_note=note,
        request_id=rid,
    )

@app.post("/invoke/batch", response_model=BatchResponse)
async def invoke_batch(batch: BatchRequest, request: Request):
    global REQS
    REQS += 1
    client = request.client.host if request.client else "unknown"
    if not rl.allow(client, rate_per_sec=5.0, burst=20):
        raise HTTPException(status_code=429, detail="Rate limit exceeded.")

    results = []
    tasks = []
    # Prepare tasks
    for item in batch.items:
        mode = item.mode.upper()
        if mode not in POLICY_ALLOWLIST or mode not in CODEX_REGISTRY:
            results.append(BatchResponseItem(id=item.id, mode=mode, result="", ok=False, error="mode_not_allowed"))
            continue
        key = cache_key(mode, item.text)
        cached = cachemod.cache_get(key)
        if cached is not None:
            results.append(BatchResponseItem(id=item.id, mode=mode, result=cached, ok=True))
        else:
            async def run(mode=mode, text=item.text, iid=item.id):
                out = await apply_mode(mode, text)
                cachemod.cache_set(cache_key(mode, text), out)
                return BatchResponseItem(id=iid, mode=mode, result=out, ok=True)
            tasks.append(run())

    if tasks:
        produced = await asyncio.gather(*tasks)
        results.extend(produced)

    return BatchResponse(results=results)

@app.post("/invoke/stream")
async def invoke_stream(req: InvokeRequest, request: Request):
    global REQS
    REQS += 1
    client = request.client.host if request.client else "unknown"
    if not rl.allow(client):
        raise HTTPException(status_code=429, detail="Rate limit exceeded.")

    mode = req.mode.upper()
    if mode not in POLICY_ALLOWLIST or mode not in CODEX_REGISTRY:
        raise HTTPException(status_code=403, detail="Mode not permitted.")

    async def generator():
        yield f"request_id: {uuid4()}\n".encode()
        text = req.text
        # We stream in three chunks to provide immediate feedback
        yield b"status: processing\n"
        out = await apply_mode(mode, text)
        for line in out.splitlines():
            yield (line + "\n").encode()
            await asyncio.sleep(0)  # cooperative yield
        yield b"status: done\n"
    return StreamingResponse(generator(), media_type="text/plain")

@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"error": "internal_error", "message": str(exc)})
