from cachetools import LRUCache
from typing import Optional

# Small in-memory cache for idempotent calls (text-mode pairs)
_cache = LRUCache(maxsize=2048)

def cache_get(key: str) -> Optional[str]:
    return _cache.get(key)

def cache_set(key: str, value: str):
    _cache[key] = value

def stats():
    # cachetools doesn't expose hits/misses directly; track externally in main
    return {"size": len(_cache)}
