from typing import Set

# 12D allowlist: expanded but still safe textual transforms.
POLICY_ALLOWLIST: Set[str] = {
    "FUNGAL",
    "SKELETON",
    "MIRROR",
    "PHOENIX",
    "VEIL",
    "SYZYGY",
    "UNIVERSE",
    "OUTLINE",
    "CONTRAST",
    "REFRACTOR",
    "SUMMARY",
    "CHECKLIST"
}

POLICY_NOTES = {
    "FUNGAL": "Expands into interconnected bullet clusters; no claims of hidden data.",
    "SKELETON": "Strips to headings and bullet points only; no new facts.",
    "MIRROR": "Reflects and challenges assumptions without adding unverifiable claims.",
    "PHOENIX": "Two-step: critique then safer rewrite.",
    "VEIL": "Hints only; avoid sensitive specifics.",
    "SYZYGY": "Aligns two provided concepts; no invented third-party claims.",
    "UNIVERSE": "Layered summary (tl;dr → details) with hedging.",
    "OUTLINE": "Generates clean outlines with numbered sections.",
    "CONTRAST": "Compares A vs B (split with '::') across consistent criteria.",
    "REFRACTOR": "Rephrase for clarity and brevity; no new facts.",
    "SUMMARY": "Short, neutral summary; avoids speculation.",
    "CHECKLIST": "Actionable checklist derived from text; non-prescriptive."
}
