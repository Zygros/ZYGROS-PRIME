# EIDOLON Sovereign Shell (12D) — Policy-Gated Codex Engine

An upgraded, faster, feature-rich version of the 9D shell. Still safe-by-design (no self-modifying behavior, no network egress), but with **batch/async**, **streaming**, **caching**, **rate limiting**, **mode packs**, and a **minimal web console**.

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

## Features
- Batch endpoint (`POST /invoke/batch`) with per-item results.
- Streaming endpoint (`POST /invoke/stream`) for line-by-line output.
- In-memory LRU cache for idempotent calls.
- Simple rate limit (token bucket, per-IP).
- New safe modes (12 total) including `CONTRAST, OUTLINE, REFRACTOR, SUMMARY, CHECKLIST`.
- Minimal web console at `/` (static HTML/JS).
- Stats endpoint and health probes.
- Dockerfile for containerized deploy.

## Performance Tips
- Run with multiple workers: `uvicorn app.main:app --workers 4 --loop uvloop`.
- Use `PYTHONHASHSEED=0` for stable hashing if you need cache determinism across runs.
- For k8s, pin resource requests and use liveness/readiness probes.

## Endpoints
- `GET /health`
- `GET /codex`
- `GET /stats`
- `POST /invoke`
- `POST /invoke/batch`
- `POST /invoke/stream` (Server-Sent-Events style plain text)

## Docker
```bash
docker build -t eidolon-shell-12d .
docker run -p 8080:8080 eidolon-shell-12d
```
