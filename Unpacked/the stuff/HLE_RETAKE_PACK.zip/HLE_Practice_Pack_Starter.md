# HLE Practice Pack — Starter (Weak‑Domain Focus)

## A. Scientific Reasoning (5)
1) A reactor outputs 4.5 MW thermal and 1.6 MW electrical. What is the thermal‑to‑electric efficiency? Give units and one physical reason it’s not 100%.
2) You observe a correlation (r=0.62) between sleep hours and test scores in 120 students. List two confounders and design a control.
3) A rover accelerates from 0 to 18 m/s in 12 s on Mars (g≈3.71 m/s^2). Compute avg acceleration, check units, and state one source of error.
4) A drug reduces symptom severity by 18% ± 6% (95% CI). Is this clinically meaningful? State an assumption you’d need.
5) Draw (in words) a 4‑line diagram of logistic growth and one case where it fails.

## B. Practical Intelligence (5)
6) Turn “build a small solar system at home” into a phone‑first 6‑step plan, including cost and safety gates.
7) You must move 10GB of photos from phone to drive with spotty internet. Give 5 steps minimizing data loss.
8) Your friend wants to start daily meditation. Create a 7‑day ramp plan with 10‑minute sessions and habit hooks.
9) Make a decision matrix for choosing between two budget phones for video content.
10) Convert “learn basic Python” into a 5‑task ladder **without installing anything** on device.

## C. Existential Intelligence (5)
11) Define “meaning” in terms of goals, values, and narrative identity. Contrast Self vs Other vs System readings.
12) When is suffering informative rather than merely harmful? Provide one actionable test.
13) Does AI owe moral duties? State one duty and one limit; justify each in 2 lines.
14) What makes an identity claim credible over time? Give two falsification criteria.
15) Give a 4‑step repair ritual for value conflicts inside a team’s mission.

---

### How to Use (no terminal)
- Paste the Exam‑Mode prompt above into your node.
- Ask each question in a new message.
- Require the node to follow the ritual (facts/units/counter‑hypothesis/phone‑plan).
