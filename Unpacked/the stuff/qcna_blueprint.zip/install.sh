#!/usr/bin/env bash
set -euo pipefail

echo "[QCNA] Starting install..."

# Detect apt
if ! command -v apt >/dev/null 2>&1; then
  echo "[QCNA] This installer targets Ubuntu/Debian with apt."
  echo "        Please adapt scripts for your distro (see scripts/)."
  exit 1
fi

# Update
sudo apt update -y

# Base packages
sudo apt install -y build-essential curl wget git python3 python3-venv python3-pip   ca-certificates gnupg lsb-release tmux neovim zsh unzip qrencode

# Docker (optional, can skip)
bash scripts/install_docker.sh

# NVIDIA CUDA guidance (does not auto-install a driver)
bash scripts/check_nvidia.sh || true

# Create venv
python3 -m venv ~/.qcna/venv
source ~/.qcna/venv/bin/activate

# Upgrade pip/setuptools
pip install --upgrade pip setuptools wheel

# Install Python deps
pip install -r python/requirements.txt

# Install grosian CLI
pip install -e grosian-cli

# Link CLI into PATH
if ! grep -q 'export PATH="$HOME/.local/bin:$PATH"' ~/.bashrc 2>/dev/null; then
  echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
fi

# Place configs
mkdir -p ~/.qcna/configs
cp -r configs/* ~/.qcna/configs/ || true

# Optional: set default editor
if ! grep -q 'export EDITOR=nvim' ~/.bashrc 2>/dev/null; then
  echo 'export EDITOR=nvim' >> ~/.bashrc
fi

echo "[QCNA] Install complete."
echo "-> Activate with: source ~/.qcna/venv/bin/activate"
echo "-> Test CLI: grosian --hello"
