#!/usr/bin/env bash
set -euo pipefail

if command -v nvidia-smi >/dev/null 2>&1; then
  echo "[QCNA] NVIDIA GPU detected."
  nvidia-smi || true
  exit 0
fi

echo "[QCNA] No NVIDIA GPU or driver not installed."
echo "       If you have an NVIDIA GPU, install the proprietary driver and CUDA toolkit."
echo "       Ubuntu: sudo ubuntu-drivers autoinstall  && reboot"
