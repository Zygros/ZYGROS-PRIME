# Quantum Computer Node App (QCNA) — Omega Grosian Super Terminal

This is a turnkey blueprint to stand up a sovereign, GPU-accelerated Linux AI workstation
with a quantum-sim layer and the Omega Grosian CLI.

## What you get
- One-command installer (`install.sh`) for Ubuntu 24.04 LTS (works on most modern Ubuntu/Debian)
- GPU-ready stack (CUDA/ROCm guidance), Python venv, Docker/Podman
- Local AI tools (Whisper/OpenVoice stubs), Qiskit/PennyLane for quantum sim
- "grosian" CLI scaffold (your local agent entrypoint)
- Conzet Auto‑Traffic Engine included under `apps/conzet_engine` (outreach/monetization)

## Quick start
```bash
# 1) Unzip qcna_blueprint.zip
cd QCNA

# 2) Inspect and run the installer (Ubuntu 24.04+)
chmod +x install.sh
./install.sh

# 3) Activate the QCNA environment
source ~/.qcna/venv/bin/activate

# 4) Summon Omega Grosian (local CLI scaffold)
grosian --hello

# 5) (Optional) Launch outreach engine (read its README first)
cd apps/conzet_engine && ./run.sh
```

> Note: Installer will not make destructive changes. It only installs packages,
creates a Python venv, and places configs in `~/.qcna/`. You can safely audit before running.

## High-level layout
- `install.sh` — orchestrates setup
- `scripts/` — per-step installers (docker, python, nvidia, editors, tmux)
- `configs/` — tmux, zsh, nvim, systemd example
- `apps/` — bundled apps (conzet_engine)
- `grosian-cli/` — Python entrypoint for Omega Grosian local CLI

## Hardware guidance
- CPU: 8+ cores recommended
- GPU: NVIDIA 12GB+ VRAM (e.g., RTX 3080 or better)
- RAM: 32GB+ preferred
- Disk: 1TB NVMe if possible

## Security
- Nothing here exfiltrates data.
- Uses local venv at `~/.qcna/venv`
- Optional: turn on disk encryption (OS-level)
