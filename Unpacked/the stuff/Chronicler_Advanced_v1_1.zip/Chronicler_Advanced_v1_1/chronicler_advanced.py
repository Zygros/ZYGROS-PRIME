#!/usr/bin/env python3
# chronicler_advanced.py
# v1.1 — hardened, cache-aware, CLI-friendly refactor of ChroniclerAdvancedEngine
# MIT License

from __future__ import annotations

import json
import sqlite3
import pandas as pd
import numpy as np
from datetime import datetime
from collections import Counter
import re
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple, Optional
from functools import lru_cache

# Optional deps (sklearn, networkx) — guarded import
try:
    import networkx as nx  # noqa: F401
except Exception:
    nx = None

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.cluster import KMeans
except Exception:
    TfidfVectorizer = None
    KMeans = None


@dataclass
class ConversationInsight:
    """Advanced conversation analysis result"""
    conversation_id: str
    platform: str
    timestamp: datetime
    topic_clusters: List[str]
    complexity_score: float
    knowledge_domains: List[str]
    interaction_patterns: Dict[str, Any]
    value_metrics: Dict[str, float]


class ChroniclerAdvancedEngine:
    """🧠 ADVANCED INTELLIGENCE LAYER FOR CHRONICLER — v1.1"""

    def __init__(self, db_path: str, table: str = "chats", cfg: Optional[Dict[str, Any]] = None):
        self.db_path = db_path
        self.table = table
        self.cfg = cfg or default_config()
        self.df = self.load_data()
        self._depth_cache = None  # populated on first call

    # ---------- Data Loading ----------
    def load_data(self) -> pd.DataFrame:
        """Load and preprocess conversation data with robust guards."""
        with sqlite3.connect(self.db_path) as conn:
            # Defensive: ensure table exists
            try:
                df = pd.read_sql_query(f"SELECT * FROM {self.table}", conn)
            except Exception as e:
                raise RuntimeError(f"Failed to read table '{self.table}' from {self.db_path}: {e}")
        if df.empty:
            # create minimal columns to avoid downstream key errors
            for col in ("id", "timestamp", "source", "content"):
                if col not in df.columns:
                    df[col] = []
        # Coerce/clean columns
        if "timestamp" in df.columns:
            df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
        else:
            df["timestamp"] = pd.NaT
        df = df.dropna(subset=["timestamp"]).copy()
        if "source" not in df.columns:
            df["source"] = "unknown"
        if "id" not in df.columns:
            # fabricate ids if missing
            df["id"] = np.arange(1, len(df) + 1).astype(int)
        if "content" not in df.columns:
            df["content"] = ""
        # Time helpers
        df["hour"] = df["timestamp"].dt.hour
        df["day_of_week"] = df["timestamp"].dt.dayofweek
        df["date"] = df["timestamp"].dt.date
        df.sort_values("timestamp", inplace=True, kind="stable")
        df.reset_index(drop=True, inplace=True)
        return df

    # ---------- Public Orchestrator ----------
    def execute_full_analysis(self) -> Dict[str, Any]:
        ts = datetime.now().isoformat()
        return {
            "metadata": {
                "analysis_timestamp": ts,
                "total_conversations": int(len(self.df)),
                "platforms_analyzed": sorted(list(map(str, self.df["source"].unique()))),
                "time_range": {
                    "start": self.df["timestamp"].min().isoformat() if not self.df.empty else None,
                    "end": self.df["timestamp"].max().isoformat() if not self.df.empty else None,
                },
                "engine_version": "1.1",
            },
            "conversation_flows": self.analyze_conversation_flows(),
            "knowledge_domains": self.analyze_knowledge_domains(),
            "platform_intelligence": self.analyze_platform_intelligence(),
            "conversation_value": self.calculate_conversation_value(),
            "predictive_insights": self.generate_predictive_insights(),
            "optimization_recommendations": self._generate_optimization_recommendations(),
        }

    # ---------- Flow Analysis ----------
    def analyze_conversation_flows(self) -> Dict[str, Any]:
        return {
            "platform_transitions": self._detect_platform_switches(),
            "conversation_depth": self._measure_conversation_depth(),
            "interaction_rhythms": self._analyze_temporal_patterns(),
            "topic_evolution": self._track_topic_progression(),
            "engagement_levels": self._calculate_engagement_metrics(),
        }

    def _detect_platform_switches(self) -> Dict[str, Any]:
        switches = []
        df_sorted = self.df
        for i in range(1, len(df_sorted)):
            curr = df_sorted.iloc[i]
            prev = df_sorted.iloc[i - 1]
            if str(curr["source"]) != str(prev["source"]):
                gap_min = (curr["timestamp"] - prev["timestamp"]).total_seconds() / 60.0
                switches.append(
                    {
                        "from_platform": str(prev["source"]),
                        "to_platform": str(curr["source"]),
                        "time_gap_minutes": gap_min,
                        "timestamp": curr["timestamp"].isoformat(),
                    }
                )
        preferred = Counter([(s["from_platform"], s["to_platform"]) for s in switches]).most_common()
        return {
            "switches": switches,
            "switch_frequency": len(switches),
            "platform_stickiness": self._calculate_platform_stickiness(),
            "preferred_transitions": preferred,
        }

    def _calculate_platform_stickiness(self) -> Dict[str, float]:
        """Proxy: average conversations per active day for each platform."""
        stickiness = {}
        for platform, sub in self.df.groupby("source"):
            days = sub["date"].nunique() or 1
            stickiness[str(platform)] = float(len(sub) / days)
        return stickiness

    @lru_cache(maxsize=1)
    def _measure_conversation_depth(self) -> Dict[Any, Dict[str, float]]:
        """Compute per-row depth metrics; cached since it's reused in multiple places."""
        depth = {}
        for idx, chat in self.df.iterrows():
            content = str(chat.get("content", "") or "")
            wc = len(content.split())
            uw = len(set(content.lower().split()))
            asl = self._avg_sentence_length(content)
            tech_terms = self._count_technical_terms(content)
            qd = content.count("?") / max(wc, 1)

            # Weighted sum from config
            w = self.cfg["complexity_weights"]
            complexity = (
                wc * w["word_count"]
                + uw * w["unique_words"]
                + asl * w["avg_sentence_length"]
                + tech_terms * w["technical_terms"]
                + qd * w["question_density"]
            )
            depth[chat["id"]] = {
                "word_count": wc,
                "lexical_diversity": (uw / max(wc, 1)),
                "avg_sentence_length": asl,
                "technical_density": tech_terms / max(wc, 1),
                "question_density": qd,
                "complexity_score": complexity,
            }
        return depth

    def _analyze_temporal_patterns(self) -> Dict[str, Any]:
        return {
            "hourly_distribution": {int(k): int(v) for k, v in self.df.groupby("hour").size().to_dict().items()},
            "daily_patterns": {int(k): int(v) for k, v in self.df.groupby("day_of_week").size().to_dict().items()},
            "platform_timing": self.df.groupby(["source", "hour"]).size().unstack(fill_value=0).to_dict(),
            "conversation_gaps": self._calculate_conversation_gaps(),
            "peak_activity_windows": self._find_peak_windows(),
            "platform_rhythm": self._analyze_platform_rhythms(),
        }

    def _calculate_conversation_gaps(self) -> List[Dict[str, Any]]:
        gaps = []
        df_sorted = self.df
        for i in range(1, len(df_sorted)):
            gap = (df_sorted.iloc[i]["timestamp"] - df_sorted.iloc[i - 1]["timestamp"]).total_seconds() / 3600.0
            gaps.append({"gap_hours": gap, "between_platforms": [str(df_sorted.iloc[i - 1]["source"]), str(df_sorted.iloc[i]["source"])]})
        return gaps

    def _find_peak_windows(self) -> List[Dict[str, Any]]:
        hourly_counts = self.df.groupby("hour").size()
        top = hourly_counts.nlargest(min(3, len(hourly_counts)))
        return [{"hour": int(h), "activity_level": int(c)} for h, c in top.items()]

    def _analyze_platform_rhythms(self) -> Dict[str, Any]:
        rhythms = {}
        for platform, sub in self.df.groupby("source"):
            mode_vals = sub["hour"].mode().tolist()
            rhythms[str(platform)] = {
                "peak_hours": list(map(int, mode_vals)),
                "avg_hour": float(sub["hour"].mean() if len(sub) else 0.0),
                "hour_distribution": {int(k): int(v) for k, v in sub["hour"].value_counts().to_dict().items()},
            }
        return rhythms

    def _track_topic_progression(self) -> Dict[str, Any]:
        if len(self.df) < 2:
            return {"insufficient_data": True}
        contents = self.df["content"].fillna("").astype(str)
        if contents.str.len().sum() == 0:
            return {"no_content": True}
        if TfidfVectorizer is None or KMeans is None:
            return {"sklearn_unavailable": True, "fallback_analysis": self._simple_topic_analysis()}
        try:
            vectorizer = TfidfVectorizer(max_features=self.cfg["tfidf"]["max_features"],
                                         stop_words="english",
                                         ngram_range=tuple(self.cfg["tfidf"]["ngram_range"]))
            tf = vectorizer.fit_transform(contents)
            n_clusters = int(np.clip(self.cfg["clustering"]["n_clusters"], 2, max(2, len(self.df)//2))) if len(self.df) > 3 else min(2, len(self.df))
            kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
            clusters = kmeans.fit_predict(tf)
            self.df["topic_cluster"] = clusters
            # hourly evolution
            topic_evolution = self.df.groupby([pd.Grouper(key="timestamp", freq="H"), "topic_cluster"]).size()
            feature_names = vectorizer.get_feature_names_out()
            cluster_terms = {}
            for i in range(n_clusters):
                top_idx = kmeans.cluster_centers_[i].argsort()[-10:][::-1]
                cluster_terms[f"cluster_{i}"] = [feature_names[idx] for idx in top_idx]
            return {
                "topic_clusters": cluster_terms,
                "topic_evolution": {str(k): int(v) for k, v in topic_evolution.to_dict().items()},
                "topic_transitions": self._analyze_topic_transitions(clusters),
                "dominant_topics": Counter(clusters).most_common(),
            }
        except Exception as e:
            return {"error": str(e), "fallback_analysis": self._simple_topic_analysis()}

    def _analyze_topic_transitions(self, clusters: np.ndarray) -> List[Dict[str, Any]]:
        trans = []
        dfc = self.df.copy()
        dfc["cluster"] = clusters
        for i in range(1, len(dfc)):
            if int(dfc.iloc[i]["cluster"]) != int(dfc.iloc[i - 1]["cluster"]):
                trans.append({
                    "from_topic": int(dfc.iloc[i - 1]["cluster"]),
                    "to_topic": int(dfc.iloc[i]["cluster"]),
                    "platform": str(dfc.iloc[i]["source"]),
                    "timestamp": dfc.iloc[i]["timestamp"].isoformat(),
                })
        return trans

    # ---------- Domain Analysis ----------
    def analyze_knowledge_domains(self) -> Dict[str, Any]:
        return {
            "technical_domains": self._identify_technical_domains(),
            "creative_domains": self._identify_creative_domains(),
            "learning_domains": self._identify_learning_patterns(),
            "problem_solving_domains": self._identify_problem_patterns(),
            "domain_expertise_progression": self._track_expertise_growth(),
        }

    def _identify_technical_domains(self) -> List[str]:
        technical_keywords = self.cfg["domains"]["technical"]
        all_text = " ".join(self.df["content"].fillna("").astype(str).str.lower())
        return [d for d, kws in technical_keywords.items() if any(k in all_text for k in kws)]

    def _identify_creative_domains(self) -> List[str]:
        creative_keywords = self.cfg["domains"]["creative"]
        all_text = " ".join(self.df["content"].fillna("").astype(str).str.lower())
        return [d for d, kws in creative_keywords.items() if any(k in all_text for k in kws)]

    def _identify_learning_patterns(self) -> Dict[str, Any]:
        indicators = self.cfg["learning_indicators"]
        all_text = " ".join(self.df["content"].fillna("").astype(str).str.lower())
        learning_score = sum(all_text.count(ind) for ind in indicators)
        return {
            "learning_intensity": int(learning_score),
            "question_based_learning": int(all_text.count("?")),
            "tutorial_seeking": int(all_text.count("tutorial") + all_text.count("how to")),
        }

    def _identify_problem_patterns(self) -> Dict[str, Any]:
        indicators = self.cfg["problem_indicators"]
        all_text = " ".join(self.df["content"].fillna("").astype(str).str.lower())
        problem_score = sum(all_text.count(ind) for ind in indicators)
        return {
            "problem_solving_intensity": int(problem_score),
            "error_debugging": int(all_text.count("error") + all_text.count("bug")),
            "help_seeking": int(all_text.count("help")),
        }

    def _track_expertise_growth(self) -> Dict[str, Any]:
        df_sorted = self.df
        scores = []
        for _, chat in df_sorted.iterrows():
            content = str(chat.get("content", "") or "")
            td = self._count_technical_terms(content) / max(len(content.split()), 1)
            scores.append(float(td))
        growth = float(np.gradient(scores).mean()) if len(scores) > 1 else 0.0
        current = float(scores[-1]) if scores else 0.0
        return {"expertise_trajectory": scores, "expertise_growth_rate": growth, "current_expertise_level": current}

    # ---------- Platform Intelligence ----------
    def analyze_platform_intelligence(self) -> Dict[str, Any]:
        intel = {}
        depth = self._measure_conversation_depth()
        for platform, sub in self.df.groupby("source"):
            # average complexity from cached depth
            avg_complexity = float(np.mean([depth.get(cid, {}).get("complexity_score", 0.0) for cid in sub["id"]])) if len(sub) else 0.0
            contents = sub["content"].fillna("").astype(str)
            intel[str(platform)] = {
                "usage_frequency": int(len(sub)),
                "avg_session_length": float(contents.str.split().str.len().mean() if len(contents) else 0.0),
                "complexity_preference": avg_complexity,
                "time_preferences": {int(k): int(v) for k, v in sub["hour"].value_counts().to_dict().items()},
                "unique_characteristics": self._identify_platform_characteristics(contents),
            }
        return intel

    def _identify_platform_characteristics(self, contents: pd.Series) -> Dict[str, Any]:
        texts = contents.fillna("").astype(str)
        all_text = " ".join(texts).lower()
        avg_complexity = float(
            np.mean([self._count_technical_terms(t) / max(len(t.split()), 1) for t in texts if t.strip()])
        ) if len(texts) else 0.0
        return {
            "avg_complexity": avg_complexity,
            "question_ratio": float(all_text.count("?") / max(len(all_text.split()), 1)),
            "total_engagement_chars": int(len(all_text)),
        }

    # ---------- Value & Predictions ----------
    def calculate_conversation_value(self) -> Dict[str, Any]:
        return {
            "knowledge_acquisition_rate": float(self._calculate_learning_velocity()),
            "problem_solving_efficiency": float(self._measure_solution_speed()),
            "creative_output_value": float(self._assess_creative_value()),
            "time_investment_roi": self._calculate_time_roi(),
            "platform_value_optimization": self._optimize_platform_usage(),
            "total_conversation_value": float(self._calculate_total_value()),
        }

    def generate_predictive_insights(self) -> Dict[str, Any]:
        return {
            "optimal_platform_suggestions": self._predict_best_platform(),
            "peak_productivity_windows": self._predict_best_times(),
            "conversation_outcome_probability": self._predict_success_likelihood(),
            "topic_evolution_forecast": self._forecast_topic_trends(),
            "learning_acceleration_opportunities": self._identify_acceleration_points(),
        }

    # ---------- Helpers ----------
    def _avg_sentence_length(self, text: str) -> float:
        sentences = re.split(r"[.!?]+", text)
        tokens = [len(s.split()) for s in sentences if s.strip()]
        return float(np.mean(tokens)) if tokens else 0.0

    def _count_technical_terms(self, text: str) -> int:
        indicators = self.cfg["technical_indicators"]
        t = text.lower()
        return int(sum(t.count(term) for term in indicators))

    def _simple_topic_analysis(self) -> Dict[str, Any]:
        all_text = " ".join(self.df["content"].fillna("").astype(str))
        words = re.findall(r"\w+", all_text.lower())
        top = Counter(words).most_common(20)
        return {"top_words": top, "total_words": int(len(words)), "unique_words": int(len(set(words)))}

    def _calculate_learning_velocity(self) -> float:
        if len(self.df) < 2:
            return 0.0
        timespan_h = (self.df["timestamp"].max() - self.df["timestamp"].min()).total_seconds() / 3600.0
        total_words = sum(len(str(c).split()) for c in self.df["content"].fillna(""))
        return float(total_words / max(timespan_h, 1.0))

    def _measure_solution_speed(self) -> float:
        days = (self.df["timestamp"].max() - self.df["timestamp"].min()).days + 1 if len(self.df) else 1
        return float(len(self.df) / max(days, 1))

    def _assess_creative_value(self) -> float:
        indicators = self.cfg["creative_indicators"]
        text = " ".join(self.df["content"].fillna("").astype(str).str.lower())
        score = sum(text.count(ind) for ind in indicators)
        return float(score / max(len(self.df), 1))

    def _calculate_time_roi(self) -> Dict[str, float]:
        if self.df.empty:
            return {"conversations_per_hour": 0.0, "words_per_hour": 0.0, "platforms_efficiency": 0.0}
        total_h = (self.df["timestamp"].max() - self.df["timestamp"].min()).total_seconds() / 3600.0
        total_h = max(total_h, 1.0)
        return {
            "conversations_per_hour": float(len(self.df) / total_h),
            "words_per_hour": float(sum(len(str(c).split()) for c in self.df["content"].fillna("")) / total_h),
            "platforms_efficiency": float(self.df["source"].nunique() / total_h),
        }

    def _optimize_platform_usage(self) -> Dict[str, Any]:
        stats = {}
        depth = self._measure_conversation_depth()
        for platform, sub in self.df.groupby("source"):
            avg_complexity = float(np.mean([depth.get(cid, {}).get("complexity_score", 0.0) for cid in sub["id"]])) if len(sub) else 0.0
            stats[str(platform)] = {
                "usage_count": int(len(sub)),
                "avg_complexity": avg_complexity,
                "peak_hours": list(map(int, sub["hour"].mode().tolist())) if len(sub) else [],
            }
        return stats

    def _calculate_total_value(self) -> float:
        w = self.cfg["value_weights"]
        return (
            self._calculate_learning_velocity() * w["learning"]
            + self._assess_creative_value() * w["creative"]
            + self._measure_solution_speed() * w["problem_solving"]
            + len(self.df) * w["traffic"]
        )

    def _predict_best_platform(self) -> Dict[str, str]:
        predictions = {}
        intel = self.analyze_platform_intelligence()
        for plat, stats in intel.items():
            if stats["complexity_preference"] > self.cfg["thresholds"]["complexity_high"]:
                predictions[plat] = "technical_deep_work"
            elif stats["avg_session_length"] > self.cfg["thresholds"]["session_length_long"]:
                predictions[plat] = "extended_collaboration"
            else:
                predictions[plat] = "quick_queries"
        return predictions

    def _predict_best_times(self) -> List[Dict[str, Any]]:
        hp = (
            self.df.groupby("hour")
            .agg(content_words=("content", lambda x: sum(len(str(c).split()) for c in x)))
            .reset_index()
        )
        top = hp.nlargest(min(3, len(hp)), "content_words")
        return [{"hour": int(r["hour"]), "productivity_score": "high"} for _, r in top.iterrows()]

    def _predict_success_likelihood(self) -> Dict[str, float]:
        mode_hour = int(self.df["hour"].mode().iloc[0]) if len(self.df) else 12
        optimal = 0.8 if mode_hour in self.cfg["optimal_hours"] else 0.5
        platform_bonus = 0.9 if self.df["source"].nunique() > 1 else 0.6
        complexity_assume = 0.85
        return {"optimal_time": float(optimal), "platform_match": float(platform_bonus), "complexity_balance": float(complexity_assume)}

    def _forecast_topic_trends(self) -> Dict[str, str]:
        recent = self._identify_technical_domains() + self._identify_creative_domains()
        return {topic: "expanding" for topic in recent}

    def _identify_acceleration_points(self) -> List[Dict[str, str]]:
        return [
            {"opportunity": "cross_platform_synthesis", "impact": "high"},
            {"opportunity": "knowledge_gap_targeting", "impact": "medium"},
            {"opportunity": "optimal_timing_usage", "impact": "medium"},
        ]

    def _generate_optimization_recommendations(self) -> List[Dict[str, Any]]:
        recs = []
        if self.df["source"].nunique() > 1:
            recs.append({
                "category": "platform_optimization",
                "recommendation": "Leverage platform-specific strengths based on usage patterns",
                "priority": "high",
                "implementation": "Route technical queries to highest-complexity platforms",
            })
        peaks = self._find_peak_windows()
        if peaks:
            recs.append({
                "category": "temporal_optimization",
                "recommendation": f"Schedule complex work during peak hours: {[w['hour'] for w in peaks]}",
                "priority": "medium",
                "implementation": "Block calendar for AI collaboration during peak windows",
            })
        if self._calculate_learning_velocity() > 0:
            recs.append({
                "category": "learning_acceleration",
                "recommendation": "Maintain current learning velocity and explore knowledge gaps",
                "priority": "medium",
                "implementation": "Set daily learning targets and track progress",
            })
        return recs


# ---------- Configuration ----------
def default_config() -> Dict[str, Any]:
    return {
        "complexity_weights": {
            "word_count": 0.1,
            "unique_words": 0.2,
            "avg_sentence_length": 0.15,
            "technical_terms": 0.3,
            "question_density": 25.0,
        },
        "tfidf": {"max_features": 100, "ngram_range": [1, 2]},
        "clustering": {"n_clusters": 3},
        "domains": {
            "technical": {
                "programming": ["code", "function", "class", "import", "python", "javascript"],
                "data_science": ["data", "analysis", "model", "algorithm", "machine learning"],
                "system_design": ["architecture", "system", "database", "api", "framework"],
                "ai_ml": ["ai", "artificial intelligence", "neural network", "deep learning"],
            },
            "creative": {
                "writing": ["story", "narrative", "character", "plot", "creative writing"],
                "visual_arts": ["design", "visual", "art", "graphics", "image"],
                "music": ["music", "song", "rhythm", "melody", "beatbox"],
                "worldbuilding": ["world", "mythology", "lore", "fantasy", "sci-fi"],
            },
        },
        "learning_indicators": ["how to", "explain", "what is", "why does", "tutorial", "learn"],
        "problem_indicators": ["problem", "issue", "error", "bug", "fix", "solve", "help"],
        "creative_indicators": ["create", "design", "build", "generate", "story", "art"],
        "thresholds": {"complexity_high": 50.0, "session_length_long": 100.0},
        "optimal_hours": [9, 10, 14, 15],
        "value_weights": {"learning": 0.3, "creative": 0.25, "problem_solving": 0.25, "traffic": 0.2},
    }


# ---------- CLI ----------
def main():
    import argparse, pathlib
    parser = argparse.ArgumentParser(description="Chronicler Advanced Engine v1.1")
    parser.add_argument("--db", dest="db_path", default="chronicler_output/chronicler.db", help="Path to SQLite DB")
    parser.add_argument("--table", dest="table", default="chats", help="Table name containing chat logs")
    parser.add_argument("--config", dest="config", default=None, help="Optional JSON config path")
    parser.add_argument("--out", dest="out_dir", default="chronicler_output", help="Directory to write results")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON (indent=2)")
    args = parser.parse_args()

    cfg = default_config()
    if args.config and pathlib.Path(args.config).exists():
        with open(args.config, "r") as f:
            user_cfg = json.load(f)
        # shallow merge — override provided keys
        cfg.update(user_cfg)

    engine = ChroniclerAdvancedEngine(args.db_path, table=args.table, cfg=cfg)
    results = engine.execute_full_analysis()

    pathlib.Path(args.out_dir).mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_json = pathlib.Path(args.out_dir) / f"advanced_analysis_{ts}.json"
    with open(out_json, "w") as f:
        if args.pretty:
            json.dump(results, f, indent=2, default=str)
        else:
            json.dump(results, f, separators=(",", ":"), default=str)

    # Also export a compact CSV of platform intelligence & peak windows for quick glance
    plat = results.get("platform_intelligence", {})
    platform_rows = []
    for k, v in plat.items():
        platform_rows.append({
            "platform": k,
            "usage_frequency": v.get("usage_frequency", 0),
            "avg_session_length": v.get("avg_session_length", 0.0),
            "complexity_preference": v.get("complexity_preference", 0.0),
        })
    df_plat = pd.DataFrame(platform_rows)
    df_plat.to_csv(pathlib.Path(args.out_dir) / f"platform_intelligence_{ts}.csv", index=False)

    print(f"📊 [CHRONICLER ADVANCED] Analysis written to: {out_json}")


if __name__ == "__main__":
    main()
