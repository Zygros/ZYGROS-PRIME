-- sample_schema.sql
CREATE TABLE IF NOT EXISTS chats (
  id INTEGER PRIMARY KEY,
  timestamp TEXT NOT NULL,
  source TEXT NOT NULL,
  content TEXT NOT NULL
);

-- Minimal seed example (UTC ISO timestamps)
INSERT INTO chats (timestamp, source, content) VALUES
('2025-09-22T10:15:00','chatgpt','Explain vector databases vs relational databases?'),
('2025-09-22T11:05:00','grok','Write Python to parse logs and summarize errors.'),
('2025-09-22T14:42:00','chatgpt','Help me design a module interface for AI tools.');
