# Chronicler Advanced Engine — v1.1

A hardened, cache-aware refactor of your **ChroniclerAdvancedEngine** with:
- Robust guards around missing columns/tables
- Cached depth metrics to avoid recomputation
- Configurable weights/thresholds via `config.json`
- Clean CLI (`--db`, `--table`, `--config`, `--out`, `--pretty`)
- JSON + CSV outputs for quick review
- Dependency-light core (skips sklearn/networkx gracefully if unavailable)

## Quickstart

```bash
# 1) Activate your venv (recommended)
python3 -m venv .venv && source .venv/bin/activate

# 2) Install minimal deps
pip install pandas numpy

# Optional for clustering:
pip install scikit-learn

# 3) Run
python3 chronicler_advanced.py --db chronicler_output/chronicler.db --out chronicler_output --pretty
```

### Expected SQLite Schema

```sql
-- See sample_schema.sql for a reference.
CREATE TABLE IF NOT EXISTS chats (
  id INTEGER PRIMARY KEY,
  timestamp TEXT NOT NULL,
  source TEXT NOT NULL,   -- e.g., "chatgpt", "grok", "gemini"
  content TEXT NOT NULL
);
```

> If your table is named differently, use `--table YOUR_TABLE_NAME`.

## Config Overrides

Copy `config.example.json` to `config.json` and tweak weights/thresholds:
```json
{
  "thresholds": {"complexity_high": 60.0}
}
```

## Outputs

- `advanced_analysis_YYYYMMDD_HHMMSS.json` — full analysis
- `platform_intelligence_YYYYMMDD_HHMMSS.csv` — quick-glance metrics

## License

MIT — do what you want, no warranty.
