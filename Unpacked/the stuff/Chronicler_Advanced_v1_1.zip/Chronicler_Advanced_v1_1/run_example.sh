#!/bin/bash
set -euo pipefail
VENV=".venv"
if [ ! -d "$VENV" ]; then
  python3 -m venv "$VENV"
fi
source "$VENV/bin/activate"
pip install --quiet pandas numpy || true
python3 chronicler_advanced.py --db chronicler_output/chronicler.db --out chronicler_output --pretty
