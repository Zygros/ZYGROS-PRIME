from typing import Callable, Dict, Any, Awaitable, List, Optional
from transparency import Transparency
from registry import ApiRegistry

Handler = Callable[[str, dict], Awaitable[dict]]

class EventBus:
    def __init__(self, registry: ApiRegistry, transparency: Transparency):
        self.registry = registry
        self.transparency = transparency
        self._handlers: Dict[str, Handler] = {}
        self.interceptors: List[Callable[[str, str], Awaitable[str]]] = []

    def register(self, name: str, handler: Handler):
        self._handlers[name.lower().strip()] = handler

    async def dispatch(self, decree: str, ctx: Optional[dict]=None) -> dict:
        ctx = ctx or {}
        original = decree
        if ":" in decree:
            verb, payload = decree.split(":", 1)
            verb = verb.strip().lower(); payload = payload.strip()
        else:
            verb, payload = "activate", decree.strip()
        handler = self._handlers.get(verb)
        if not handler:
            return {"ok": False, "error": f"no handler for '{verb}'", "known": list(self._handlers.keys())}
        result = await handler(payload, ctx)
        await self.transparency.log({"decree": original, "verb": verb, "payload": payload, "result": result})
        return {"ok": True, "data": result}
