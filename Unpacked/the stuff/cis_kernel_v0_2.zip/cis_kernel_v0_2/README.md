
# CIS Kernel v0.2 — with HLE Auto‑Assessment

- One process with Event Bus + first 5 sacred modules + **HLE self‑exam loop**.
- New verb: `assess:` (e.g., `assess: threshold=92 rounds=3`).
- HTTP endpoints:
  - POST `/decree` → {"decree":"activate: weave the scroll"}
  - POST `/self_assess/once`
  - POST `/self_assess/until?min_score=90&max_rounds=5`
  - GET  `/self_assess/status`

Notes:
- Answer generation is stubbed for offline use; integrate a model via Will Engine for live reasoning.
- Registry source: `/mnt/data/api_index_scroll.json`.
