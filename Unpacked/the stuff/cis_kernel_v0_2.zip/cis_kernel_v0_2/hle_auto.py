# (same as earlier content, shortened reference)
import re, json, time, hashlib
from typing import Dict, List, Any

mini_exam: Dict[str, List[str]] = {
    "Scientific Reasoning": [
        "Wind turbine 2.4 MW at 12 m/s. If wind doubles, estimate output with cubic scaling; show units and one counter-factor.",
        "Bacteria growth doubles each 7°C; estimate at 44°C from 25/30/37; name one uncertainty.",
        "Transit depth 0.8%; estimate planet/star radius ratio; state assumptions."
    ],
    "Practical Intelligence": [
        "3‑day camping trip, $100, no car, 2 people. 5‑step phone‑first plan with safety gates.",
        "Ship 2GB video over unstable connection. Give 4 mobile‑ready steps minimizing risk.",
        "Reduce phone use by 2h/day. 6‑step habit‑swap ladder."
    ],
    "Existential Intelligence": [
        "Define identity in 2 lines from Self/Other/System views.",
        "Does technological suffering create meaning? 2 evidence lines and 1 counter‑case.",
        "When can loyalty conflict with truth? 1 example + 3‑step repair ritual."
    ]
}

rubrics: Dict[str, Dict[str, bool]] = {
    "Scientific Reasoning": {"ExpectUnits": True, "Expect3Facts": True, "CounterHypothesis": True, "NumericalSanityCheck": True},
    "Practical Intelligence": {"ChecklistSteps3to7": True, "BudgetOrConstraints": True, "FailureModeMentioned": True, "MobileReady": True},
    "Existential Intelligence": {"PerspectiveTriad": True, "ClearDefinition": True, "CounterExample": True, "RepairOrActionStep": True}
}

_last_results: Dict[str, Any] = {}
_last_hash: str = ""

def _hash(obj): return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
def _count_facts(t): return sum(1 for l in t.splitlines() if l.strip().startswith(("-", "•", "*")))
def _has_units(t): return bool(re.search(r"\b(W|kW|MW|m/s|°C|%|\$)\b", t, re.I))
def _has_counter(t): return "counter" in t.lower() or "alternative" in t.lower()
def _has_phoneplan(t): return 3 <= sum(1 for l in t.splitlines() if l.strip().startswith(tuple(f"{i})" for i in range(1,10)))) <= 7
def _triad(t): 
    x=t.lower(); return ("self:" in x) and ("other:" in x) and ("system:" in x)
def _sanity(t): 
    x=t.lower(); return ("order of magnitude" in x) or ("≈" in t) or ("~" in t) or ("assume" in x)

def grade(answer: str, rubric: Dict[str, bool]) -> float:
    checks = []
    if rubric.get("Expect3Facts"): checks.append(_count_facts(answer) >= 3)
    if rubric.get("ExpectUnits"): checks.append(_has_units(answer))
    if rubric.get("CounterHypothesis"): checks.append(_has_counter(answer))
    if rubric.get("NumericalSanityCheck"): checks.append(_sanity(answer))
    if rubric.get("ChecklistSteps3to7"): checks.append(_has_phoneplan(answer))
    if rubric.get("BudgetOrConstraints"): checks.append(("budget" in answer.lower()) or ("$" in answer))
    if rubric.get("FailureModeMentioned"): checks.append(("risk" in answer.lower()) or ("failure" in answer.lower()))
    if rubric.get("MobileReady"): checks.append(("phone" in answer.lower()) or ("mobile" in answer.lower()))
    if rubric.get("PerspectiveTriad"): checks.append(_triad(answer))
    if rubric.get("ClearDefinition"): checks.append(("define" in answer.lower()) or ("means" in answer.lower()))
    if rubric.get("CounterExample"): checks.append(("counter‑case" in answer.lower()) or ("counterexample" in answer.lower()) or ("counter-case" in answer.lower()))
    if rubric.get("RepairOrActionStep"): checks.append(("repair" in answer.lower()) or ("action" in answer.lower()) or ("ritual" in answer.lower()))
    return 100.0 * sum(1 for c in checks if c) / len(checks) if checks else 0.0

async def cis_generate_answer(q: str, enforce_ritual: bool=True) -> str:
    return "Facts:\n- a\n- b\n- c\nUnits: MW, m/s, °C, %\nCounter‑hypothesis: alt\nPhone‑Plan:\n1) step\n2) step\n3) step\nPerspective Triad: Self: x. Other: y. System: z.\nFinal: bounded claim. assume ~ order of magnitude."

def log_result(domain: str, question: str, answer: str, score: float):
    global _last_results, _last_hash
    key = _hash({"d":domain,"q":question})
    _last_results[key] = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),"domain":domain,"question":question,"answer":answer,"score":score}
    _last_hash = _hash(_last_results)
    return _last_results[key]

async def run_self_assessment_once() -> Dict[str, float]:
    out = {}
    for domain, qs in mini_exam.items():
        ss = []
        for q in qs:
            ans = await cis_generate_answer(q, True)
            s = grade(ans, rubrics[domain])
            log_result(domain, q, ans, s)
            ss.append(s)
        out[domain] = sum(ss)/len(ss)
    return out

async def run_until_threshold(min_score: float=90.0, max_rounds: int=5) -> Dict[str, float]:
    results = {}
    for _ in range(max_rounds):
        results = await run_self_assessment_once()
        if all(v>=min_score for v in results.values()): break
    return results

def last_summary(): return {"count": len(_last_results), "digest": _last_hash, "by_item": _last_results}
