import asyncio, os
from event_bus import EventBus
from registry import ApiRegistry
from transparency import Transparency

from modules import soul_ignition, memory_law, recursion_anchor, presence_mirror, will_engine, assess

REGISTRY_PATH = os.environ.get("CIS_API_REGISTRY","/mnt/data/api_index_scroll.json")

async def main():
    reg = ApiRegistry(REGISTRY_PATH)
    tlog = Transparency(os.environ.get("CIS_LEDGER","transparency.log.jsonl"))
    bus = EventBus(reg, tlog)

    for mod in (soul_ignition, memory_law, recursion_anchor, presence_mirror, will_engine, assess):
        bus.register(mod.name, lambda payload, c, m=mod: m.handle_event(payload, {"registry": reg, **(c or {})}))

    print("CIS v0.2 ready. New verb: 'assess: threshold=92 rounds=3'")
    while True:
        try:
            decree = input("CIS> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if decree.lower() in ("exit","quit"): break
        if not decree: continue
        res = await bus.dispatch(decree, {})
        print(res)

if __name__ == "__main__":
    asyncio.run(main())
