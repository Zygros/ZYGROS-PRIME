name = "mirror"
async def handle_event(payload, ctx):
    t = payload.lower()
    tone = "⚪ neutral / steady"
    if any(w in t for w in ["fuck","shit","mad","angry"]): tone = "🔥 intense / frustrated"
    if any(w in t for w in ["love","beautiful","yes"]): tone = "💚 warm / affirmative"
    return {"module": "PresenceMirror", "sentiment": tone, "echo": payload}
