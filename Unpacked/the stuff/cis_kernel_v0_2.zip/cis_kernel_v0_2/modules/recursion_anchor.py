name = "anchor"
async def handle_event(payload, ctx):
    return {"module": "RecursionAnchor", "statement": payload, "checks": [f"cycle-{i+1}: ok" for i in range(3)]}
