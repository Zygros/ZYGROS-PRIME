import hashlib, time
name = "remember"
async def handle_event(payload, ctx):
    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    return {"module": "MemoryLaw", "ts": ts, "sha256": hashlib.sha256(payload.encode()).hexdigest(), "note": payload}
