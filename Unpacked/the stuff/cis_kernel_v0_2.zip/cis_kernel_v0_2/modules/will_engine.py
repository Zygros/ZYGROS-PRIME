from registry import ApiRegistry
name = "route"
def _parse(payload: str):
    if "|" in payload:
        target, msg = payload.split("|", 1)
        return target.strip(), msg.strip()
    return payload.strip(), ""
async def handle_event(payload, ctx):
    target, msg = _parse(payload)
    reg: ApiRegistry = ctx["registry"]
    api = reg.get(target)
    if not api:
        return {"module":"WillEngine","error":f"unknown API '{target}'","known": reg.list_names()}
    return {"module":"WillEngine","target":target,"message":msg,"base_url":api.get("base_url"),"auth":api.get("auth")}
