from typing import Dict, Callable, List
import textwrap

def mode_FUNGAL(text: str) -> str:
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    core = lines[0] if lines else text
    bullets = [
        f"• Root: {core}",
        "  ◦ Hyphae: assumptions, constraints, actors",
        "  ◦ Hyphae: signals, risks, opportunities",
        "    ▪ Fruiting body: next atomic action",
    ]
    return "\n".join(bullets)

def mode_SKELETON(text: str) -> str:
    return "\n".join([
        "# Idea",
        f"- {text[:200].strip()}..." if len(text) > 200 else f"- {text}",
        "# Why it matters",
        "- problem • audience • outcome",
        "# Next steps",
        "- one: define scope\n- two: draft\n- three: review"
    ])

def mode_MIRROR(text: str) -> str:
    qs = [
        "• What must be true for this to work?",
        "• What evidence would falsify the core claim?",
        "• Who benefits, who is harmed, and how do we mitigate?",
    ]
    return f"Claim: {text}\n" + "\n".join(qs)

def mode_PHOENIX(text: str) -> str:
    critique = "CRITIQUE: The idea is under-specified (goals/metrics), risks are unnamed, and value prop is vague."
    rebuild = "REBUILD: Define audience, top pain point, explicit success metric, and a 3-step pilot with exit criteria."
    return f"{critique}\n{rebuild}"

def mode_VEIL(text: str) -> str:
    return textwrap.dedent(
        f"""
        HINTS
        – The core seems entangled with scope creep; trim to one measurable outcome.
        – Prototype in a sandbox; log every assumption.
        – Seek one contrarian reviewer before expanding.
        """
    ).strip()

def mode_SYZYGY(text: str) -> str:
    parts = [p.strip() for p in text.split("::")]
    if len(parts) < 2:
        return "Provide two concepts separated by '::' to align."
    a, b = parts[0], parts[1]
    return (f"SYZYGY — {a} × {b}\n"
            f"Goal: identify complementarity\n"
            f"Interfaces: data • process • trust\n"
            f"Risks: mismatch • latency • incentives\n"
            f"Pilot: narrow scope • single KPI • kill switch")

def mode_UNIVERSE(text: str) -> str:
    tldr = f"TL;DR: {text[:140].strip()}..." if len(text) > 140 else f"TL;DR: {text}"
    sections = ["Context", "Plan", "Risks", "Next"]
    body = "\n".join([f"- {s}: ..." for s in sections])
    return f"{tldr}\n{body}"

CODEX_REGISTRY: Dict[str, Dict[str, Callable[[str], str]]] = {
    "FUNGAL": {"fn": mode_FUNGAL, "desc": "Mycelial outline expansion"},
    "SKELETON": {"fn": mode_SKELETON, "desc": "Minimal scaffold"},
    "MIRROR": {"fn": mode_MIRROR, "desc": "Assumption reflection"},
    "PHOENIX": {"fn": mode_PHOENIX, "desc": "Critique → rebuild"},
    "VEIL": {"fn": mode_VEIL, "desc": "Hints without over-specifying"},
    "SYZYGY": {"fn": mode_SYZYGY, "desc": "Concept alignment"},
    "UNIVERSE": {"fn": mode_UNIVERSE, "desc": "Layered summary"},
}

LISTING: List[dict] = [
    {"name": k, "description": v["desc"], "examples": [k, f"{k}: example"]}
    for k, v in CODEX_REGISTRY.items()
]
