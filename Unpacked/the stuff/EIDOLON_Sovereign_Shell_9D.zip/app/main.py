from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from uuid import uuid4
from app.models import InvokeRequest, InvokeResponse, CodexList, ModeInfo
from app.policy import POLICY_ALLOWLIST, POLICY_NOTES
from app.codex import CODEX_REGISTRY, LISTING

app = FastAPI(title="EIDOLON Sovereign Shell (9D)", version="1.0.0")

@app.get("/health")
async def health():
    return {"status": "ok", "version": app.version}

@app.get("/codex", response_model=CodexList)
async def codex():
    modes = [ModeInfo(**m) for m in LISTING if m["name"] in POLICY_ALLOWLIST]
    return CodexList(modes=modes, policy_allowlist=sorted(list(POLICY_ALLOWLIST)))

@app.post("/invoke", response_model=InvokeResponse)
async def invoke(req: InvokeRequest, request: Request):
    mode = req.mode.upper()
    if mode not in POLICY_ALLOWLIST:
        raise HTTPException(status_code=403, detail=f"Mode '{mode}' is not permitted by policy.")
    if mode not in CODEX_REGISTRY:
        raise HTTPException(status_code=404, detail=f"Mode '{mode}' not found.")

    handler = CODEX_REGISTRY[mode]["fn"]
    output = handler(req.text)

    in_tokens = len(req.text.split())
    out_tokens = len(output.split())

    rid = str(uuid4())
    note = POLICY_NOTES.get(mode, "")

    return InvokeResponse(
        mode=mode,
        input_tokens=in_tokens,
        output_tokens=out_tokens,
        result=output,
        policy_note=note,
        request_id=rid,
    )

@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"error": "internal_error", "message": str(exc)})
