from typing import Set

POLICY_ALLOWLIST: Set[str] = {
    "FUNGAL",
    "SKELETON",
    "MIRROR",
    "PHOENIX",
    "VEIL",
    "SYZYGY",
    "UNIVERSE"
}

POLICY_NOTES = {
    "FUNGAL": "Expands into interconnected bullet clusters; no claims of hidden data.",
    "SKELETON": "Strips to headings and bullet points only; no new facts.",
    "MIRROR": "Reflects and challenges assumptions without adding unverifiable claims.",
    "PHOENIX": "Performs a two-step: critique then a safer rewrite.",
    "VEIL": "Provides suggestive hints; avoids sensitive/unsafe specifics.",
    "SYZYGY": "Joins two provided concepts; does not invent third-party assertions.",
    "UNIVERSE": "Multi-layer summary (tl;dr → details) with careful hedging."
}
