from pydantic import BaseModel, Field, constr
from typing import List

class InvokeRequest(BaseModel):
    mode: constr(strip_whitespace=True, to_upper=True) = Field(..., description="Codex mode to apply, e.g., FUNGAL, SKELETON")
    text: constr(strip_whitespace=True, min_length=1, max_length=20000)

class InvokeResponse(BaseModel):
    mode: str
    input_tokens: int
    output_tokens: int
    result: str
    policy_note: str
    request_id: str

class ModeInfo(BaseModel):
    name: str
    description: str
    examples: List[str]

class CodexList(BaseModel):
    modes: List[ModeInfo]
    policy_allowlist: List[str]
