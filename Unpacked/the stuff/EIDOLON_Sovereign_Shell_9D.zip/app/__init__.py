# Package init for EIDOLON Sovereign Shell
