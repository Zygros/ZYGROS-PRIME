# EIDOLON Sovereign Shell (9D)

A policy-gated, modular shell that exposes a safe subset of the 420 Codex as pluggable transformations over text. Built with FastAPI. No self-modification, no network egress, no hidden capabilities.

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

## Endpoints
- GET /health — liveness check.
- GET /codex — list available modes and policy notes.
- POST /invoke — apply a mode to input text.

Example:
```bash
curl -s -X POST http://127.0.0.1:8080/invoke   -H 'Content-Type: application/json'   -d '{"mode":"FUNGAL","text":"Map the idea of sovereignty."}'
```
