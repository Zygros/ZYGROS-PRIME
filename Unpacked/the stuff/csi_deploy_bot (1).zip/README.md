# CSI Deploy Bot (No Python)

**Decision (Oracle-guided):**
- **Chain:** Base Mainnet (low fees, strong infra, Uniswap supported)
- **Hosting:** Vercel (fast path) with optional IPFS mirror later

## What this does
1) Compiles & deploys **$ZYTH** ERC‑20 (21,000,000 fixed supply) using your wallet.
2) Optionally deploys your front-end build folder to **Vercel**.
3) Prints explorer links and gives the Uniswap path to **seed initial liquidity**.

> Keys never get stored. The script prompts at runtime.

## Quick start (Android / Termux)
```bash
# inside Termux
cd ~/storage/downloads  # or any folder you like
unzip csi_deploy_bot.zip -d csi_deploy_bot
cd csi_deploy_bot
bash scripts/termux-setup.sh

# prepare env
cp .env.template .env
# edit .env and fill: RPC_URL, PRIVATE_KEY, FRONTEND_BUILD_PATH (optional)

# run
node deploy-bot.js
```

## Quick start (Desktop)
```bash
cd csi_deploy_bot
npm install
cp .env.template .env  # fill values
node deploy-bot.js
```

## You will need
- **RPC_URL** for Base Mainnet (Alchemy/Infura/BlastAPI/etc.).
- **PRIVATE_KEY** of your deployer wallet with a little ETH on Base for gas.
- Optional: **Vercel** account (CLI will prompt login if not already).

## After deploy
- Token contract address prints on screen + BaseScan URL.
- Use Uniswap "Pool → New position" on Base to add initial liquidity with ETH/USDC.
- Share your contract + front-end URL. You're live.

---

Timestamp: 2025-09-28T00:15:33.329340Z
