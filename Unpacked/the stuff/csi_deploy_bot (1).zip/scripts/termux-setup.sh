#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install -y nodejs git
cd "$(dirname "$0")"
npm install
echo ""
echo "Done. Put your values in .env (copy .env.template), then run:"
echo "  node deploy-bot.js"
