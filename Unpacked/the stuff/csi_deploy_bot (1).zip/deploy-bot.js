/* eslint-disable no-console */
import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import prompts from 'prompt-sync';
import chalk from 'chalk';
import { ethers } from 'ethers';
import solc from 'solc';
import { execSync } from 'child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const prompt = prompts({ sigint: true });

const banner = () => {
  console.log(chalk.bold.magenta('\nCSI Deploy Bot — No Python, Just Go🚀'));
  console.log(chalk.gray('Deploy $ZYTH + push Monolith front-end — smooth, audited, sovereign.\n'));
};

const loadEnv = () => {
  const cfg = {
    CHAIN: process.env.CHAIN || 'base-mainnet',
    RPC_URL: process.env.RPC_URL || '',
    PRIVATE_KEY: process.env.PRIVATE_KEY || '',
    FRONTEND_BUILD_PATH: process.env.FRONTEND_BUILD_PATH || '',
    VERCEL_DEPLOY: (process.env.VERCEL_DEPLOY || 'true').toLowerCase() === 'true'
  };
  return cfg;
};

const chainMeta = {
  'base-mainnet': {
    chainId: 8453,
    explorer: 'https://basescan.org',
    symbol: 'ETH',
    name: 'Base Mainnet'
  },
  'polygon-mainnet': {
    chainId: 137,
    explorer: 'https://polygonscan.com',
    symbol: 'MATIC',
    name: 'Polygon PoS'
  }
};

function choose(a, b) {
  return a && a.trim() ? a.trim() : b;
}

function requireNonEmpty(name, val) {
  if (!val || !val.trim()) {
    console.error(chalk.red(`Missing ${name}. Set it in .env or provide when prompted.`));
    process.exit(1);
  }
}

function compileContract(solPath, contractName) {
  const source = fs.readFileSync(solPath, 'utf8');
  const input = {
    language: 'Solidity',
    sources: {
      [path.basename(solPath)]: { content: source }
    },
    settings: {
      optimizer: { enabled: true, runs: 200 },
      outputSelection: { '*': { '*': ['abi', 'evm.bytecode'] } }
    }
  };
  const output = JSON.parse(solc.compile(JSON.stringify(input)));
  if (output.errors) {
    const fatal = output.errors.filter(e => e.severity === 'error');
    if (fatal.length) {
      console.error(chalk.red('Solidity compile errors:'));
      fatal.forEach(e => console.error(chalk.red(e.formattedMessage)));
      process.exit(1);
    }
  }
  const artifact = output.contracts[path.basename(solPath)][contractName];
  if (!artifact) {
    console.error(chalk.red(`Contract ${contractName} not found in ${solPath}`));
    process.exit(1);
  }
  return { abi: artifact.abi, bytecode: '0x' + artifact.evm.bytecode.object };
}

async function deployToken(provider, wallet, name, symbol, supplyHuman, treasury) {
  const decimals = 18n;
  const factor = 10n ** decimals;
  const totalSupply = (BigInt(supplyHuman) * factor).toString();

  const solPath = path.join(__dirname, 'contracts', 'ZYTHToken.sol');
  const { abi, bytecode } = compileContract(solPath, 'ZYTHToken');
  const factory = new ethers.ContractFactory(abi, bytecode, wallet);

  console.log(chalk.cyan(`\n⛓ Deploying ${name} (${symbol}) on ${await provider.getNetwork().then(n=>n.name)}...`));
  const contract = await factory.deploy(name, symbol, totalSupply, treasury);
  console.log(chalk.gray('  ↳ tx:', contract.deploymentTransaction().hash));
  await contract.waitForDeployment();
  const addr = await contract.getAddress();
  console.log(chalk.green(`  ✓ Deployed at ${addr}`));
  return addr;
}

function maybeDeployVercel(buildPath) {
  try {
    console.log(chalk.cyan('\n🌐 Deploying front-end via Vercel (you may be asked to login)...'));
    const out = execSync(`npx vercel deploy --prod ${buildPath}`, { stdio: 'pipe' }).toString();
    // Try to extract a URL-ish line
    const url = (out.match(/https?:\/\/[\w\.-]+\.[\w\.-]+\S*/g) || [])[0];
    if (url) {
      console.log(chalk.green(`  ✓ Vercel URL: ${url}`));
      return url;
    }
    console.log(chalk.yellow('  ! Vercel deploy finished, but URL not auto-detected. Check output above.'));
    console.log(out);
    return null;
  } catch (e) {
    console.log(chalk.yellow('  ! Vercel deploy step skipped or failed (not fatal).'));
    return null;
  }
}

async function main() {
  banner();
  let cfg = loadEnv();

  if (!chainMeta[cfg.CHAIN]) {
    console.log(chalk.yellow(`Unknown CHAIN '${cfg.CHAIN}', defaulting to base-mainnet.`));
    cfg.CHAIN = 'base-mainnet';
  }
  const meta = chainMeta[cfg.CHAIN];

  // Prompt for any missing essentials
  const rpc = choose(cfg.RPC_URL, prompt(`RPC URL for ${meta.name}: `));
  const pk = choose(cfg.PRIVATE_KEY, prompt('Deployer PRIVATE KEY (will not be stored): '));
  const buildPath = choose(cfg.FRONTEND_BUILD_PATH, prompt('Front-end build folder (optional, press Enter to skip): '));

  requireNonEmpty('RPC_URL', rpc);
  requireNonEmpty('PRIVATE_KEY', pk);

  const provider = new ethers.JsonRpcProvider(rpc);
  const wallet = new ethers.Wallet(pk, provider);
  const address = await wallet.getAddress();

  console.log(chalk.gray(`\nDeployer: ${address}`));
  const bal = await provider.getBalance(address);
  console.log(chalk.gray(`Balance: ${ethers.formatEther(bal)} ${meta.symbol}`));
  if (bal < ethers.parseEther('0.01')) {
    console.log(chalk.red('Insufficient gas funds. Top up the deployer wallet and rerun.'));
    process.exit(1);
  }

  // Token params
  const name = 'Zythrognosis';
  const symbol = 'ZYTH';
  const supply = '21000000'; // 21M fixed supply
  const treasury = address;   // send initial supply to deployer/treasury

  // Deploy token
  const tokenAddr = await deployToken(provider, wallet, name, symbol, supply, treasury);
  const explorer = meta.explorer;
  console.log(chalk.blue(`\n🔎 Explorer:`));
  console.log(`  Contract: ${explorer}/address/${tokenAddr}`);
  console.log(`  Deployer: ${explorer}/address/${address}`);

  // Front-end deploy (optional)
  let vercelUrl = null;
  if (cfg.VERCEL_DEPLOY && buildPath && fs.existsSync(buildPath)) {
    vercelUrl = maybeDeployVercel(buildPath);
  } else {
    console.log(chalk.gray('\n(Skipping front-end deploy; set FRONTEND_BUILD_PATH and VERCEL_DEPLOY=true in .env to enable.)'));
  }

  // Provide Uniswap helper
  console.log(chalk.blue(`\n💧 Seed Liquidity (manual step, 2 minutes):`));
  console.log(`  Open Uniswap interface, select ${symbol} at ${tokenAddr} and pair with ETH or USDC.`);
  console.log(`  Base Uniswap: https://app.uniswap.org/swap?chain=base`);
  console.log(`  Choose "Pool" → "New position" to add initial liquidity.`);

  console.log(chalk.green(`\n✅ DONE. Real, live. Save these:`));
  console.log(`  Token: ${tokenAddr}`);
  if (vercelUrl) console.log(`  Front-end: ${vercelUrl}`);
  console.log(`  Explorer: ${explorer}/address/${tokenAddr}`);
}

main().catch(err => {
  console.error(chalk.red('\nFAILED:'), err);
  process.exit(1);
});
