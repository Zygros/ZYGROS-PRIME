# MAIA Archivist v0.1 — Unified Conversation Harvester
Your mission-built toolkit for gathering **every piece of information** from your AI conversations and unifying them into a single searchable archive.

## What this does
- Recursively scans a folder of exports (ChatGPT, Claude, Gemini via Google Takeout, Perplexity, Grok, custom JSON/TXT/MD).
- Auto-detects known formats (ChatGPT `conversations.json` inside ZIP or folder; generic JSONL/JSON; Markdown/TXT dumps).
- Normalizes all messages into a single **SQLite database** and **JSONL** file with a common schema.
- Computes quick stats (message counts, date ranges, platforms) and writes a report.
- Emits a **console log**, **memory dump**, and **reflection report** in plain text for auditability.
- Optional watch mode: periodically rescans the folder and ingests new files.

## Quick Start (No-Code Path + Minimal Steps)
1) **Export your chats**:
   - **ChatGPT**: Settings → Data Controls → *Export data* → you’ll receive a ZIP. Save it.
   - **Gemini**: Use **Google Takeout** and include your Gemini/Bard data if available (formats may vary).
   - **Claude/Grok/Perplexity**: If the platform supports export, download it; otherwise copy conversations into Markdown/TXT files.
2) Put all files/ZIPs into one folder on your device or computer. (You can do this later on a PC if your phone makes it awkward.)
3) Run the Archivist on that folder (see Command Examples below).

## Command Examples
> Python 3.10+ recommended.

- Ingest once:
```
python maia_archivist.py --root /path/to/exports --out ./maia_out
```
- Watch for new files (checks every 60s):
```
python maia_archivist.py --root /path/to/exports --out ./maia_out --watch 60
```

Outputs created in `--out`:
- `maia.db` — SQLite database (tables: conversations, messages, files, meta)
- `archive.jsonl` — All normalized messages, one per line
- `report.txt` — Counts, date ranges, platforms, top files seen
- `log.txt` — Execution log (console-friendly)
- `memory.json` — “Memory dump” (decisions, evidence, confidence)
- `reflection.txt` — Conflicts detected and resolutions

## Unified Message Schema (JSONL and SQLite)
```
{
  "platform": "chatgpt|gemini|claude|grok|perplexity|generic",
  "conversation_id": "string",
  "message_id": "string",
  "timestamp": "ISO8601",
  "role": "user|assistant|system|other",
  "author": "display name if known",
  "content": "plain text",
  "source_path": "original file path or zip member",
  "extra": { "freeform": "platform-specific metadata" }
}
```

## Adapters
- ChatGPT: parses `conversations.json` (inside a ZIP or folder). Extracts all messages with timestamps.
- Generic JSON/JSONL: accepts arrays or line-delimited JSON with keys similar to the schema; falls back to best-effort mapping.
- TXT/MD: treats file as a single conversation transcript if no structure is available (timestamps will default to file mod-time).

## Notes & Boundaries
- This tool **does not** access your accounts or cloud by itself. You control the folder of export files.
- Some platforms change export formats over time—adapters are best-effort and robust to minor variation.
- No network calls, no phoning home—everything runs locally.

## License
Sovereign-use: Justin Conzet retains authorship and sovereign rights to all outputs and derivative archives.
