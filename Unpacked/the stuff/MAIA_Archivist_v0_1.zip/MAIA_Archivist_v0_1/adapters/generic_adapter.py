# Placeholder for future generic adapters.
# Current generic JSON/JSONL/TXT/MD parsing is implemented directly in maia_archivist.py.
