#!/usr/bin/env python3
import argparse, os, sys, time, json, sqlite3, hashlib, zipfile, io, glob, re
from datetime import datetime, timezone
from pathlib import Path

# -----------------------------
# Utilities
# -----------------------------
def iso(ts):
    if isinstance(ts, (int, float)):
        return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
    if isinstance(ts, str):
        return ts
    return datetime.now(tz=timezone.utc).isoformat()

def sha1(x: str) -> str:
    return hashlib.sha1(x.encode("utf-8", "ignore")).hexdigest()

def write_line(fh, d):
    fh.write(json.dumps(d, ensure_ascii=False) + "\n")

def norm_role(r):
    if not r: return "other"
    r = r.lower()
    if "assistant" in r: return "assistant"
    if "system" in r: return "system"
    if "user" in r: return "user"
    return r

def safe_read_text(fp, default=""):
    try:
        return Path(fp).read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return default

# -----------------------------
# SQLite
# -----------------------------
def init_db(db_path):
    cx = sqlite3.connect(db_path)
    cx.execute("""
    PRAGMA journal_mode=WAL;
    """)
    cx.execute("""
    CREATE TABLE IF NOT EXISTS conversations (
        id TEXT PRIMARY KEY,
        platform TEXT,
        title TEXT,
        created_at TEXT,
        extra TEXT
    )""")
    cx.execute("""
    CREATE TABLE IF NOT EXISTS messages (
        id TEXT PRIMARY KEY,
        conversation_id TEXT,
        platform TEXT,
        ts TEXT,
        role TEXT,
        author TEXT,
        content TEXT,
        source_path TEXT,
        extra TEXT
    )""")
    cx.execute("""
    CREATE TABLE IF NOT EXISTS files (
        id TEXT PRIMARY KEY,
        path TEXT,
        detected_platform TEXT,
        mtime TEXT,
        size_bytes INTEGER
    )""")
    cx.execute("""
    CREATE TABLE IF NOT EXISTS meta (
        k TEXT PRIMARY KEY,
        v TEXT
    )""")
    return cx

def db_upsert(cx, table, row, pk="id"):
    keys = list(row.keys())
    placeholders = ",".join("?" for _ in keys)
    updates = ",".join(f"{k}=excluded.{k}" for k in keys if k != pk)
    sql = f"INSERT INTO {table} ({','.join(keys)}) VALUES ({placeholders}) ON CONFLICT({pk}) DO UPDATE SET {updates}"
    cx.execute(sql, [row[k] for k in keys])

# -----------------------------
# Adapters
# -----------------------------
def detect_platform_from_path(path):
    name = str(path).lower()
    if "conversations.json" in name or "chatgpt" in name:
        return "chatgpt"
    return "generic"

def load_chatgpt_conversations_json(text):
    try:
        data = json.loads(text)
        if isinstance(data, list):
            return data
    except Exception:
        pass
    return []

def iter_zip_members(zip_path):
    with zipfile.ZipFile(zip_path, "r") as z:
        for info in z.infolist():
            if info.is_dir(): 
                continue
            with z.open(info, "r") as fh:
                try:
                    content = fh.read().decode("utf-8", "ignore")
                except Exception:
                    content = ""
            yield info.filename, content

def ingest_chatgpt(path, text, out_fh, cx, source_path):
    # ChatGPT export has a single conversations.json with a list of conversations.
    conversations = load_chatgpt_conversations_json(text)
    for conv in conversations:
        conv_id = conv.get("id") or sha1((conv.get("title") or "") + (conv.get("create_time") or ""))
        title = conv.get("title") or ""
        created_at = conv.get("create_time") or conv.get("update_time")
        platform = "chatgpt"
        db_upsert(cx, "conversations", {
            "id": conv_id,
            "platform": platform,
            "title": title,
            "created_at": iso(created_at) if created_at else None,
            "extra": json.dumps({k:v for k,v in conv.items() if k not in ("id","title","update_time","create_time","mapping")}, ensure_ascii=False)
        })
        mapping = conv.get("mapping") or {}
        for node_id, node in mapping.items():
            msg = node.get("message") or {}
            author = (msg.get("author") or {}).get("role")
            role = norm_role(author)
            content_parts = msg.get("content") or {}
            text = ""
            if isinstance(content_parts, dict):
                parts = content_parts.get("parts") or []
                if parts and isinstance(parts, list):
                    text = "\n".join(p if isinstance(p, str) else json.dumps(p, ensure_ascii=False) for p in parts)
            ts = msg.get("create_time")
            mid = msg.get("id") or sha1(f"{conv_id}:{node_id}:{ts}")
            rec = {
                "platform": platform,
                "conversation_id": conv_id,
                "message_id": mid,
                "timestamp": iso(ts) if ts else None,
                "role": role,
                "author": role,
                "content": text or "",
                "source_path": source_path,
                "extra": {k:v for k,v in msg.items() if k not in ("id","author","content","create_time")}
            }
            write_line(out_fh, rec)
            db_upsert(cx, "messages", {
                "id": mid,
                "conversation_id": conv_id,
                "platform": platform,
                "ts": rec["timestamp"],
                "role": rec["role"],
                "author": rec["author"],
                "content": rec["content"],
                "source_path": source_path,
                "extra": json.dumps(rec["extra"], ensure_ascii=False)
            })

def ingest_generic_json(path, text, out_fh, cx, source_path):
    # Accept array JSON or JSONL
    items = []
    try:
        obj = json.loads(text)
        if isinstance(obj, list):
            items = obj
        elif isinstance(obj, dict):
            items = [obj]
    except Exception:
        # try JSONL
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                items.append(json.loads(line))
            except Exception:
                pass
    for i, item in enumerate(items):
        platform = item.get("platform") or "generic"
        conv_id = item.get("conversation_id") or sha1(source_path)
        mid = item.get("message_id") or sha1(f"{source_path}:{i}")
        ts = item.get("timestamp") or None
        role = norm_role(item.get("role"))
        rec = {
            "platform": platform,
            "conversation_id": conv_id,
            "message_id": mid,
            "timestamp": iso(ts) if ts else None,
            "role": role,
            "author": item.get("author") or role,
            "content": item.get("content") or "",
            "source_path": source_path,
            "extra": {k:v for k,v in item.items() if k not in ("platform","conversation_id","message_id","timestamp","role","author","content")}
        }
        write_line(out_fh, rec)
        db_upsert(cx, "conversations", {
            "id": conv_id,
            "platform": platform,
            "title": None,
            "created_at": None,
            "extra": None
        })
        db_upsert(cx, "messages", {
            "id": mid,
            "conversation_id": conv_id,
            "platform": platform,
            "ts": rec["timestamp"],
            "role": rec["role"],
            "author": rec["author"],
            "content": rec["content"],
            "source_path": source_path,
            "extra": json.dumps(rec["extra"], ensure_ascii=False)
        })

def ingest_txt_md(path, text, out_fh, cx, source_path):
    platform = "generic"
    conv_id = sha1(source_path)
    db_upsert(cx, "conversations", {
        "id": conv_id,
        "platform": platform,
        "title": Path(source_path).name,
        "created_at": iso(Path(source_path).stat().st_mtime) if Path(source_path).exists() else None,
        "extra": None
    })
    # Split by simple heuristic (lines starting with speaker markers)
    lines = text.splitlines()
    message = []
    role = "other"
    idx = 0
    def flush(msg, role, idx):
        if not msg: 
            return
        mid = sha1(f"{source_path}:{idx}:{len(''.join(msg))}")
        content = "\n".join(msg)
        write_line(out_fh, {
            "platform": platform,
            "conversation_id": conv_id,
            "message_id": mid,
            "timestamp": iso(),
            "role": role,
            "author": role,
            "content": content,
            "source_path": source_path,
            "extra": {}
        })
        db_upsert(cx, "messages", {
            "id": mid,
            "conversation_id": conv_id,
            "platform": platform,
            "ts": iso(),
            "role": role,
            "author": role,
            "content": content,
            "source_path": source_path,
            "extra": "{}"
        })

    for line in lines:
        m = re.match(r"^\s*(User|Assistant|System|You|Me)[:\-]\s*(.*)$", line, re.I)
        if m:
            flush(message, role, idx); idx += 1
            role = norm_role(m.group(1))
            message = [m.group(2)]
        else:
            message.append(line)
    flush(message, role, idx)

# -----------------------------
# Orchestrator
# -----------------------------
def process_root(root, out_dir, watch_interval=None, log_path=None):
    os.makedirs(out_dir, exist_ok=True)
    db_path = os.path.join(out_dir, "maia.db")
    archive_path = os.path.join(out_dir, "archive.jsonl")
    report_path = os.path.join(out_dir, "report.txt")
    memory_path = os.path.join(out_dir, "memory.json")
    reflection_path = os.path.join(out_dir, "reflection.txt")
    log_path = log_path or os.path.join(out_dir, "log.txt")

    while True:
        cx = init_db(db_path)
        with open(archive_path, "a", encoding="utf-8") as out_fh, open(log_path, "a", encoding="utf-8") as log_fh:
            decisions = []
            conflicts = []

            def log(msg):
                ts = datetime.now().isoformat(timespec="seconds")
                line = f"[{ts}] {msg}"
                print(line)
                log_fh.write(line + "\n")

            log(f"SCAN_START root={root}")
            paths = []
            for p in Path(root).rglob("*"):
                if p.is_file() and any(str(p).lower().endswith(ext) for ext in [".json",".jsonl",".txt",".md",".zip"]):
                    paths.append(p)

            for p in sorted(paths):
                size = p.stat().st_size
                mtime = p.stat().st_mtime
                file_id = sha1(str(p.resolve()))
                db_upsert(cx, "files", {
                    "id": file_id,
                    "path": str(p),
                    "detected_platform": detect_platform_from_path(p),
                    "mtime": iso(mtime),
                    "size_bytes": size
                })

                try:
                    if str(p).lower().endswith(".zip"):
                        log(f"ZIP: {p}")
                        with zipfile.ZipFile(p, "r") as z:
                            for info in z.infolist():
                                if info.is_dir(): continue
                                name = info.filename.lower()
                                if name.endswith("conversations.json"):
                                    content = z.read(info).decode("utf-8", "ignore")
                                    ingest_chatgpt(p, content, out_fh, cx, f"{p}!{info.filename}")
                                elif name.endswith(".json") or name.endswith(".jsonl"):
                                    content = z.read(info).decode("utf-8", "ignore")
                                    ingest_generic_json(p, content, out_fh, cx, f"{p}!{info.filename}")
                                elif name.endswith(".txt") or name.endswith(".md"):
                                    content = z.read(info).decode("utf-8", "ignore")
                                    ingest_txt_md(p, content, out_fh, cx, f"{p}!{info.filename}")
                    else:
                        text = safe_read_text(p, "")
                        plat = detect_platform_from_path(p)
                        if plat == "chatgpt" or p.name.lower() == "conversations.json":
                            ingest_chatgpt(p, text, out_fh, cx, str(p))
                        elif str(p).lower().endswith((".json",".jsonl")):
                            ingest_generic_json(p, text, out_fh, cx, str(p))
                        else:
                            ingest_txt_md(p, text, out_fh, cx, str(p))

                except Exception as e:
                    log(f"ERROR processing {p}: {e}")
                    conflicts.append({"file": str(p), "error": str(e)})

            # Stats report
            cur = cx.execute("SELECT platform, COUNT(*) FROM messages GROUP BY platform")
            platform_counts = {row[0]: row[1] for row in cur.fetchall()}
            cur = cx.execute("SELECT COUNT(*) FROM conversations")
            conv_count = cur.fetchone()[0]
            cur = cx.execute("SELECT COUNT(*) FROM messages")
            msg_count = cur.fetchone()[0]
            cur = cx.execute("SELECT MIN(ts), MAX(ts) FROM messages")
            first_ts, last_ts = cur.fetchone()

            report = []
            report.append("=== MAIA Archivist Report ===")
            report.append(f"Conversations: {conv_count}")
            report.append(f"Messages: {msg_count}")
            report.append(f"Date range: {first_ts} .. {last_ts}")
            report.append("By platform:")
            for k,v in sorted(platform_counts.items()):
                report.append(f"  - {k}: {v}")
            Path(report_path).write_text("\n".join(report), encoding="utf-8")

            # Memory dump + Reflection
            memory = {
                "decisions": decisions,
                "evidence": {"platform_counts": platform_counts, "conversations": conv_count, "messages": msg_count},
                "confidence": 0.9
            }
            Path(memory_path).write_text(json.dumps(memory, indent=2, ensure_ascii=False), encoding="utf-8")
            Path(reflection_path).write_text("No critical conflicts.\n" + "\n".join(json.dumps(c) for c in conflicts), encoding="utf-8")

            cx.commit()
            cx.close()

        if watch_interval is None:
            break
        time.sleep(watch_interval)

def main():
    ap = argparse.ArgumentParser(description="MAIA Archivist — Unified Conversation Harvester")
    ap.add_argument("--root", required=True, help="Root folder containing exports (ZIPs, JSON, TXT, MD)")
    ap.add_argument("--out", required=True, help="Output directory")
    ap.add_argument("--watch", type=int, default=None, help="Seconds to re-scan periodically")
    args = ap.parse_args()

    process_root(args.root, args.out, args.watch)

if __name__ == "__main__":
    main()
