import os, httpx
from typing import Any, Dict

LIVE = os.getenv("CIS_LIVE_CALLS","0") == "1"

def _headers(auth: Dict[str, Any]) -> Dict[str, str]:
    if not auth: return {}
    if isinstance(auth.get("headers"), list):
        out = {}
        for h in auth["headers"]:
            if ":" in h:
                k,v = h.split(":",1)
                out[k.strip()] = v.strip()
        return out
    if isinstance(auth.get("header"), str) and ":" in auth["header"]:
        k,v = auth["header"].split(":",1)
        return {k.strip(): v.strip()}
    return {}

async def call(api: Dict[str, Any], path: str, method="GET", json_body=None):
    base = (api.get("base_url") or "").rstrip("/")
    url = f"{base}/{path.lstrip('/')}"
    headers = _headers(api.get("auth",{}))
    if not LIVE:
        return {"dry_run": True, "url": url, "method": method, "headers": headers, "json": json_body}
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.request(method, url, headers=headers, json=json_body)
        payload = r.text
        ctype = r.headers.get("content-type","")
        if "application/json" in ctype:
            try: payload = r.json()
            except: pass
        return {"status": r.status_code, "headers": dict(r.headers), "body": payload}
