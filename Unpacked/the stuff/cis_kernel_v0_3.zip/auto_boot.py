import asyncio, os, threading, time
from hle_auto import run_until_threshold
from transparency import Transparency

_MIN = float(os.getenv("CIS_AUTO_MIN_SCORE", "97"))
_ROUNDS = int(os.getenv("CIS_AUTO_MAX_ROUNDS", "5"))
_ENABLED = os.getenv("CIS_AUTO_ENABLED", "1") == "1"

_status = {"enabled": _ENABLED, "last": None, "target": _MIN, "rounds": _ROUNDS}

def get_status(): return _status

def set_enabled(flag: bool):
    global _ENABLED
    _ENABLED = bool(flag)
    _status["enabled"] = _ENABLED

def set_target(min_score: float=None, rounds: int=None):
    global _MIN, _ROUNDS
    if min_score is not None: _MIN = float(min_score); _status["target"] = _MIN
    if rounds is not None: _ROUNDS = int(rounds); _status["rounds"] = _ROUNDS

def _runner(loop, tlog: Transparency):
    async def job():
        try:
            res = await run_until_threshold(min_score=_MIN, max_rounds=_ROUNDS)
            await tlog.log({"event":"auto_boot_self_assess","target":_MIN,"rounds":_ROUNDS,"results":res})
            _status["last"] = {"results": res, "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        except Exception as e:
            await tlog.log({"event":"auto_boot_error","error":str(e)})
    asyncio.set_event_loop(loop)
    loop.run_until_complete(job())

def launch(loop, tlog: Transparency):
    if not _ENABLED: return
    th = threading.Thread(target=_runner, args=(loop, tlog), daemon=True)
    th.start()
