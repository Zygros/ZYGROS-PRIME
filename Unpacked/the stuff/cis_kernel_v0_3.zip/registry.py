import json, os
from typing import Any, Dict, Optional

class ApiRegistry:
    def __init__(self, path: str):
        self.path = path
        self._data: Dict[str, Any] = {}
        self._mtime = 0.0
        self.reload()

    def reload(self):
        if not os.path.exists(self.path):
            self._data = {"apis": []}
            return
        st = os.stat(self.path)
        if st.st_mtime <= self._mtime and self._data:
            return
        with open(self.path, "r") as f:
            self._data = json.load(f)
        self._mtime = st.st_mtime

    def get(self, name: str) -> Optional[Dict[str, Any]]:
        self.reload()
        for api in self._data.get("apis", []):
            if api.get("name","").lower() == name.lower():
                return api
        return None

    def list_names(self):
        self.reload()
        return [a.get("name") for a in self._data.get("apis", [])]
