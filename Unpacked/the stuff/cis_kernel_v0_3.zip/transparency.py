import json, time, hashlib, os

class Transparency:
    def __init__(self, path="transparency.log.jsonl"):
        self.path = path
        if not os.path.exists(self.path):
            open(self.path, "w").close()

    async def log(self, entry):
        entry = dict(entry)
        entry["ts"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        blob = json.dumps(entry, sort_keys=True).encode("utf-8")
        entry["sha256"] = hashlib.sha256(blob).hexdigest()
        with open(self.path, "a") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
