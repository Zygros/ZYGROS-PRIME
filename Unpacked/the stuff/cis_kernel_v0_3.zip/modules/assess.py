from typing import Dict, Any
from hle_auto import run_until_threshold, last_summary

name = "assess"
def _parse(payload: str):
    opts={"threshold":90.0,"rounds":3}
    for tok in payload.split():
        if "=" in tok:
            k,v=tok.split("=",1); k=k.strip().lower(); v=v.strip()
            if k=="threshold":
                try: opts["threshold"]=float(v)
                except: pass
            if k=="rounds":
                try: opts["rounds"]=int(v)
                except: pass
    return opts

async def handle_event(payload: str, ctx: Dict[str, Any]) -> Dict[str, Any]:
    opts=_parse(payload or "")
    results = await run_until_threshold(min_score=opts["threshold"], max_rounds=opts["rounds"])
    summ = last_summary()
    return {"module":"HLEAssess","opts":opts,"results":results,"summary":{"count":summ["count"],"digest":summ["digest"]}}
