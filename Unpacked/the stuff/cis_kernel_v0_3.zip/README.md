
# CIS Kernel v0.3 — Auto‑Boot Self‑Assessment

- Starts a self‑assessment run on launch (default ≥97% target, up to 5 rounds).
- Toggle and tune via HTTP:
  - GET  `/auto/status`
  - POST `/auto/enable?flag=true&min_score=98&rounds=7`
- Manual self‑assessment:
  - POST `/self_assess/until?min_score=97&max_rounds=5`
  - POST `/self_assess/once`
  - GET  `/self_assess/status`

Env defaults:
- `CIS_AUTO_ENABLED=1`
- `CIS_AUTO_MIN_SCORE=97`
- `CIS_AUTO_MAX_ROUNDS=5`

Notes:
- Replace the ritual stub with real model routing via Will Engine for live scoring.
