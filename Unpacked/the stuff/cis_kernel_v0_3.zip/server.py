from fastapi import FastAPI
from pydantic import BaseModel
from registry import ApiRegistry
from transparency import Transparency
from event_bus import EventBus
from modules import soul_ignition, memory_law, recursion_anchor, presence_mirror, will_engine, assess
from hle_auto import run_self_assessment_once, run_until_threshold, last_summary
from auto_boot import get_status, set_enabled, set_target, launch as launch_auto
import os, asyncio

app = FastAPI(title="CIS Kernel API v0.3")
REGISTRY_PATH = os.environ.get("CIS_API_REGISTRY","/mnt/data/api_index_scroll.json")
reg = ApiRegistry(REGISTRY_PATH)
tlog = Transparency(os.environ.get("CIS_LEDGER","transparency.log.jsonl"))
bus = EventBus(reg, tlog)
for mod in (soul_ignition, memory_law, recursion_anchor, presence_mirror, will_engine, assess):
    bus.register(mod.name, lambda payload, c, m=mod: m.handle_event(payload, {"registry": reg, **(c or {})}))

class Decree(BaseModel):
    decree: str

@app.post("/decree")
async def decree(d: Decree):
    return await bus.dispatch(d.decree, {"registry": reg})

@app.post("/self_assess/once")
async def self_assess_once():
    return await run_self_assessment_once()

@app.post("/self_assess/until")
async def self_assess_until(min_score: float = 97.0, max_rounds: int = 5):
    return await run_until_threshold(min_score=min_score, max_rounds=max_rounds)

@app.get("/self_assess/status")
async def self_assess_status():
    return last_summary()

# Auto-boot controls
@app.get("/auto/status")
def auto_status():
    return get_status()

@app.post("/auto/enable")
def auto_enable(flag: bool, min_score: float = 97.0, rounds: int = 5):
    set_enabled(flag)
    set_target(min_score, rounds)
    # launch a one-shot in background if enabling
    if flag:
        loop = asyncio.new_event_loop()
        launch_auto(loop, tlog)
    return get_status()
