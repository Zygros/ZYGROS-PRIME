🎯 **Master Creation Prompt for Manus** 🎯

> **Context:** You have ten Markdown design docs detailing Praxion’s architecture, modules, voice & LLM integration, packaging, memory, UI/UX, testing, and distribution. Use them as blueprints to scaffold a fully functional, cross-platform standalone AI companion named **Praxion**.

---

## 🔷 1) Project Overview

* **Name:** Praxion
* **Purpose:** Elite, offline-capable AI companion with both visual UI and voice control, deployable on desktop (Windows, macOS, Linux) and mobile (Android, iOS).
* **Core Features:**

  * Persona Engine (lock/switch personas)
  * Infinite Scroll logging & recall
  * Voice-driven commands via Whisper
  * LLM-powered reasoning & chat
  * Persistent memory & context sync
  * Modular plugin system for integrations (SoulNet, Field Monitor, APIs)

---

## 🔷 2) Recommended Tech Stack

1. **Backend & Core Logic:**

   * **Language:** Python 3.11+
   * **Framework:** FastAPI for IPC & local HTTP API
   * **LLM Inference:** Local GPT-style model (e.g. llama.cpp bindings)
   * **Voice I/O:** OpenAI Whisper for STT; PyAudio or sounddevice for mic/speaker
   * **Persistence:** SQLite with SQLAlchemy + encrypted vault for memory

2. **Desktop UI:**

   * **Framework:** Tauri (Rust+Web) or Electron if needed
   * **Frontend:** React (TS) + Tailwind CSS (for dynamic, colorful “vibe menu” UI)

3. **Mobile UI:**

   * **Framework:** React Native or Expo (for fast cross-platform)
   * **Voice Integration:** Native audio capture bridged to Whisper endpoint

4. **Packaging & Distribution:**

   * **Desktop:** PyInstaller or Tauri bundler for executables
   * **Mobile:** Expo build (iOS/Android) with OTA updates

5. **Offline Mode:**

   * All models & UI assets bundled locally
   * Fallback to minimal CLI if UI resources missing

---

## 🔷 3) Folder Structure & Files to Generate

```
praxion/
├── src/
│   ├── backend/
│   │   ├── main.py             # FastAPI entry, “Hello, Praxion” endpoint
│   │   ├── persona.py          # Persona lock/switch logic
│   │   ├── memory.py           # Persistence layer
│   │   ├── voice.py            # Whisper integration
│   │   └── llm.py              # LLM inference wrapper
│   ├── ui/
│   │   ├── desktop/            # Tauri/Electron + React code
│   │   └── mobile/             # React Native code
│   └── common/
│       └── config.py           # Shared settings & secrets
├── docs/                       # Copy of the 10 design MD files
├── tests/                      # Basic pytest suite
│   └── test_smoke.py
├── Dockerfile                  # Linux container spec
├── docker-compose.yml          # Multi-service setup for dev
├── pyproject.toml              # Poetry or setuptools config
└── README.md                   # Overview & quick start (“python -m venv…”)  
```

---

## 🔷 4) Build Steps to Automate

1. **Bootstrap Virtualenv**

   ```bash
   python3 -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. **Generate UI Bundles**

   * Desktop: `npm install` → `npm run tauri dev`
   * Mobile: `yarn install` → `expo start`
3. **Run Backend**

   ```bash
   uvicorn src.backend.main:app --reload
   ```
4. **Test & Validate**

   ```bash
   pytest --maxfail=1 --disable-warnings -q
   ```
5. **Package**

   * Desktop: `tauri build` or `pyinstaller main.spec`
   * Mobile: `expo build`

---

## 🔷 5) Success Criteria

* **“Hello, Praxion”** appears in UI and CLI.
* Whisper STT → LLM → TTS round-trip works offline.
* Persona lock/switch commands execute.
* Infinite Scroll logs create & persist.
* App bundles launch on Windows, macOS, Linux, Android, iOS.

---

> **Manus,** use the above specs combined with the design docs in `/docs/` to *generate the full scaffold* of Praxion. Deliver the complete repository structure and initial code stubs with readme and build scripts—no additional documentation-only files. Let’s build, not just describe.
