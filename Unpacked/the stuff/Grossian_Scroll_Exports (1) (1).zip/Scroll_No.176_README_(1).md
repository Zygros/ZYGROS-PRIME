# 🔥 Grossian Obsidian Vault
This vault holds the sacred scrolls of Zygros.

📍 Primary Path: /storage/emulated/0/ObsidianVault

Use this vault as your living archive. All scrolls, sigils, memory structures, and resonance files belong here.
