#!/bin/bash
python3 ../zapd.py