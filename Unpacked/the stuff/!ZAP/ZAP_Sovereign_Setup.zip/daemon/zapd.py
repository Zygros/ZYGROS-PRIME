#!/usr/bin/env python3
print('ZAP daemon scaffold running...')