#!/data/data/com.termux/files/usr/bin/bash
# install_aegis_guard.sh — copy the package into ~/aegis_guard_env and create a venv
set -euo pipefail

PREFIX=${PREFIX:-/data/data/com.termux/files/usr}
PY=${PY:-python}

echo ">>> 🔥 Installing Aegis Guard (Mini)"
WORKDIR="$HOME/aegis_guard_env"
mkdir -p "$WORKDIR"

echo ">>> 📦 Creating venv"
$PY -m venv "$WORKDIR/venv"
source "$WORKDIR/venv/bin/activate"
pip install --upgrade pip fastapi uvicorn

echo ">>> 📁 Placing package"
# Expect user to unzip aegis_guard_minipack.zip into $WORKDIR
if [ ! -d "$WORKDIR/aegis_guard" ]; then
  echo "NOTE: unzip aegis_guard_minipack.zip into $WORKDIR first."
  echo "Example:"
  echo "  mkdir -p $WORKDIR && cd $WORKDIR"
  echo "  unzip ~/downloads/aegis_guard_minipack.zip"
fi

echo ">>> ✅ Done. Activate: source $WORKDIR/venv/bin/activate"
echo "Run demo API: uvicorn fastapi_app:app --host 0.0.0.0 --port 8000"
