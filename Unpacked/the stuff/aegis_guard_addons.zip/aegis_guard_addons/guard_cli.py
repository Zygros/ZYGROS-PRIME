# guard_cli.py
# Usage: python guard_cli.py "your prompt here"
import sys
from aegis_guard import AegisGuard, GuardConfig, DefaultPolicy

def fake_model(prompt: str) -> str:
    # Replace with your model call
    return "Response: " + prompt[:80]

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python guard_cli.py "your prompt"")
        raise SystemExit(2)
    prompt = sys.argv[1]
    guard = AegisGuard(GuardConfig(policy=DefaultPolicy(), log_path="aegis_cli_logs.jsonl"))
    res = guard.guarded_chat(prompt, fake_model)
    print(res)
