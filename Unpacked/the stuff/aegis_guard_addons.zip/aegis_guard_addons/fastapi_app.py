# fastapi_app.py
# Minimal FastAPI server that guards incoming prompts and model responses.
# Run: uvicorn fastapi_app:app --host 0.0.0.0 --port 8000

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Any, Dict
from aegis_guard import AegisGuard, GuardConfig, DefaultPolicy

app = FastAPI(title="Aegis Guarded LLM API")
guard = AegisGuard(GuardConfig(policy=DefaultPolicy(), log_path="aegis_api_logs.jsonl"))

class ChatIn(BaseModel):
    prompt: str

class ChatOut(BaseModel):
    ok: bool
    response: str = ""
    risk: list[str] = []
    actions: list[str] = []
    canary: str = ""

def call_model(prompt: str) -> str:
    # TODO: replace with your actual LLM call
    return "OK. (no secrets here)"

@app.post("/chat", response_model=ChatOut)
def chat(inp: ChatIn):
    result = guard.guarded_chat(inp.prompt, call_model)
    if not result.get("ok"):
        # If blocked, still return structured details for the caller
        return ChatOut(ok=False, response=result.get("sanitized", ""), risk=result.get("risk", []), actions=result.get("actions", []))
    return ChatOut(ok=True, response=result["response"], risk=result["risk"], actions=result["actions"], canary=result["canary"])
