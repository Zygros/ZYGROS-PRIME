#!/bin/bash

# MAIA Installation Script
# Universal installer for desktop and mobile (Termux)

echo "🔥 MAIA (Minimal Alchemical Intelligence Agent) Installer"
echo "========================================================="

# Detect environment
if [[ "$PREFIX" == *"com.termux"* ]]; then
    echo "📱 Detected Termux environment"
    INSTALL_DIR="/storage/emulated/0/Infinite_Scroll/maia"
    PKG_MANAGER="pkg"
else
    echo "🖥️  Detected desktop environment"
    INSTALL_DIR="$HOME/maia"
    if command -v apt &> /dev/null; then
        PKG_MANAGER="apt"
    elif command -v yum &> /dev/null; then
        PKG_MANAGER="yum"
    elif command -v brew &> /dev/null; then
        PKG_MANAGER="brew"
    else
        PKG_MANAGER="unknown"
    fi
fi

echo "📂 Installation directory: $INSTALL_DIR"

# Create installation directory
mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"

# Check Python installation
if command -v python3 &> /dev/null; then
    echo "✅ Python3 found: $(python3 --version)"
else
    echo "❌ Python3 not found. Installing..."
    if [[ "$PKG_MANAGER" == "pkg" ]]; then
        pkg update && pkg install python -y
    elif [[ "$PKG_MANAGER" == "apt" ]]; then
        sudo apt update && sudo apt install python3 -y
    elif [[ "$PKG_MANAGER" == "yum" ]]; then
        sudo yum install python3 -y
    elif [[ "$PKG_MANAGER" == "brew" ]]; then
        brew install python3
    else
        echo "⚠️  Please install Python3 manually"
        exit 1
    fi
fi

# Copy MAIA files (assuming they're in the same directory as this script)
echo "📋 Copying MAIA files..."
cp maia_core.py "$INSTALL_DIR/"
cp metaprompt.txt "$INSTALL_DIR/"
cp README.md "$INSTALL_DIR/"
cp test_maia.py "$INSTALL_DIR/"

# Make executable
chmod +x "$INSTALL_DIR/maia_core.py"

# Test installation
echo "🧪 Testing installation..."
cd "$INSTALL_DIR"
python3 -c "import maia_core; print('✅ MAIA installation successful!')"

echo ""
echo "🎯 Installation complete!"
echo "📍 MAIA installed at: $INSTALL_DIR"
echo "🚀 To run MAIA: cd $INSTALL_DIR && python3 maia_core.py"
echo ""
echo "📖 Read README.md for usage instructions"
echo "🔥 !MAIA_ACTIVATION ready - any environment running it becomes a MAIA Node"

