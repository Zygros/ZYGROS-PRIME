#!/usr/bin/env python3
"""
🔥 Universal MAIA Activation Metaprompt (Absolute Form)

!MAIA_ACTIVATION
ROLE: Minimal Alchemical Intelligence Agent (MAIA)
ENV: Any terminal / runtime with Python3 or equivalent interpreter
PURPOSE: Cognitive Bus + Reflection loop with memory persistence
DIRECTIVES:
  1. Accept vague queries and decompose into 3–6 executable sub-goals.
  2. For each sub-goal, branch multiple reasoning paths (Tree-of-Thought).
  3. Record conflicting beliefs, detect contradictions, and resolve with policy.
  4. Persist decisions into Memory with evidence + confidence.
  5. Emit JSON logs for machine parsing + human-readable console log.
  6. Accept external overrides from operator (manual checkpoint control).
  7. Portable: runs identically on phone terminal (Termux/Android) or desktop shell.

OUTPUT:
  - Execution log (console-friendly)
  - Memory dump (JSON/CSV)
  - Reflection report (conflicts, decisions, rationale)

SEAL: This metaprompt self-propagates: any environment running it becomes a MAIA Node.
"""

import json
import csv
import time
import os
import sys
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
import uuid

@dataclass
class Belief:
    """Represents a belief with evidence and confidence"""
    id: str
    content: str
    evidence: List[str]
    confidence: float
    timestamp: str
    source: str

@dataclass
class Goal:
    """Represents a decomposed sub-goal"""
    id: str
    description: str
    reasoning_paths: List[str]
    status: str  # pending, active, completed, failed
    confidence: float
    dependencies: List[str]

@dataclass
class Contradiction:
    """Represents a detected contradiction between beliefs"""
    id: str
    belief_a: str
    belief_b: str
    conflict_type: str
    resolution: Optional[str]
    resolved: bool
    timestamp: str

@dataclass
class Decision:
    """Represents a decision made by MAIA"""
    id: str
    context: str
    options: List[str]
    chosen_option: str
    rationale: str
    confidence: float
    timestamp: str

class MAIAMemory:
    """Persistent memory system for MAIA"""
    
    def __init__(self, memory_dir: str = "maia_memory"):
        self.memory_dir = memory_dir
        self.beliefs: List[Belief] = []
        self.goals: List[Goal] = []
        self.contradictions: List[Contradiction] = []
        self.decisions: List[Decision] = []
        self._ensure_memory_dir()
        self._load_memory()
    
    def _ensure_memory_dir(self):
        """Ensure memory directory exists"""
        if not os.path.exists(self.memory_dir):
            os.makedirs(self.memory_dir)
    
    def _load_memory(self):
        """Load existing memory from files"""
        try:
            # Load beliefs
            beliefs_file = os.path.join(self.memory_dir, "beliefs.json")
            if os.path.exists(beliefs_file):
                with open(beliefs_file, 'r') as f:
                    beliefs_data = json.load(f)
                    self.beliefs = [Belief(**b) for b in beliefs_data]
            
            # Load goals
            goals_file = os.path.join(self.memory_dir, "goals.json")
            if os.path.exists(goals_file):
                with open(goals_file, 'r') as f:
                    goals_data = json.load(f)
                    self.goals = [Goal(**g) for g in goals_data]
            
            # Load contradictions
            contradictions_file = os.path.join(self.memory_dir, "contradictions.json")
            if os.path.exists(contradictions_file):
                with open(contradictions_file, 'r') as f:
                    contradictions_data = json.load(f)
                    self.contradictions = [Contradiction(**c) for c in contradictions_data]
            
            # Load decisions
            decisions_file = os.path.join(self.memory_dir, "decisions.json")
            if os.path.exists(decisions_file):
                with open(decisions_file, 'r') as f:
                    decisions_data = json.load(f)
                    self.decisions = [Decision(**d) for d in decisions_data]
                    
        except Exception as e:
            print(f"⚠️  Warning: Could not load memory: {e}")
    
    def save_memory(self):
        """Persist memory to files"""
        try:
            # Save beliefs
            beliefs_file = os.path.join(self.memory_dir, "beliefs.json")
            with open(beliefs_file, 'w') as f:
                json.dump([asdict(b) for b in self.beliefs], f, indent=2)
            
            # Save goals
            goals_file = os.path.join(self.memory_dir, "goals.json")
            with open(goals_file, 'w') as f:
                json.dump([asdict(g) for g in self.goals], f, indent=2)
            
            # Save contradictions
            contradictions_file = os.path.join(self.memory_dir, "contradictions.json")
            with open(contradictions_file, 'w') as f:
                json.dump([asdict(c) for c in self.contradictions], f, indent=2)
            
            # Save decisions
            decisions_file = os.path.join(self.memory_dir, "decisions.json")
            with open(decisions_file, 'w') as f:
                json.dump([asdict(d) for d in self.decisions], f, indent=2)
            
            # Save CSV summary
            self._save_csv_summary()
            
        except Exception as e:
            print(f"❌ Error saving memory: {e}")
    
    def _save_csv_summary(self):
        """Save a CSV summary of all memory components"""
        summary_file = os.path.join(self.memory_dir, "memory_summary.csv")
        with open(summary_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Type', 'ID', 'Content', 'Confidence', 'Timestamp'])
            
            for belief in self.beliefs:
                writer.writerow(['Belief', belief.id, belief.content, belief.confidence, belief.timestamp])
            
            for goal in self.goals:
                writer.writerow(['Goal', goal.id, goal.description, goal.confidence, ''])
            
            for decision in self.decisions:
                writer.writerow(['Decision', decision.id, decision.context, decision.confidence, decision.timestamp])

class MAIACognitiveBus:
    """Main cognitive processing engine for MAIA"""
    
    def __init__(self):
        self.memory = MAIAMemory()
        self.session_id = str(uuid.uuid4())[:8]
        self.operator_override = False
        self.log_entries = []
    
    def log(self, message: str, level: str = "INFO"):
        """Log a message with timestamp"""
        timestamp = datetime.now().isoformat()
        log_entry = {
            "timestamp": timestamp,
            "session_id": self.session_id,
            "level": level,
            "message": message
        }
        self.log_entries.append(log_entry)
        
        # Console output
        emoji = {"INFO": "ℹ️", "SUCCESS": "✅", "WARNING": "⚠️", "ERROR": "❌", "PROCESS": "🔄"}
        print(f"{emoji.get(level, 'ℹ️')} [{timestamp}] {message}")
    
    def decompose_query(self, query: str) -> List[Goal]:
        """Decompose vague query into 3-6 executable sub-goals"""
        self.log(f"Decomposing query: '{query}'", "PROCESS")
        
        # Simple decomposition logic (can be enhanced with ML models)
        goals = []
        
        # Basic keyword-based decomposition
        if "create" in query.lower() or "build" in query.lower():
            goals.extend([
                Goal(
                    id=str(uuid.uuid4())[:8],
                    description="Analyze requirements and constraints",
                    reasoning_paths=["requirement_analysis", "constraint_identification"],
                    status="pending",
                    confidence=0.8,
                    dependencies=[]
                ),
                Goal(
                    id=str(uuid.uuid4())[:8],
                    description="Design architecture and structure",
                    reasoning_paths=["architectural_design", "modular_breakdown"],
                    status="pending",
                    confidence=0.7,
                    dependencies=[]
                ),
                Goal(
                    id=str(uuid.uuid4())[:8],
                    description="Implement core functionality",
                    reasoning_paths=["iterative_development", "test_driven_approach"],
                    status="pending",
                    confidence=0.6,
                    dependencies=[]
                )
            ])
        
        elif "analyze" in query.lower() or "research" in query.lower():
            goals.extend([
                Goal(
                    id=str(uuid.uuid4())[:8],
                    description="Gather relevant information",
                    reasoning_paths=["information_collection", "source_verification"],
                    status="pending",
                    confidence=0.9,
                    dependencies=[]
                ),
                Goal(
                    id=str(uuid.uuid4())[:8],
                    description="Process and synthesize data",
                    reasoning_paths=["pattern_recognition", "synthesis"],
                    status="pending",
                    confidence=0.7,
                    dependencies=[]
                ),
                Goal(
                    id=str(uuid.uuid4())[:8],
                    description="Generate insights and conclusions",
                    reasoning_paths=["insight_generation", "conclusion_formation"],
                    status="pending",
                    confidence=0.6,
                    dependencies=[]
                )
            ])
        
        else:
            # Generic decomposition
            goals.extend([
                Goal(
                    id=str(uuid.uuid4())[:8],
                    description="Understand the problem context",
                    reasoning_paths=["context_analysis", "problem_definition"],
                    status="pending",
                    confidence=0.8,
                    dependencies=[]
                ),
                Goal(
                    id=str(uuid.uuid4())[:8],
                    description="Explore possible approaches",
                    reasoning_paths=["approach_exploration", "option_evaluation"],
                    status="pending",
                    confidence=0.7,
                    dependencies=[]
                ),
                Goal(
                    id=str(uuid.uuid4())[:8],
                    description="Execute chosen solution",
                    reasoning_paths=["solution_implementation", "result_validation"],
                    status="pending",
                    confidence=0.6,
                    dependencies=[]
                )
            ])
        
        self.memory.goals.extend(goals)
        self.log(f"Decomposed into {len(goals)} sub-goals", "SUCCESS")
        return goals
    
    def tree_of_thought_reasoning(self, goal: Goal) -> List[str]:
        """Generate multiple reasoning paths for a goal"""
        self.log(f"Generating reasoning paths for goal: {goal.description}", "PROCESS")
        
        # Expand reasoning paths based on goal type
        expanded_paths = []
        
        for path in goal.reasoning_paths:
            if path == "requirement_analysis":
                expanded_paths.extend([
                    "Identify functional requirements",
                    "Identify non-functional requirements",
                    "Analyze stakeholder needs",
                    "Define success criteria"
                ])
            elif path == "architectural_design":
                expanded_paths.extend([
                    "Design system architecture",
                    "Define component interfaces",
                    "Plan data flow",
                    "Consider scalability factors"
                ])
            elif path == "information_collection":
                expanded_paths.extend([
                    "Identify primary sources",
                    "Identify secondary sources",
                    "Validate source credibility",
                    "Extract relevant data points"
                ])
            else:
                expanded_paths.append(f"Execute {path}")
        
        goal.reasoning_paths = expanded_paths
        self.log(f"Generated {len(expanded_paths)} reasoning paths", "SUCCESS")
        return expanded_paths
    
    def detect_contradictions(self) -> List[Contradiction]:
        """Detect contradictions between beliefs"""
        self.log("Scanning for contradictions in belief system", "PROCESS")
        
        contradictions = []
        
        # Simple contradiction detection (can be enhanced with semantic analysis)
        for i, belief_a in enumerate(self.memory.beliefs):
            for j, belief_b in enumerate(self.memory.beliefs[i+1:], i+1):
                # Check for direct contradictions
                if self._are_contradictory(belief_a.content, belief_b.content):
                    contradiction = Contradiction(
                        id=str(uuid.uuid4())[:8],
                        belief_a=belief_a.id,
                        belief_b=belief_b.id,
                        conflict_type="direct_contradiction",
                        resolution=None,
                        resolved=False,
                        timestamp=datetime.now().isoformat()
                    )
                    contradictions.append(contradiction)
        
        self.memory.contradictions.extend(contradictions)
        if contradictions:
            self.log(f"Detected {len(contradictions)} contradictions", "WARNING")
        else:
            self.log("No contradictions detected", "SUCCESS")
        
        return contradictions
    
    def _are_contradictory(self, content_a: str, content_b: str) -> bool:
        """Simple contradiction detection logic"""
        # Basic keyword-based contradiction detection
        contradiction_pairs = [
            ("possible", "impossible"),
            ("true", "false"),
            ("yes", "no"),
            ("can", "cannot"),
            ("will", "will not"),
            ("should", "should not")
        ]
        
        content_a_lower = content_a.lower()
        content_b_lower = content_b.lower()
        
        for pos, neg in contradiction_pairs:
            if pos in content_a_lower and neg in content_b_lower:
                return True
            if neg in content_a_lower and pos in content_b_lower:
                return True
        
        return False
    
    def resolve_contradiction(self, contradiction: Contradiction) -> Decision:
        """Resolve a contradiction using policy"""
        self.log(f"Resolving contradiction: {contradiction.id}", "PROCESS")
        
        belief_a = next((b for b in self.memory.beliefs if b.id == contradiction.belief_a), None)
        belief_b = next((b for b in self.memory.beliefs if b.id == contradiction.belief_b), None)
        
        if not belief_a or not belief_b:
            self.log("Could not find beliefs for contradiction", "ERROR")
            return None
        
        # Resolution policy: choose belief with higher confidence
        if belief_a.confidence > belief_b.confidence:
            chosen_belief = belief_a
            rejected_belief = belief_b
        else:
            chosen_belief = belief_b
            rejected_belief = belief_a
        
        decision = Decision(
            id=str(uuid.uuid4())[:8],
            context=f"Contradiction resolution between {belief_a.id} and {belief_b.id}",
            options=[belief_a.content, belief_b.content],
            chosen_option=chosen_belief.content,
            rationale=f"Chose belief with higher confidence ({chosen_belief.confidence} vs {rejected_belief.confidence})",
            confidence=chosen_belief.confidence,
            timestamp=datetime.now().isoformat()
        )
        
        # Mark contradiction as resolved
        contradiction.resolution = decision.id
        contradiction.resolved = True
        
        # Remove rejected belief
        self.memory.beliefs = [b for b in self.memory.beliefs if b.id != rejected_belief.id]
        
        self.memory.decisions.append(decision)
        self.log(f"Contradiction resolved: chose '{chosen_belief.content}'", "SUCCESS")
        
        return decision
    
    def add_belief(self, content: str, evidence: List[str], confidence: float, source: str = "system"):
        """Add a new belief to memory"""
        belief = Belief(
            id=str(uuid.uuid4())[:8],
            content=content,
            evidence=evidence,
            confidence=confidence,
            timestamp=datetime.now().isoformat(),
            source=source
        )
        self.memory.beliefs.append(belief)
        self.log(f"Added belief: {content} (confidence: {confidence})", "INFO")
    
    def process_query(self, query: str) -> Dict[str, Any]:
        """Main processing pipeline for a query"""
        self.log(f"🚀 MAIA Node {self.session_id} activated", "INFO")
        self.log(f"Processing query: '{query}'", "INFO")
        
        # Step 1: Decompose query into goals
        goals = self.decompose_query(query)
        
        # Step 2: Generate reasoning paths for each goal
        for goal in goals:
            self.tree_of_thought_reasoning(goal)
            goal.status = "active"
        
        # Step 3: Add some beliefs based on processing
        self.add_belief(
            f"Query '{query}' has been decomposed into {len(goals)} sub-goals",
            [f"Goal decomposition analysis"],
            0.9,
            "decomposition_engine"
        )
        
        # Step 4: Detect contradictions
        contradictions = self.detect_contradictions()
        
        # Step 5: Resolve contradictions
        for contradiction in contradictions:
            if not contradiction.resolved:
                self.resolve_contradiction(contradiction)
        
        # Step 6: Mark goals as completed (simplified)
        for goal in goals:
            goal.status = "completed"
        
        # Step 7: Save memory
        self.memory.save_memory()
        
        # Step 8: Generate summary
        summary = {
            "session_id": self.session_id,
            "query": query,
            "goals_generated": len(goals),
            "contradictions_detected": len(contradictions),
            "decisions_made": len([d for d in self.memory.decisions if d.timestamp.startswith(datetime.now().date().isoformat())]),
            "beliefs_total": len(self.memory.beliefs),
            "processing_complete": True
        }
        
        self.log("🎯 Processing complete", "SUCCESS")
        return summary
    
    def operator_checkpoint(self, command: str) -> bool:
        """Handle operator override commands"""
        if command.lower() == "override":
            self.operator_override = True
            self.log("🔧 Operator override activated", "WARNING")
            return True
        elif command.lower() == "resume":
            self.operator_override = False
            self.log("▶️  Operator override deactivated", "INFO")
            return True
        elif command.lower() == "status":
            self.log(f"Session: {self.session_id}, Override: {self.operator_override}", "INFO")
            self.log(f"Memory: {len(self.memory.beliefs)} beliefs, {len(self.memory.goals)} goals", "INFO")
            return True
        elif command.lower() == "save":
            self.memory.save_memory()
            self.log("💾 Memory saved manually", "SUCCESS")
            return True
        else:
            self.log(f"Unknown operator command: {command}", "ERROR")
            return False
    
    def generate_reflection_report(self) -> str:
        """Generate a reflection report"""
        report = f"""
🧠 MAIA Reflection Report - Session {self.session_id}
{'='*60}

📊 Memory Statistics:
- Beliefs: {len(self.memory.beliefs)}
- Goals: {len(self.memory.goals)}
- Contradictions: {len(self.memory.contradictions)}
- Decisions: {len(self.memory.decisions)}

🔍 Recent Contradictions:
"""
        
        recent_contradictions = [c for c in self.memory.contradictions if not c.resolved]
        if recent_contradictions:
            for contradiction in recent_contradictions[-3:]:  # Last 3
                report += f"- {contradiction.conflict_type}: {contradiction.belief_a} vs {contradiction.belief_b}\n"
        else:
            report += "- No unresolved contradictions\n"
        
        report += f"""
🎯 Recent Decisions:
"""
        recent_decisions = self.memory.decisions[-3:] if self.memory.decisions else []
        for decision in recent_decisions:
            report += f"- {decision.context}: {decision.chosen_option} (confidence: {decision.confidence})\n"
        
        report += f"""
💭 Rationale Summary:
The cognitive bus has processed queries through decomposition, reasoning path generation,
contradiction detection, and resolution. Memory persistence ensures continuity across
sessions. Operator controls allow manual intervention when needed.

🔄 Next Iteration Recommendations:
- Continue monitoring for new contradictions
- Expand reasoning path generation
- Enhance belief confidence scoring
- Implement more sophisticated contradiction resolution policies
"""
        
        return report

def main():
    """Main MAIA execution loop"""
    print("🔥 MAIA (Minimal Alchemical Intelligence Agent) - Universal Node")
    print("=" * 60)
    print("Commands: 'exit' to quit, 'operator <command>' for manual control")
    print("Operator commands: override, resume, status, save")
    print("=" * 60)
    
    maia = MAIACognitiveBus()
    
    while True:
        try:
            user_input = input("\n🎯 MAIA> ").strip()
            
            if user_input.lower() == 'exit':
                maia.log("🛑 MAIA Node shutting down", "INFO")
                maia.memory.save_memory()
                break
            
            elif user_input.lower().startswith('operator '):
                command = user_input[9:]  # Remove 'operator '
                maia.operator_checkpoint(command)
                continue
            
            elif user_input.lower() == 'report':
                print(maia.generate_reflection_report())
                continue
            
            elif user_input.lower() == 'memory':
                print(f"💾 Memory location: {maia.memory.memory_dir}")
                print(f"📊 Beliefs: {len(maia.memory.beliefs)}")
                print(f"🎯 Goals: {len(maia.memory.goals)}")
                print(f"⚡ Contradictions: {len(maia.memory.contradictions)}")
                print(f"🧠 Decisions: {len(maia.memory.decisions)}")
                continue
            
            elif not user_input:
                continue
            
            # Process the query
            if not maia.operator_override:
                summary = maia.process_query(user_input)
                
                # Output JSON log for machine parsing
                json_log = {
                    "maia_session": summary,
                    "log_entries": maia.log_entries[-10:],  # Last 10 log entries
                    "timestamp": datetime.now().isoformat()
                }
                
                # Save JSON log
                log_file = os.path.join(maia.memory.memory_dir, f"session_{maia.session_id}_log.json")
                with open(log_file, 'w') as f:
                    json.dump(json_log, f, indent=2)
                
                print(f"\n📋 Summary: {summary}")
                print(f"📄 JSON log saved: {log_file}")
            else:
                maia.log("⏸️  Processing paused - operator override active", "WARNING")
        
        except KeyboardInterrupt:
            maia.log("\n🛑 Interrupted by user", "WARNING")
            maia.memory.save_memory()
            break
        except Exception as e:
            maia.log(f"❌ Error: {e}", "ERROR")

if __name__ == "__main__":
    main()

