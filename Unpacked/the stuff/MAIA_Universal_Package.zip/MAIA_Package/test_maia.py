#!/usr/bin/env python3
"""
Test script for MAIA functionality
"""

import maia_core
import json

def test_maia_basic():
    """Test basic MAIA functionality"""
    print("🧪 Testing MAIA Basic Functionality")
    print("=" * 50)
    
    # Initialize MAIA
    maia = maia_core.MAIACognitiveBus()
    print(f"✅ MAIA initialized with session ID: {maia.session_id}")
    
    # Test query processing
    test_query = "Create a simple web application"
    print(f"\n🎯 Testing query: '{test_query}'")
    
    summary = maia.process_query(test_query)
    print(f"✅ Query processed successfully")
    print(f"📊 Summary: {json.dumps(summary, indent=2)}")
    
    # Test memory persistence
    print(f"\n💾 Memory state:")
    print(f"   Beliefs: {len(maia.memory.beliefs)}")
    print(f"   Goals: {len(maia.memory.goals)}")
    print(f"   Contradictions: {len(maia.memory.contradictions)}")
    print(f"   Decisions: {len(maia.memory.decisions)}")
    
    # Test operator commands
    print(f"\n🔧 Testing operator commands:")
    maia.operator_checkpoint("status")
    maia.operator_checkpoint("save")
    
    # Generate reflection report
    print(f"\n📋 Generating reflection report:")
    report = maia.generate_reflection_report()
    print(report[:500] + "..." if len(report) > 500 else report)
    
    print(f"\n✅ All tests passed!")

if __name__ == "__main__":
    test_maia_basic()

